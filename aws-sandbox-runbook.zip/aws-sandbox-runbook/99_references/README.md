# 参照管理

本ランブックが根拠とする社内資料と外部資料の一覧。外部資料は内容が更新されるため、手順の前提が変わっていないか **確認日** を基準に見直す。

## 1. 社内資料

社内資料の名称・URL は未確定。確認できたら `<INTERNAL_...>` を置き換える (このファイルは非公開。Public GitHub へ出さない)。

| ID | 資料 | 参照先 | 本ランブックで使う箇所 |
| --- | --- | --- | --- |
| I-01 | サンドボックス利用ガイド (スイッチロール、定期削除、クォータ) | `<INTERNAL_SANDBOX_GUIDE>` | [01_constraints](../01_constraints/README.md) |
| I-02 | サンドボックスで利用可能な AWS サービス一覧 | `<INTERNAL_SANDBOX_SERVICE_LIST>` | 未確定事項 Q-03 |
| I-03 | SMART Gateway 利用手順 | `<INTERNAL_SMART_GATEWAY_GUIDE>` | [Pattern 01 §19-C](../04_patterns/01_windows-dev-ec2/README.md#c-smart-gateway-経由の-rdp-接続) |
| I-04 | 情報セキュリティ規程 (Public GitHub、個人契約サービスの利用) | `<INTERNAL_INFO_SECURITY_POLICY>` | [security-boundary](../01_constraints/security-boundary.md) |
| I-05 | Box Drive の利用ルール (State 保存可否) | `<INTERNAL_BOX_POLICY>` | 未確定事項 Q-01 |

## 2. 外部資料

確認日: 2026-09-29

### Terraform

| 資料 | URL |
| --- | --- |
| S3 Backend (`use_lockfile`) | <https://developer.hashicorp.com/terraform/language/backend/s3> |
| Terraform test (モック Provider) | <https://developer.hashicorp.com/terraform/language/tests> |
| Terraform 1.16.4 配布物 | <https://releases.hashicorp.com/terraform/1.16.4/> |
| HashiCorp の PGP 鍵 | <https://www.hashicorp.com/trust/security> |
| AWS Provider 6.66.0 | <https://registry.terraform.io/providers/hashicorp/aws/6.66.0/docs> |

### AWS

| 資料 | URL |
| --- | --- |
| Session Manager | <https://docs.aws.amazon.com/systems-manager/latest/userguide/session-manager.html> |
| Permissions Boundary | <https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_boundaries.html> |
| インスタンスメタデータ (IMDSv2) | <https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/configuring-instance-metadata-service.html> |
| EC2 user data | <https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/user-data.html> |
| EC2Launch v2 (Windows) | <https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2launch-v2.html> |
| Amazon Linux 2023 | <https://docs.aws.amazon.com/linux/al2023/ug/what-is-amazon-linux.html> |
| S3 バージョニング | <https://docs.aws.amazon.com/AmazonS3/latest/userguide/Versioning.html> |

### Docker

| 資料 | URL |
| --- | --- |
| Compose ファイルリファレンス | <https://docs.docker.com/reference/compose-file/> |
| Docker daemon ソケットの保護 | <https://docs.docker.com/engine/security/protect-access/> |
| Rootless モード | <https://docs.docker.com/engine/security/rootless/> |

### アプリケーション

| 資料 | URL |
| --- | --- |
| FastAPI | <https://fastapi.tiangolo.com/> |
| Vite の環境変数 (`VITE_` 接頭辞) | <https://vite.dev/guide/env-and-mode> |
| Node.js リリース (LTS) | <https://nodejs.org/en/about/previous-releases> |

### Snowflake

| 資料 | URL |
| --- | --- |
| キーペア認証 | <https://docs.snowflake.com/en/user-guide/key-pair-auth> |
| プログラムによるアクセストークン | <https://docs.snowflake.com/en/user-guide/programmatic-access-tokens> |
| Python Connector | <https://docs.snowflake.com/en/developer-guide/python-connector/python-connector> |
| Snowflake CLI | <https://docs.snowflake.com/en/developer-guide/snowflake-cli/index> |

### GitHub / Claude Code

| 資料 | URL |
| --- | --- |
| Personal access token | <https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens> |
| Git Credential Manager | <https://github.com/git-ecosystem/git-credential-manager> |
| Claude Code の設定 (permissions) | <https://code.claude.com/docs/en/settings> |

## 3. 更新ルール

- 外部資料の記述と手順が食い違った場合は、公式資料を正として手順を修正し、[CHANGELOG](../CHANGELOG.md) に記録する。
- バージョンを更新したときは、この表の確認日と [バージョン固定](../02_common-design/version-pinning.md) を更新する。
