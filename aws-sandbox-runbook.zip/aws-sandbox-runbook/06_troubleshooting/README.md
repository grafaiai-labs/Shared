# トラブルシューティング

症状ごとに「確認 → 原因 → 対処」の順で記載する。調査結果を共有するときは、アカウント ID、ARN、IP、バケット名を `<...>` に置き換える。

## 目次

| 分類 | 症状 |
| --- | --- |
| 接続 | [Session Manager で接続できない](#session-manager-で接続できない) / [RDP で接続できない](#rdp-で接続できない) |
| Runner / Terraform | [Runner の初期化が失敗した](#runner-の初期化が失敗した) / [terraform init が失敗する](#terraform-init-が失敗する) / [terraform apply で AccessDenied / UnauthorizedOperation](#terraform-apply-で-accessdenied--unauthorizedoperation) / [EC2 の作成が制約で拒否される](#ec2-の作成が制約で拒否される) / [State のロックが残っている](#state-のロックが残っている) / [State を失った（S3 バケットが消えた）](#state-を失ったs3-バケットが消えた) / [週末削除後に前週の State が残っている](#週末削除後に前週の-state-が残っている) |
| Windows | [Windows のパスワードを取得できない](#windows-のパスワードを取得できない) / [Windows の初期化スクリプトが失敗した](#windows-の初期化スクリプトが失敗した) |
| Linux / Docker | [Docker で permission denied](#docker-で-permission-denied) / [イメージの pull / パッケージの取得に失敗する](#イメージの-pull--パッケージの取得に失敗する) / [ディスクが不足する](#ディスクが不足する) |
| アプリ | [Snowflake へ接続できない](#snowflake-へ接続できない) |

---

## Session Manager で接続できない

| 確認 | 期待値 | 対処 |
| --- | --- | --- |
| インスタンスの状態 | 実行中、ステータスチェック合格 | 起動直後は 2〜5 分待つ |
| IAM インスタンスプロファイル | `AmazonSSMManagedInstanceCore` を含むロールが付いている | EC2 →「アクション」→「セキュリティ」→「IAM ロールを変更」。反映まで数分 |
| SG のアウトバウンド | TCP 443 が許可されている | 追加する (Terraform 管理のものは Terraform で) |
| Systems Manager →「フリートマネージャー」 | インスタンスが「オンライン」 | 表示されない場合はエージェントが Endpoint へ到達できていない |
| IMDS | メタデータが有効 | 「インスタンスメタデータオプションを変更」で有効化 |

原因の多くは IAM ロールの付け忘れか、アウトバウンドの削除しすぎ。SSM VPC Endpoint 自体の問題は利用者では直せないため管理者へ連絡する。

## RDP で接続できない

1. **Public IP が変わっていないか**: 停止・起動で変わる。コンソールで最新値を確認する。
2. **SG**: `<owner>-windev-ec2-01-sg` のインバウンドに、SMART Gateway の送信元 CIDR **3 件すべて** について TCP 3389 / TCP 22 / ICMP があること (計 9 ルール)。1 件だけ、または RDP だけでは接続できないことがある。既存 SG `CP-SandD01-D-SMARTGateway-SG` のインバウンドルールと送信元を突き合わせ、差分があれば `terraform.tfvars` の `gateway_allowed_cidrs` を直して `plan` → `apply` する (U-05)。
3. **インスタンスの状態**: ステータスチェック合格。「インスタンスのスクリーンショットを取得」でログオン画面が表示されているか。
4. **初期化中の再起動**: user data 実行中はインストーラーが再起動を要求しない設定だが、Windows Update で再起動中の場合がある。数分待つ。
5. **代替**: SSM が使える場合、Fleet Manager から状態を確認する (利用可能な場合)。

## Runner の初期化が失敗した

```bash
cat /var/lib/runner-setup/status              # failed:<行番号>
sudo tail -n 50 /var/log/runner-setup.log
```

| ログ | 原因 | 対処 |
| --- | --- | --- |
| `releases.hashicorp.com へ到達できません` | 外向き通信不可 (Q-02) | [ネットワーク §4](../02_common-design/network.md#4-public-subnet-から外部へ接続できない場合) |
| `PGP 鍵のフィンガープリントが一致しません` | HashiCorp の鍵更新、または取得内容の異常 | 公式サイトで鍵を確認し、[バージョン固定](../02_common-design/version-pinning.md) を更新。一致しない理由が不明なら中止 |
| `sha256sum: WARNING: 1 computed checksum did NOT match` | 取得失敗・改ざん・バージョン不一致 | 再実行。再現する場合は固定値と公式 SHA256SUMS を照合 |
| `dnf` のエラー | リポジトリへ到達できない | 時間をおいて再実行、外向き 443 を確認 |

再実行: スクリプトを `~/runner-setup.sh` に貼り付けて `sudo bash ~/runner-setup.sh` (冪等)。

## terraform init が失敗する

| エラー | 原因 | 対処 |
| --- | --- | --- |
| `Failed to query available provider packages` / タイムアウト | Registry へ到達できない | 外向き 443、Q-02 |
| `the cached package ... does not match any of the checksums recorded in the dependency lock file` | ロックファイルのハッシュ不一致 | ロックファイルを変更していないか確認。変更していなければ配布物の異常として中止 |
| `Error: Unsupported Terraform Core version` | Runner の Terraform が 1.16.4 でない | `terraform version`、runner-setup を再実行 |
| `AccessDenied` (S3) | バケット名の不一致、ポリシーの `<BOOTSTRAP_BUCKET_NAME>` の置き換え漏れ | `backend.hcl` と IAM ポリシーのバケット名を照合 |
| `Backend configuration changed` | 別のバケット名で init 済み | `terraform init -reconfigure -backend-config=...` |
| `NoSuchBucket` | バケット未作成・週末削除 | Pattern 00 §19-A |

## terraform apply で AccessDenied / UnauthorizedOperation

1. メッセージの `Action` と `Resource` を確認する。
2. `Encoded authorization failure message` をデコードする ([IAM 設計 §7](../02_common-design/iam.md#7-権限不足-accessdenied-の調べ方))。
3. 判断する。

| デコード結果 | 対処 |
| --- | --- |
| Runner のポリシーに該当 Allow がない | workload ポリシーへ最小限の Allow を追加し、[IAM 設計 §5](../02_common-design/iam.md#5-ワイルドカードを使っている箇所と理由) に理由を追記 |
| 条件 (タグ、VPC、インスタンスタイプ) で不一致 | `Owner` タグ、`<VPC_ID>`、`<OWNER>` の置き換えを確認 |
| Permissions Boundary / SCP による拒否 | ポリシーを広げても解決しない。管理者へ確認 (Q-06) |
| `iam:CreateRole` で Boundary 条件不一致 | `terraform.tfvars` の `permissions_boundary_arn` と workload ポリシーの `<PERMISSIONS_BOUNDARY_ARN>` を照合 |

Apply が途中で失敗した場合も State は作成済みのリソースを記録している。原因を直して再度 `plan` → `apply` すればよい。

## EC2 の作成が制約で拒否される

| エラー | 原因 | 対処 |
| --- | --- | --- |
| `InvalidParameterValue` / `UnauthorizedOperation` で volume type | `gp3` を指定、または AMI 既定の `gp3` のまま | `gp2` を明示 (Module は既定で `gp2`) |
| インスタンスタイプの拒否 | クォータ外のタイプ | t3 / t2 の nano〜medium |
| ボリュームサイズの拒否 | 100 GB 超 | 100 GB 以下 |

## State のロックが残っている

```text
Error: Error acquiring the state lock
Lock Info: ID: <LOCK_ID> Path: <BUCKET>/state/<pattern>/terraform.tfstate.tflock
```

1. 他のセッションで Terraform が実行中でないことを確認する (Runner は 1 台、利用者は 1 名)。
2. 実行中でなければ解除する。

   ```bash
   terraform force-unlock <LOCK_ID>
   ```

> [!WARNING]
> 実行中の Terraform があるときに解除すると State が壊れる。

## State を失った（S3 バケットが消えた）

週の途中でバケットを誤って削除した、または定期削除後に State だけが消えた場合。

| 状況 | 対処 |
| --- | --- |
| AWS 上のリソースも消えている (週末削除後) | 空の State から通常どおり再構築 |
| AWS 上のリソースは残っている | ① 必要なデータを退避 → ② コンソールで `tag:Owner = <OWNER>` かつ `ManagedBy = terraform` のリソースを手動削除 (EC2 → SG → キーペア → インスタンスプロファイル → IAM ロールの順) → ③ 空の State から再構築 |

`terraform import` で State を復元する方法もあるが、1 名・週次再構築の運用では削除して作り直す方が確実で速い。

## 週末削除後に前週の State が残っている

S3 が削除されずに State だけ残り、リソースが削除されている場合、`terraform plan` は「作成」を表示する (リソースが存在しないため)。そのまま apply してよい。
リソースが一部だけ残っている場合は前項の手順で整理する。

## Windows のパスワードを取得できない

| 症状 | 対処 |
| --- | --- |
| 「パスワードはまだ利用できません」 | 起動から 4 分以上待つ。15 分以上待っても出ない場合は「システムログを取得」で EC2Launch のエラーを確認 |
| 復号エラー | キーペア名と秘密鍵の組み合わせを確認。PEM 形式 (`-----BEGIN RSA PRIVATE KEY-----` または `-----BEGIN PRIVATE KEY-----`) の RSA 鍵であること。パスフレーズ付きは不可 |
| キーペアが「なし」 | `key_pair_public_key` / `key_pair_name` の設定漏れ。インスタンスの再作成が必要 |

## Windows の初期化スクリプトが失敗した

```powershell
Get-Content C:\ProgramData\DevBootstrap\status.txt
Select-String -Path C:\ProgramData\DevBootstrap\init.log -Pattern 'ERROR|mismatch|invalid'
Get-Content C:\ProgramData\Amazon\EC2Launch\log\agent.log -Tail 50
```

| ログ | 対処 |
| --- | --- |
| `SHA256 mismatch` | 配布元のファイルが変わった可能性。バージョンと URL を確認し、固定値を公式値で更新 |
| `invalid Authenticode signature` | 取得失敗・改ざんの可能性。再実行し、再現する場合は中止 |
| `npm install failed` / `pip install failed` | npm / PyPI への到達性 |
| ログがない | user data が実行されていない。`run_init_script_on_boot` を確認し、手動実行 |

## Docker で permission denied

```text
permission denied while trying to connect to the Docker daemon socket at unix:///var/run/docker.sock
```

| 確認 | 対処 |
| --- | --- |
| `id` の出力に `docker` がある | ない場合は `sudo usermod -aG docker dev` (ssm-user で) → `dev` で再ログイン (`exit` → `sudo -iu dev`) |
| `systemctl is-active docker` | `active` でなければ `sudo systemctl start docker`、`sudo journalctl -u docker` |

鍵ファイルでの `Permission denied` (API コンテナ内) は、所有者 `10001:10001`、ファイル `400`、`secrets/` ディレクトリ `711` を確認する。

## イメージの pull / パッケージの取得に失敗する

| 症状 | 原因 | 対処 |
| --- | --- | --- |
| `toomanyrequests` | Docker Hub の匿名 pull 制限 | 時間をおく。Public IP 単位の制限のため、再構築で IP が変わると解消する場合がある |
| タイムアウト | 外向き 443 不可、Proxy 未設定 (案 B) | SG、`proxy_url`、`/etc/systemd/system/docker.service.d/http-proxy.conf` |
| `pip ... hashes do not match` | `requirements.txt` と取得物の不一致 | `requirements.in` を変えたなら `uv pip compile` で再生成 |
| `npm ci` の失敗 | `package-lock.json` と `package.json` の不一致 | [バージョン固定](../02_common-design/version-pinning.md) の npm 手順で再生成 |

## ディスクが不足する

```bash
df -h /
docker system df
docker image prune          # 使われていないイメージ (確認あり)
docker builder prune        # ビルドキャッシュ
```

恒常的に不足する場合は `root_volume_size_gb` を増やす (100 GB 以下)。EC2 の再作成は不要だが、OS 側のパーティション拡張が必要な場合がある。

## Snowflake へ接続できない

`/api/readyz` または ETL のログの `error_code` で切り分ける。

| error_code | 確認 |
| --- | --- |
| `SNOWFLAKE_NOT_CONFIGURED` | `missing_settings` の項目を `.env` に設定。`<...>` のままになっていないか。鍵ファイルのパスと権限 |
| `SNOWFLAKE_UNREACHABLE` (errno 250001 等) | アカウント識別子の形式 (`<orgname>-<account_name>`)。EC2 から `curl -sI https://<SNOWFLAKE_ACCOUNT_IDENTIFIER>.snowflakecomputing.com` が応答するか |
| `SNOWFLAKE_AUTH_FAILED` | ユーザー名、公開鍵の登録 (`DESC USER` の `RSA_PUBLIC_KEY_FP`)、PAT の有効期限、ネットワークポリシー (EC2 の Public IP が許可されているか) |
| `SNOWFLAKE_TIMEOUT` | ウェアハウスの自動再開、クエリの重さ、タイムアウト値 |
| `SNOWFLAKE_QUERY_FAILED` | ロールの権限、DB / スキーマ名 (大文字・小文字) |

Snowflake 側の詳細は Snowsight の「クエリ履歴」でクエリタグ (`sample-api` / `sample-etl:*`) を検索する。
