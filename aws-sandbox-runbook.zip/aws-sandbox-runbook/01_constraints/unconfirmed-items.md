# 未確定事項台帳

仕様上「推測で確定してはならない」値と、実測で確認が必要な事項の一覧。
値はすべて `<PLACEHOLDER_NAME>` 形式で記載しており、確定した値は **Git 管理外のファイル** (`terraform.tfvars`、`backend.hcl`、`.env`) にだけ記入する。

リポジトリ内の残存プレースホルダーは次のコマンドで一覧できる。

```bash
python3 09_scripts/check_repo.py placeholders
```

## 1. 値 (プレースホルダー)

| ID | プレースホルダー | 内容 | 確認方法 | 記入先 (Git 管理外) |
| --- | --- | --- | --- | --- |
| U-01 | `<AWS_ACCOUNT_ID>` | サンドボックス AWS アカウント ID | スイッチロール後、コンソール右上のアカウントメニュー。画面を撮影しない | 各 `terraform.tfvars`、IAM ポリシー JSON (コンソール貼り付け時) |
| U-02 | `<VPC_ID>` | 利用する既存 VPC | VPC コンソール → VPC。管理者から指定がない場合は 1 つだけ存在するかを確認 | `terraform.tfvars`、`runner-workload-policy.json` |
| U-03 | `<PUBLIC_SUBNET_ID>` | Public Subnet | VPC → サブネット → ルートテーブルに `0.0.0.0/0 → igw-` があること。Runner 作成後は [smoke-test](../08_iac/bootstrap/smoke-test/main.tf) の `subnet_routes` 出力で `default_route_via = igw` を確認 | `terraform.tfvars` |
| U-04 | `<PRIVATE_SUBNET_ID>` | Private Subnet | 同上で `nat` なら NAT あり、`none` なら外向き通信不可 | `terraform.tfvars` (切替時のみ) |
| U-05 | `<GATEWAY_ALLOWED_CIDR_1>`〜`<GATEWAY_ALLOWED_CIDR_3>` | SMART Gateway の送信元 IP 3 件 (RDP / SSH / ICMP の許可元)。2026-10-01 に 3 件 (各 `/32`) と確認済み | 既存 SG `CP-SandD01-D-SMARTGateway-SG` のインバウンドルールの「ソース」、または SMART Gateway の利用案内・管理者。**推測で広い範囲を入れない** | Pattern 01 `terraform.tfvars` の `gateway_allowed_cidrs` (配列) |
| U-06 | `<PERMISSIONS_BOUNDARY_ARN>` | `ChildAccountRoleBoundary` の ARN | IAM → ポリシー → `ChildAccountRoleBoundary` → ARN をコピー | `terraform.tfvars`、`runner-workload-policy.json` |
| U-07 | `<BOOTSTRAP_BUCKET_NAME>` | Bootstrap S3 バケット名 | 毎週作成時に決める (グローバル一意)。命名規則: `<owner>-tfstate-s3-<sequence>-<ランダム英数字>` | `backend.hcl`、`terraform.tfvars`、IAM ポリシー JSON |
| U-08 | `<OWNER>` | 命名・タグ用の利用者識別子 (英小文字始まり 3〜16 文字、ハイフン不可) | 利用者が決める。社員番号など個人を特定できる値は避ける | `terraform.tfvars`、IAM ポリシー JSON |
| U-09 | `<EXPIRES_AT_YYYY_MM_DD>` | タグ ExpiresAt | 直近の日曜日 | `terraform.tfvars` |
| U-10 | `<RSA_PUBLIC_KEY_OPENSSH>` / `<EXISTING_KEY_PAIR_NAME>` | Windows パスワード復号用 RSA キー | [Pattern 01 §19](../04_patterns/01_windows-dev-ec2/README.md#19-手動例外手順) | Pattern 01 `terraform.tfvars` |
| U-11 | `<APPROVED_PROXY_URL>` | 承認済み Proxy | 管理者へ確認。存在しない前提で設計している | Pattern 02 `terraform.tfvars` (切替時のみ) |
| U-12 | `<SNOWFLAKE_ACCOUNT_IDENTIFIER>` | Snowflake アカウント識別子 (`<orgname>-<account_name>` 形式) | Snowsight → 左下のアカウントメニュー → Account → 識別子 | `.env` |
| U-13 | `<SNOWFLAKE_USER>` `<SNOWFLAKE_ROLE>` `<SNOWFLAKE_WAREHOUSE>` `<SNOWFLAKE_DATABASE>` `<SNOWFLAKE_SCHEMA>` | Snowflake 接続先 | Snowflake 管理者 / 自身の検証環境 | `.env` |
| U-14 | Snowflake 認証方式 | `keypair` (推奨) / `pat` / `password` | 利用する Snowflake アカウントのポリシーを確認 ([Snowflake 接続](../05_components/snowflake-connection.md)) | `.env` の `SNOWFLAKE_AUTH_METHOD` |
| U-15 | `<GITHUB_USER>` / `<GITHUB_REPO>` | 個人 Public GitHub のリポジトリ | 利用者が作成 | 検証コマンドの引数のみ |
| U-16 | `<ETL_SOURCE_HTTPS_URL>` | ETL の外部データ取得元 | 一般公開 API を選ぶ。認証が必要なものは対象外 | Pattern 04 `.env` |
| U-17 | `<APP_DIR>` | ETL の配置ディレクトリ | Linux EC2 上で決める (例: 作業ユーザーのホーム配下) | systemd unit |
| U-18 | `<PATTERN01_SECURITY_GROUP_ID>` | Windows 開発用 EC2 の SG ID | Pattern 01 の `terraform output security_group_id` | Pattern 02 `terraform.tfvars` |
| U-19 | `<PUBLIC_DOMAIN_NAME>` | Pattern 05 で HTTPS 公開するドメイン | 利用可能なドメインと DNS 検証手段の有無を確認 | Pattern 05 (未実装) |
| U-20 | `<ALLOWED_CLIENT_CIDR>` | Pattern 05 の公開範囲 | 試験目的から決める。`0.0.0.0/0` にする場合は WAF 必須 | Pattern 05 (未実装) |
| U-21 | `<PUBLIC_SUBNET_ID_AZ_A>` / `<PUBLIC_SUBNET_ID_AZ_C>` | ALB 用の異なる AZ の Public Subnet | smoke-test の `subnet_routes` で AZ と経路を確認 | Pattern 05 (未実装) |
| U-22 | `<GIT_USER_NAME>` / `<GIT_USER_EMAIL>` | Git のコミット作者 (Public GitHub に公開される) | GitHub の `noreply` アドレスを推奨 | 各 EC2 の `git config --global` |
| U-23 | `<BOX_BACKUP_DIR>` | Box Drive 上のバックアップ先フォルダー | 社内 PC の Box Drive 同期フォルダー。共有設定のないフォルダーにする | Git Bundle 作成コマンドの引数 |
| U-24 | `<INTERNAL_SANDBOX_GUIDE>` ほか `<INTERNAL_...>` 5 件 | 社内資料の名称・URL | 管理者・社内ポータル | [参照管理](../99_references/README.md) |

## 2. 可否・方針 (Yes / No で確定させるもの)

| ID | 事項 | 現在の扱い | 確認方法 | 確定後に変更する箇所 |
| --- | --- | --- | --- | --- |
| Q-01 | State を Box Drive へ保存してよいか | **保存しない** | 情報管理部門へ確認 | [Terraform と State](../02_common-design/terraform-and-state.md) §5 |
| Q-02 | Public Subnet から GitHub / HashiCorp / Terraform Registry へ接続できるか | 接続できる前提で手順を書き、初回に実測する | Runner の `/var/log/runner-setup.log` の `reach` 行、`terraform init` の成否 | 不可なら [ネットワーク設計](../02_common-design/network.md) §4 の代替案 |
| Q-03 | C-MAC で利用可能な AWS サービスの最新版 | EC2 / IAM / S3 / SSM / VPC 参照のみを前提 | 管理者の案内・利用可能サービス一覧 | [01_constraints](README.md) §4、Pattern 04 / 05 |
| Q-04 | Private Subnet に NAT または承認済み Proxy があるか | ない前提 | smoke-test の `subnet_routes`、管理者確認 | Pattern 02 `subnet_mode` |
| Q-05 | カスタマー管理ポリシーを作成できるか | 作成できる前提 | IAM → ポリシー → ポリシーの作成 | 不可ならロールのインラインポリシーへ貼り付ける ([Pattern 00](../04_patterns/00_terraform-bootstrap/README.md) §15) |
| Q-06 | Runner ロールから `iam:CreateRole` 等が Boundary で許可されるか | 許可される前提 | Pattern 01 の初回 `terraform apply` | 不可なら IAM ロールを手動作成し Module へ名前を渡す方式へ変更 |
| Q-07 | Claude Code の認証を社内 PC のブラウザーで行ってよいか | Windows 開発用 EC2 のブラウザーで行う | 社内ルールの確認 | [Claude Code](../05_components/claude-code.md) |
| Q-08 | Resource Groups & Tag Editor を利用できるか | 利用できない場合はサービス別に確認 | コンソールで開けるか | [週末前の破棄](../03_common-runbook/pre-weekend-teardown.md) §6 |
| Q-09 | Pattern 05 で使う ALB / API Gateway / WAF / ACM / 独自ドメインを利用できるか | 未検証 (設計のみ) | 管理者確認 | [Pattern 05](../04_patterns/05_public-web/README.md) |

## 3. 実行時に置き換える引数

未確定値ではなく、コマンド実行のたびに変わる値。記録不要。

| プレースホルダー | 内容 |
| --- | --- |
| `<IAC_ZIP_NAME>` / `<IAC_ZIP_SHA256>` | `package-iac.sh` が出力した ZIP 名と SHA256 |
| `<ROOT_MODULE_DIR>` | Runner 上の Root Module のパス |
| `<ENCODED_MESSAGE>` | AccessDenied に含まれる encoded authorization failure message |
| `<LOCK_ID>` / `<BUCKET>` | State ロックのエラーに表示される値 |
| `<COMMIT_MESSAGE>` / `<FILE_NAME>` / `<CONTAINER>` / `<EXPORT_DIR>` | コミットメッセージ、ファイル名、コンテナ名、Public 抽出先 |
| `<RSA_PUBLIC_KEY_BODY>` | Snowflake へ登録する公開鍵の本文 (秘密情報ではない) |
| `<ETL_JOB_NAME>` | ETL のジョブ名 (`.env` の `ETL_JOB_NAME`) |

テンプレート内の `<PATTERN_TITLE>` / `<PURPOSE>` / `<DECISION_TITLE>` と、書式説明の `<PLACEHOLDER>` / `<PLACEHOLDER_NAME>` は置き換え対象ではない。

## 4. 社内資料

社内資料の URL・文書名は [参照管理](../99_references/README.md) に `<INTERNAL_...>` として記載している。社内 URL は Public GitHub へ出さない。
