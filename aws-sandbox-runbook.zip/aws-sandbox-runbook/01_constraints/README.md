# C-MAC サンドボックス制約

このランブックのすべての設計判断は、ここに記載した制約を前提とする。制約が変わった場合は、まずこの文書を更新し、影響する文書を [CHANGELOG](../CHANGELOG.md) に記録する。

関連文書:

- [Public / 非公開の境界と秘密情報の扱い](security-boundary.md)
- [未確定事項台帳](unconfirmed-items.md)

## 1. 利用範囲

| 項目 | 内容 |
| --- | --- |
| 利用者 | 当面 1 名 |
| 用途 | 個人の学習、非業務の技術検証 |
| 扱わないもの | 業務ソースコード、社内機密情報、顧客情報、個人情報、本番データ |
| Claude Code | 個人契約のものを利用する |
| GitHub | 個人 Public アカウント。一般公開可能な汎用コードとダミー情報のみ保存する |

## 2. アカウントとリージョン

| 項目 | 値 |
| --- | --- |
| サインイン経路 | Shared アカウントからサンドボックス個別アカウントへスイッチロール |
| スイッチ先ロール名 | `CP-SandD01-D-Role-ChildAdmin` |
| サンドボックス AWS アカウント ID | `<AWS_ACCOUNT_ID>` (未確定) |
| リージョン | `ap-northeast-1` のみ |
| オンプレミス接続 | 不可 |

## 3. 定期削除

| 項目 | 内容 |
| --- | --- |
| サインイン不可時間 | 毎週 日曜 22:00 〜 月曜 09:00 |
| 削除対象 | ほぼすべての AWS リソース (S3 を含む) |
| 帰結 | AWS 内のリソース・データを永続的な正本として扱わない |
| 週末前 | Terraform 管理対象を原則 `terraform destroy` する |
| 週末後 | 空の環境から再構築する |

運用上の締め切りは次のとおりとする。

- 週末前の破棄は **金曜の作業終了時** に行う。遅くとも **日曜 21:00** までに完了させる (22:00 の 1 時間前)。
- タグ `ExpiresAt` には直近の日曜日の日付 (`YYYY-MM-DD`) を設定する。

## 4. 利用者が実施できないこと

| 制約 | 本ランブックでの対応 |
| --- | --- |
| VPC、Subnet、Network ACL を作成できない | 既存 VPC / Subnet の ID を変数で受け取る。Terraform で作成しない |
| NACL の穴あけは実施されない | NACL 変更を前提とした設計をしない。到達性は実測で確認する |
| 一部の AWS サービスを利用できない | サービス利用前に可否を確認する ([未確定事項](unconfirmed-items.md)) |
| IAM ユーザー、IAM グループ、アクセスキーを作成できない | EC2 インスタンスロールと SSM で操作する |
| サンドボックスでアクセスキーを使わない | Runner はインスタンスロールの一時認証情報だけを使う |
| AWS CloudShell を利用できない | Terraform Runner EC2 を手動で Bootstrap する |
| 社内 PC から AWS CLI / Terraform を直接実行できない | 同上。社内 PC はブラウザー (AWS コンソール) と VS Code のみ |

## 5. 利用者が守ること

| 規則 | 確認方法 |
| --- | --- |
| IAM ロール作成時は Permissions Boundary `ChildAccountRoleBoundary` を適用する | コンソール: ロール詳細の「アクセス許可の境界」。Terraform: `permissions_boundary` 変数 (必須) |
| 予約名 `CP-SandD*-D-*` に該当する名前を作らない | 命名は `<owner>-<purpose>-<resource>-<sequence>`。`owner` は英小文字始まり 3 文字以上のため予約名と衝突しない ([命名とタグ](../02_common-design/naming-and-tagging.md)) |
| SSM 用 VPC Endpoint は既存のものを使う | 新規作成しない |

## 6. クォータ

### 6.1 EC2 インスタンスタイプ

利用可能: `t3.nano` / `t3.micro` / `t3.small` / `t3.medium` / `t2.nano` / `t2.micro` / `t2.small` / `t2.medium`

Terraform の変数検証と Runner の IAM 条件 (`ec2:InstanceType`) の両方でこの一覧に制限している。

### 6.2 EBS

| 項目 | 値 |
| --- | --- |
| ボリュームタイプ | `gp2` / `st1` / `sc1` / `standard` |
| 最大サイズ | 100 GB |

> [!IMPORTANT]
> Amazon Linux 2023 の AMI は既定のルートボリュームが `gp3` である。`gp3` は利用できないため、
> Terraform では `volume_type = "gp2"` を明示し、コンソールで EC2 を作成する場合も必ず `gp2` へ変更する。

### 6.3 RDS

| 項目 | 値 |
| --- | --- |
| インスタンスクラス | `db.t3.micro` / `db.t3.small` / `db.t3.medium` |
| 最大ストレージ | 100 GB |

## 7. 接続方式

| 対象 | 方式 | 配置 | インバウンド |
| --- | --- | --- | --- |
| Windows 開発用 EC2 | SMART Gateway 経由の RDP | Public Subnet + Public IPv4 | TCP 3389 を SMART Gateway 許可 IP からのみ |
| Linux EC2 | SSM Session Manager | 初期は Public Subnet + Public IPv4 ([ネットワーク設計](../02_common-design/network.md)) | なし |
| Terraform Runner | SSM Session Manager | Public Subnet + Public IPv4 | なし |

- Windows EC2 は Windows Server 2022 Japanese Full Base、`t3.medium`、AMI ID は固定しない。Docker Desktop は導入しない。
- Linux EC2 は SSH キーと SSH インバウンドを使わない。Docker Engine / Docker Compose は Linux EC2 で実行する。
- Terraform Runner は Amazon Linux 2023、`t3.micro`、キーペアなし。Terraform 実行時だけ起動し、週末前に最後に削除する。

## 8. Terraform と State の制約

- Terraform / AWS Provider は固定バージョン ([バージョン固定](../02_common-design/version-pinning.md))。
- State は非公開 S3 Backend (暗号化、バージョニング、`use_lockfile = true`)。S3 も週末削除対象のため正本にしない。
- State を Box Drive へ保存してよいかは未確定。**許可が確認されるまで Box Drive へ State を保存しない。**
- Runner、Runner 用 IAM、Runner 用 Security Group、Bootstrap S3 は Terraform 管理外 (コンソールで手動作成・手動削除)。

詳細は [Terraform と State](../02_common-design/terraform-and-state.md) を参照。
