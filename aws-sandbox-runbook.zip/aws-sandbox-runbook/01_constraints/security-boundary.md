# Public / 非公開の境界と秘密情報の扱い

## 1. 保存先の区分

| 保存先 | 位置付け | 保存してよいもの |
| --- | --- | --- |
| ローカル Git (このリポジトリ) | **正本**。リモートは設定しない | すべての文書とコード。ただし `.gitignore` 対象 (State、tfvars、秘密鍵など) は除く |
| Box Drive | ローカル Git のバックアップ | Git Bundle、非公開 IaC ZIP。**State は許可確認まで保存しない** |
| 非公開 S3 (Bootstrap バケット) | 実行時の一時置き場。週末に削除される | State、IaC ZIP、退避ファイル |
| 個人 Public GitHub | 一般公開 | 下表「Public 可」のディレクトリから [export-public.sh](../09_scripts/export-public.sh) で抽出したものだけ |

## 2. ディレクトリごとの公開可否

| パス | 区分 | 理由 |
| --- | --- | --- |
| `01_constraints/` `02_common-design/` `03_common-runbook/` `05_components/` `06_troubleshooting/` `99_references/` | 非公開 | C-MAC 固有の制約、ロール名、運用情報を含む |
| `04_patterns/*/README.md` | 非公開 | 同上 |
| `04_patterns/00_terraform-bootstrap/iam/` | 非公開 | C-MAC 固有の予約名・Boundary の扱いを含む |
| `04_patterns/*/scripts/` | Public 可 | 汎用スクリプト。環境依存値は環境変数で受け取る |
| `04_patterns/0[12]_*/terraform/` | Public 可 (tfvars 除く) | 値は変数化済み。`*.tfvars.example` はプレースホルダーのみ |
| `04_patterns/03_docker-react-fastapi-snowflake/` (README 除く) | Public 可 | ダミー値のみ |
| `04_patterns/04_scheduled-etl/` (README 除く) | Public 可 | ダミー値のみ |
| `08_iac/modules/` | Public 可 | 環境非依存の Module |
| `08_iac/bootstrap/` | Public 可 (backend.hcl 除く) | バケット名は `backend.hcl` (Git 管理外) にだけ書く |

Public 可のコードには、C-MAC 固有の語 (組織名、接続ゲートウェイ名、予約ロール名、Boundary 名) を書かない。[check-repo.sh](../09_scripts/check-repo.sh) がこれを検査する。

## 3. Public GitHub へ保存してはならないもの

AWS アカウント ID / VPC ID / Subnet ID / Security Group ID / IAM ARN / Permissions Boundary ARN / C-MAC 固有のリソース名 / SMART Gateway 情報 / 社内 URL / Backend バケット名 / `terraform.tfvars` / `backend.hcl` / Terraform State / Terraform Plan / パスワード / 秘密鍵 / トークン / 社内情報

## 4. 秘密情報の取り扱い

| 種類 | 置き場所 | 置いてはいけない場所 |
| --- | --- | --- |
| AWS 認証情報 | 作成しない。EC2 インスタンスロールの一時認証情報のみ | どこにも |
| Windows Administrator パスワード | 取得後はパスワードマネージャー等、リポジトリ外 | Markdown、Git、スクリーンショット、チャット |
| RSA 秘密鍵 (Windows パスワード復号用) | 社内 PC のリポジトリ外フォルダー | リポジトリ、Box の共有フォルダー、S3 |
| Snowflake 秘密鍵 / PAT | EC2 上の `secrets/` (Git 管理外、`chmod 400`) | `.env`、Dockerfile、Compose、イメージ、ログ |
| GitHub 認証 | Windows: Git Credential Manager / Linux: 実行時のみ入力 | リポジトリ、`.env`、シェル履歴 |
| Claude Code 認証 | 各 EC2 のユーザーホーム (週末に消える) | リポジトリ |
| Terraform State / Plan | 非公開 S3 (実行中のみ)。Plan はファイル保存しない | Git、Box (許可確認まで)、Public GitHub |

> [!WARNING]
> Terraform State には、作成したリソースの ID や、場合によっては秘密値が平文で残る。
> State と Plan は機密ファイルとして扱い、ダウンロード・共有・画面共有をしない。

## 5. ログ・スクリーンショット・画面共有

- スクリーンショットは原則撮らない。必要な場合は [10_assets の加工ルール](../10_assets/README.md) に従い、保存前に内部情報を塗りつぶす。
- コンソールで次が表示された状態で撮影しない: アカウント ID (右上メニュー)、ARN、VPC / Subnet / SG ID、Public IP、バケット名、SMART Gateway の IP。
- ターミナルの出力をチャット、Issue、Public リポジトリへ貼る前に、ID・IP・バケット名を `<...>` へ置き換える。
- `terraform plan` / `terraform output` の出力をそのままファイル保存しない。
- アプリケーションログにはパスワード、トークン、個人情報を出さない。サンプルコードはキー名で自動マスクする (`[REDACTED]`)。

## 6. Claude Code 利用時の注意

- Claude Code に `.env`、`secrets/`、`*.tfvars`、`backend.hcl`、State を読ませない。拒否設定は [Claude Code](../05_components/claude-code.md) を参照。
- Claude Code へ貼り付ける情報にも §3 の値を含めない。
- 業務コード・社内情報を扱わない (個人契約のため)。
