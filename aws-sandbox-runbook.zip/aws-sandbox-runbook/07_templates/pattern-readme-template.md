# Pattern NN: <PATTERN_TITLE>

<!--
構成パターン文書のテンプレート。04_patterns/NN_<name>/README.md へコピーして使う。
- 共通事項 (命名、IAM 方針、Docker 方針、週次運用) は書き写さず、02_common-design / 03_common-runbook へリンクする。
- 該当しない章も削除せず「該当なし (理由)」と書く。
- 値は <PLACEHOLDER_NAME> 形式。実値は Git 管理外のファイルにだけ書く。
- 04_patterns/NN_<name>/ へコピーした後は、相対リンクの `../` を `../../` に置き換える。
- 書き終えたら 09_scripts/check-repo.sh を実行する。
-->

1 文で、何を作り、何を確かめるパターンかを書く。

## 1. 用途

- 試験目的 (機能 / 性能 / 運用手順 / サービスの挙動のどれか)
- 利用者と利用場面

## 2. 成功条件

- [ ] 観測できる条件で書く (コマンドの出力、HTTP ステータス、ログのキー)
- [ ] 週末前に全リソースを削除できる

## 3. 非スコープ

- 

## 4. 前提条件

| 項目 | 状態 |
| --- | --- |
| 先行パターン | |
| 必要な値 | 未確定事項台帳の ID |

## 5. 設計判断

| 判断 | 内容 | 理由 |
| --- | --- | --- |
| | | |

## 6. 採用コンポーネント

| コンポーネント | 用途 / 設定 |
| --- | --- |
| | |

## 7. 不採用コンポーネントと切替条件

| 不採用 | 理由 | 採用へ切り替える条件 |
| --- | --- | --- |
| | | |

## 8. 制約、代替策、残存リスク

| 制約・リスク | 代替策・対策 |
| --- | --- |
| | |

## 9. Mermaid 構成図

```mermaid
flowchart LR
  A["送信元"] --> B["対象"]
```

## 10. 通信フロー

| # | 送信元 | 宛先 | ポート | 用途 |
| --- | --- | --- | --- | --- |
| 1 | | | | |

## 11. データフロー

| データ | 保存場所 | 退避先 | 寿命 |
| --- | --- | --- | --- |
| | | | 週末まで |

## 12. 作成する AWS リソース

| リソース | 名前 | 管理 (terraform / manual-bootstrap) |
| --- | --- | --- |
| | `<owner>-<purpose>-<resource>-01` | |

## 13. パラメーター

| 変数 | 既定 | 説明 |
| --- | --- | --- |
| | | |

## 14. 命名とタグ

[命名とタグ](../02_common-design/naming-and-tagging.md) に従う。`Purpose = <PURPOSE>`。

## 15. IAM 設計

- インスタンスロールの権限
- Runner の workload ポリシーへの追加が必要な権限と、その理由

## 16. Permissions Boundary

ロールを作る箇所と、Boundary を適用する方法。

## 17. Security Group 設計

| 方向 | プロトコル | ポート | 相手 | 説明 |
| --- | --- | --- | --- | --- |
| | | | | |

## 18. Terraform 構成

Root Module は `04_patterns/02_linux-docker-dev/terraform/` を複製して開始する (versions / backend / providers / tests)。
State キーは `state/NN_<name>/terraform.tfstate` とし、[08_iac/patterns](../08_iac/patterns/README.md) に追記する。

```bash
terraform init -input=false -backend-config=../../../08_iac/bootstrap/backend.hcl
terraform plan -out=run.tfplan
terraform apply run.tfplan && rm -f run.tfplan
```

## 19. 手動例外手順

コンソール操作は、画面文言に加えて「確認すべき設定値」を表で書く。

## 20. OS とミドルウェア初期設定

## 21. Docker 構成

## 22. アプリケーション配置

## 23. 正常系確認

```bash
# 期待値をコメントで書く
```

## 24. 異常系確認

| 状況 | 期待値 |
| --- | --- |
| | |

## 25. ログと監視

## 26. 停止手順

## 27. 個別削除

## 28. 全体削除

> [!CAUTION]
> 削除対象と、復元できないものを明記する。

## 29. 週末前の退避

## 30. 週末後の再構築

## 31. トラブルシューティング

## 32. コスト

| 課金要素 | 備考 |
| --- | --- |
| | |

## 33. 未確定事項

## 34. 更新履歴

| 日付 | 内容 |
| --- | --- |
| YYYY-MM-DD | 初版 |
