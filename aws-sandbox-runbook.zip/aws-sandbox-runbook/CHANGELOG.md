# CHANGELOG

形式: 日付ごとに「追加 / 変更 / 削除 / 固定バージョン」を記録する。制約・未確定事項の確定、バージョン更新、手順の修正は必ずここへ残す。

## 2026-09-29

### 追加

- 初版。仕様書 `claude-code-input-spec.md` に基づき、ランブック一式を作成。
- 制約: [C-MAC 制約](01_constraints/README.md)、[Public / 非公開の境界](01_constraints/security-boundary.md)、[未確定事項台帳](01_constraints/unconfirmed-items.md)。
- 共通設計: 命名とタグ、ネットワーク (Public Subnet 初期採用と Private Subnet への切替条件)、IAM (ワイルドカードの理由と縮小方法)、Terraform と State、Docker 方針、バージョン固定、コード管理。
- 共通 Runbook: 作業開始、作業終了、週末前の破棄、週末後の再構築。
- Pattern 00 Terraform Bootstrap: 手動作成手順 (S3 / IAM / SG / Runner)、IAM ポリシー JSON 5 件、Runner 初期化スクリプト (PGP 署名 + SHA256 検証)、`iac-fetch`、smoke-test Root Module。
- Pattern 01 Windows 開発用 EC2: Terraform (Root Module + Module + テスト)、PowerShell 初期化・確認スクリプト。
- Pattern 02 Linux Docker 開発用 EC2: Terraform (Root Module + Module + テスト)、初期化・確認スクリプト。
- Pattern 03 React + FastAPI + Snowflake: Docker Compose サンプル (API テスト 27 件、フロントエンドテスト 5 件)。
- Pattern 04 定期 ETL: 冪等 MERGE・再試行・タイムアウトのサンプル (テスト 16 件)、systemd timer。
- Pattern 05 Web 公開構成: 設計のみ (Terraform 未実装の理由と差し替え箇所を記載)。
- 共通コンポーネント、トラブルシューティング、テンプレート、資産ルール、参照管理。
- 検査・運用スクリプト: `check-repo.sh`、`check_repo.py`、`package-iac.sh`、`New-IacPackage.ps1`、`export-public.sh`。

### 固定バージョン

Terraform 1.16.4 / AWS Provider 6.66.0 / Docker Compose v5.5.1 / Buildx v0.37.1 / Node.js 24.21.0 / Python 3.13.15 / Git for Windows 2.56.0 / VS Code 1.139.1 / AWS CLI 2.37.5 / Claude Code 2.1.284 / Snowflake Connector 4.7.5 / Snowflake CLI 3.28.0 / FastAPI 0.141.1 / React 19.3.0 / Vite 8.3.1 / TypeScript 6.0.3。詳細は [バージョン固定](02_common-design/version-pinning.md)。
