# CHANGELOG

形式: 日付ごとに「追加 / 変更 / 削除 / 固定バージョン」を記録する。制約・未確定事項の確定、バージョン更新、手順の修正は必ずここへ残す。

## 2026-10-01

### 変更

- Pattern 01 Windows 開発用 EC2: Security Group を SMART Gateway の実環境に合わせた。RDP だけを許可した SG (`<owner>-windev-ec2-01-sg`) では SMART Gateway 経由で接続できず、既存 SG `CP-SandD01-D-SMARTGateway-SG` を追加すると接続できたため、同じ許可を Terraform 管理の SG に持たせる。
  - 変数 `rdp_allowed_cidrs` を `gateway_allowed_cidrs` (SMART Gateway 送信元 CIDR の配列) へ改名 (Root Module / [windows-dev-ec2](08_iac/modules/windows-dev-ec2/variables.tf) Module)。**既存の `terraform.tfvars` は変数名の書き換えが必要。**
  - 各 CIDR に RDP (TCP 3389)、SSH (TCP 22)、ICMP (全種別) のインバウンドルールを作成する。3 種類とも `for_each = toset(var.gateway_allowed_cidrs)` (キーは CIDR) のため、CIDR の追加・削除で Terraform コードを変更しない。既存 RDP ルールのアドレスは変わらない。
  - 変数検証に IPv4 CIDR 形式のチェックを追加 (IPv6、`/` のない値を拒否)。従来の「1 件以上、`/16` 以上、`0.0.0.0/0` 不可」は維持。
  - Module 出力 `gateway_ingress_cidrs` (rdp / ssh / icmp ごとの送信元 CIDR) を追加。
  - SG の description は SG の再作成を避けるため据え置き。
- U-05 を確定: SMART Gateway の送信元 IP は 3 件 (各 `/32`)。実値は Git 管理外の `terraform.tfvars` にだけ記入する方針は変えず、プレースホルダーを `<RDP_ALLOWED_CIDR>` から `<GATEWAY_ALLOWED_CIDR_1>`〜`<GATEWAY_ALLOWED_CIDR_3>` に変更。
- 文書: [Pattern 01 README](04_patterns/01_windows-dev-ec2/README.md) (成功条件、設計判断、Security Group 設計、パラメーター、送信元 CIDR の記入手順)、`terraform.tfvars.example`、[ネットワーク設計](02_common-design/network.md)、[C-MAC 制約](01_constraints/README.md)、[未確定事項台帳](01_constraints/unconfirmed-items.md)、[トラブルシューティング](06_troubleshooting/README.md#rdp-で接続できない)。
- テスト: Module テストを 6 件 → 10 件 (9 ルールのポート・プロトコル・送信元、CIDR 追加、空配列 / IPv6 / プレフィックスなしの拒否)、Root Module テストを 3 件 → 4 件 (3 CIDR × 3 種類、CIDR 追加) に更新。

## 2026-09-29

### 追加

- 初版。仕様書 `claude-code-input-spec.md` に基づき、ランブック一式を作成。
- 制約: [C-MAC 制約](01_constraints/README.md)、[Public / 非公開の境界](01_constraints/security-boundary.md)、[未確定事項台帳](01_constraints/unconfirmed-items.md)。
- 共通設計: 命名とタグ、ネットワーク (Public Subnet 初期採用と Private Subnet への切替条件)、IAM (ワイルドカードの理由と縮小方法)、Terraform と State、Docker 方針、バージョン固定、コード管理。
- 共通 Runbook: 作業開始、作業終了、週末前の破棄、週末後の再構築。
- Pattern 00 Terraform Bootstrap: 手動作成手順 (S3 / IAM / SG / Runner)、IAM ポリシー JSON 5 件、Runner 初期化スクリプト (PGP 署名 + SHA256 検証)、`iac-fetch`、smoke-test Root Module。
- Pattern 01 Windows 開発用 EC2: Terraform (Root Module + Module + テスト)、PowerShell 初期化・確認スクリプト。
- Pattern 02 Linux Docker 開発用 EC2: Terraform (Root Module + Module + テスト)、初期化・確認スクリプト。
- Pattern 03 React + FastAPI + Snowflake: Docker Compose サンプル (API テスト 27 件、フロントエンドテスト 5 件)。
- Pattern 04 定期 ETL: 冪等 MERGE・再試行・タイムアウトのサンプル (テスト 16 件)、systemd timer。
- Pattern 05 Web 公開構成: 設計のみ (Terraform 未実装の理由と差し替え箇所を記載)。
- 共通コンポーネント、トラブルシューティング、テンプレート、資産ルール、参照管理。
- 検査・運用スクリプト: `check-repo.sh`、`check_repo.py`、`package-iac.sh`、`New-IacPackage.ps1`、`export-public.sh`。

### 固定バージョン

Terraform 1.16.4 / AWS Provider 6.66.0 / Docker Compose v5.5.1 / Buildx v0.37.1 / Node.js 24.21.0 / Python 3.13.15 / Git for Windows 2.56.0 / VS Code 1.139.1 / AWS CLI 2.37.5 / Claude Code 2.1.284 / Snowflake Connector 4.7.5 / Snowflake CLI 3.28.0 / FastAPI 0.141.1 / React 19.3.0 / Vite 8.3.1 / TypeScript 6.0.3。詳細は [バージョン固定](02_common-design/version-pinning.md)。
