# C-MAC AWS サンドボックス共通運用ランブック

C-MAC の AWS サンドボックスで、学習・技術検証用の環境を **安全かつ短時間で 構築 → 確認 → 停止 → 削除 → 再構築** するための手順・IaC・サンプルコード一式。

> [!IMPORTANT]
> このリポジトリは **非公開 (ローカル Git が正本、リモートなし)**。C-MAC 固有の制約と運用情報を含むため、Public GitHub へ push しない。
> 公開してよいコードは [export-public.sh](09_scripts/export-public.sh) で抽出する ([境界の定義](01_constraints/security-boundary.md))。

## 最初に読むもの

1. [C-MAC サンドボックス制約](01_constraints/README.md) — 何ができて何ができないか
2. [Public / 非公開の境界と秘密情報](01_constraints/security-boundary.md) — 何をどこに置いてよいか
3. [未確定事項台帳](01_constraints/unconfirmed-items.md) — 着手前に確認・入力する値

## 1 週間の流れ

```mermaid
flowchart LR
  R["月曜: 週末後の再構築"] --> S["毎日: 作業開始"] --> E["毎日: 作業終了"] --> S
  E --> T["金曜: 週末前の破棄"] --> D["日曜 22:00: 定期削除"] --> R
```

| いつ | 手順書 |
| --- | --- |
| 週の最初 | [週末後の再構築](03_common-runbook/post-weekend-rebuild.md) |
| 毎日の開始 / 終了 | [作業開始](03_common-runbook/start-of-work.md) / [作業終了](03_common-runbook/end-of-work.md) |
| 金曜 (遅くとも日曜 21:00) | [週末前の破棄](03_common-runbook/pre-weekend-teardown.md) |

## 構成パターン

| # | パターン | 内容 | 実装 |
| --- | --- | --- | --- |
| 00 | [Terraform Bootstrap](04_patterns/00_terraform-bootstrap/README.md) | Bootstrap S3、Runner 用 IAM / SG、Terraform Runner (AL2023)。手動作成 | 手順 + IAM JSON + スクリプト |
| 01 | [Windows 開発用 EC2](04_patterns/01_windows-dev-ec2/README.md) | Windows Server 2022 Japanese、SMART Gateway 経由 RDP、VS Code / Git / Claude Code / Node.js / Python / Snowflake CLI | Terraform + PowerShell |
| 02 | [Linux Docker 開発用 EC2](04_patterns/02_linux-docker-dev/README.md) | AL2023、SSM のみ、Docker Engine + Compose、非 root 利用 | Terraform + Bash |
| 03 | [React + FastAPI + Snowflake](04_patterns/03_docker-react-fastapi-snowflake/README.md) | Docker Compose、FastAPI だけが Snowflake へ接続 | 実行可能なサンプル |
| 04 | [定期 ETL・バッチ](04_patterns/04_scheduled-etl/README.md) | 取得 → 変換 → 冪等 MERGE、再試行、タイムアウト | 実行可能なサンプル |
| 05 | [Web 公開構成](04_patterns/05_public-web/README.md) | ALB / API Gateway、Private Subnet、TLS、WAF | 設計のみ |

依存関係: 00 → 01 / 02 → 03 / 04。適用・破棄の順序は [Root Module 一覧](08_iac/patterns/README.md)。

## 共通文書

| 分類 | 文書 |
| --- | --- |
| 共通設計 | [索引とコンポーネント選定原則](02_common-design/README.md) / [命名とタグ](02_common-design/naming-and-tagging.md) / [ネットワーク](02_common-design/network.md) / [IAM](02_common-design/iam.md) / [Terraform と State](02_common-design/terraform-and-state.md) / [Docker 方針](02_common-design/docker-policy.md) / [バージョン固定](02_common-design/version-pinning.md) / [コード管理](02_common-design/code-management.md) |
| 共通 Runbook | [索引とスイッチロール](03_common-runbook/README.md) |
| コンポーネント | [SSM](05_components/ssm-session-manager.md) / [S3 による搬送](05_components/s3-transfer.md) / [Snowflake 接続](05_components/snowflake-connection.md) / [個人 Public GitHub](05_components/github-public.md) / [Claude Code](05_components/claude-code.md) |
| トラブルシューティング | [症状別の対処](06_troubleshooting/README.md) |
| テンプレート | [構成パターン](07_templates/pattern-readme-template.md) / [判断記録](07_templates/decision-record-template.md) |
| IaC | [Terraform の構成と実行方法](08_iac/README.md) |
| 資産・参照 | [画像・スクリーンショットのルール](10_assets/README.md) / [社内資料・外部資料](99_references/README.md) |
| 変更履歴 | [CHANGELOG](CHANGELOG.md) |

## フォルダー構成

```text
aws-sandbox-runbook/
├── README.md / CHANGELOG.md / .gitignore / .gitattributes / .claude/settings.json
├── 01_constraints/          制約、公開境界、未確定事項
├── 02_common-design/        共通設計
├── 03_common-runbook/       日次・週次の手順
├── 04_patterns/
│   ├── 00_terraform-bootstrap/   README, iam/*.json, scripts/runner-setup.sh
│   ├── 01_windows-dev-ec2/       README, terraform/, scripts/*.ps1
│   ├── 02_linux-docker-dev/      README, terraform/, scripts/*.sh
│   ├── 03_docker-react-fastapi-snowflake/  README, compose.yaml, .env.example, frontend/, api/
│   ├── 04_scheduled-etl/         README, compose.yaml, .env.example, etl/, systemd/
│   └── 05_public-web/            README (設計のみ)
├── 05_components/           共通コンポーネント手順
├── 06_troubleshooting/      トラブルシューティング
├── 07_templates/            テンプレート
├── 08_iac/                  README, bootstrap/ (backend 設定, smoke-test), patterns/ (一覧), modules/
├── 09_scripts/              検査、IaC ZIP 作成、Public 抽出
├── 10_assets/               画像のルール
└── 99_references/           参照管理
```

## 変更したら

```bash
09_scripts/check-repo.sh          # リンク、書式、Terraform fmt/validate/test、構文、秘密情報らしい値
09_scripts/check-repo.sh --full   # + コンテナ内のユニットテストとビルド
python3 09_scripts/check_repo.py placeholders   # 残っているプレースホルダーの一覧
```

## 守ること (要約)

- AWS アクセスキーを作らない・使わない。IAM ロールには必ず `ChildAccountRoleBoundary` を付ける。
- `CP-SandD*-D-*` に該当する名前を作らない。
- `terraform plan` を確認せずに `apply` しない。State と Plan は機密として扱い、Box Drive へ保存しない (許可確認まで)。
- `.env`、tfvars、`backend.hcl`、鍵、パスワード、トークンを Git・ログ・スクリーンショットに残さない。
- RDP / SSH / DB ポートをインターネット全体へ開けない。
- 週末前にすべて破棄する。AWS 上のものは正本ではない。
