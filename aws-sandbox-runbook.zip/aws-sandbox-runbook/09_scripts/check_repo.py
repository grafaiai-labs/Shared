#!/usr/bin/env python3
"""Static checks for this runbook repository (standard library only; PyYAML is used if installed).

Usage:
  python3 09_scripts/check_repo.py all            # every check below except "placeholders"
  python3 09_scripts/check_repo.py links          # relative Markdown links and #anchors exist
  python3 09_scripts/check_repo.py empty          # Markdown files with (almost) no content
  python3 09_scripts/check_repo.py json           # JSON syntax
  python3 09_scripts/check_repo.py yaml           # YAML syntax (skipped when PyYAML is missing)
  python3 09_scripts/check_repo.py secrets        # values that look like real IDs, keys or tokens
  python3 09_scripts/check_repo.py public-terms   # organisation-specific terms in public-eligible code
  python3 09_scripts/check_repo.py gitignore      # mandatory .gitignore entries
  python3 09_scripts/check_repo.py limits         # IAM policy size and EC2 user data size
  python3 09_scripts/check_repo.py placeholders   # list every <PLACEHOLDER_NAME> and where it is used

Exit code: 0 = no findings, 1 = findings, 2 = usage error.
"""

from __future__ import annotations

import ipaddress
import json
import re
import sys
from collections import defaultdict
from collections.abc import Callable, Iterator
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {".git", ".terraform", "node_modules", "dist", "build", "__pycache__", ".pytest_cache", ".ruff_cache", ".venv"}
TEXT_SUFFIXES = {
    ".md", ".tf", ".hcl", ".tftest.hcl", ".py", ".ts", ".tsx", ".json", ".yaml", ".yml", ".sh", ".ps1",
    ".example", ".toml", ".txt", ".in", ".conf", ".inc", ".service", ".timer", ".html", ".css", ".gitignore",
}
# Directories that may be exported to a public repository (see 01_constraints/security-boundary.md)
PUBLIC_ELIGIBLE = [
    "08_iac/modules",
    "08_iac/bootstrap",
    "04_patterns/00_terraform-bootstrap/scripts",
    "04_patterns/01_windows-dev-ec2/scripts",
    "04_patterns/01_windows-dev-ec2/terraform",
    "04_patterns/02_linux-docker-dev/scripts",
    "04_patterns/02_linux-docker-dev/terraform",
    "04_patterns/03_docker-react-fastapi-snowflake",
    "04_patterns/04_scheduled-etl",
]
PUBLIC_EXCLUDED_NAMES = {"README.md"}
ORG_TERMS = re.compile(r"C-MAC|CMAC|SMART[ _-]?Gateway|CP-SandD|ChildAccountRoleBoundary|ChildAdmin", re.I)

MANDATORY_GITIGNORE = """.terraform/ *.tfstate *.tfstate.* *.tfvars *.tfvars.json *.auto.tfvars *.auto.tfvars.json
backend.hcl override.tf override.tf.json *_override.tf *_override.tf.json *.tfplan crash.log crash.*.log .env .env.*
!.env.example *.pem *.key *.p12 *.pfx *.zip node_modules/ __pycache__/ .pytest_cache/ .venv/ dist/ build/""".split()

Finding = tuple[Path, int, str]


def rel(path: Path) -> str:
    return str(path.relative_to(ROOT))


LOCK_FILES = re.compile(r"^(package-lock\.json|requirements.*\.txt|\.terraform\.lock\.hcl)$")


def iter_files(suffixes: set[str], *, include_locks: bool = False) -> Iterator[Path]:
    """Yield repository files whose name ends with one of ``suffixes`` (lock files only on request)."""
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or any(part in SKIP_DIRS for part in path.relative_to(ROOT).parts):
            continue
        if LOCK_FILES.match(path.name) and not include_locks:
            continue
        if any(path.name.endswith(s) for s in suffixes):
            yield path


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


# ---------------------------------------------------------------- Markdown links

FENCE = re.compile(r"^(```|~~~)")
LINK = re.compile(r"(?<!!)\[[^\]]*\]\(([^)\s]+)(?:\s+\"[^\"]*\")?\)|!\[[^\]]*\]\(([^)\s]+)\)")
HEADING = re.compile(r"^(#{1,6})\s+(.*?)\s*#*\s*$")


def strip_code(lines: list[str]) -> Iterator[tuple[int, str]]:
    in_fence = False
    for number, line in enumerate(lines, 1):
        if FENCE.match(line.strip()):
            in_fence = not in_fence
            continue
        if not in_fence:
            yield number, re.sub(r"`[^`]*`", "", line)


def github_slug(text: str) -> str:
    text = re.sub(r"<[^>]+>", "", text)  # inline HTML
    text = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", text)  # links -> text
    text = text.replace("`", "").strip().lower()
    text = re.sub(r"[^\w\- ]", "", text)
    return text.replace(" ", "-")


def anchors_of(md: Path, cache: dict[Path, set[str]]) -> set[str]:
    if md not in cache:
        seen: dict[str, int] = defaultdict(int)
        result: set[str] = set()
        for _, line in strip_code(read(md).splitlines()):
            m = HEADING.match(line)
            if m:
                slug = github_slug(m.group(2))
                result.add(slug if seen[slug] == 0 else f"{slug}-{seen[slug]}")
                seen[slug] += 1
        cache[md] = result
    return cache[md]


def check_links() -> list[Finding]:
    findings: list[Finding] = []
    cache: dict[Path, set[str]] = {}
    for md in iter_files({".md"}):
        for number, line in strip_code(read(md).splitlines()):
            for m in LINK.finditer(line):
                target = m.group(1) or m.group(2)
                if re.match(r"^[a-z]+:", target) or target.startswith("//"):
                    continue
                path_part, _, anchor = target.partition("#")
                dest = md if not path_part else (md.parent / path_part).resolve()
                if not dest.exists():
                    findings.append((md, number, f"link target not found: {target}"))
                    continue
                if anchor:
                    if dest.suffix != ".md":
                        findings.append((md, number, f"anchor on non-Markdown target: {target}"))
                    elif anchor not in anchors_of(dest, cache):
                        findings.append((md, number, f"anchor not found: {target}"))
    return findings


def check_empty() -> list[Finding]:
    findings: list[Finding] = []
    for md in iter_files({".md"}):
        body = [ln for ln in read(md).splitlines() if ln.strip() and not ln.lstrip().startswith("#")]
        if len("".join(body)) < 200:
            findings.append((md, 1, "Markdown has almost no content (< 200 characters outside headings)"))
    return findings


# ---------------------------------------------------------------- syntax


def check_json() -> list[Finding]:
    findings: list[Finding] = []
    for path in iter_files({".json"}, include_locks=True):
        try:
            json.loads(read(path))
        except json.JSONDecodeError as exc:
            findings.append((path, exc.lineno, f"invalid JSON: {exc.msg}"))
    return findings


def check_yaml() -> list[Finding]:
    try:
        import yaml  # type: ignore[import-untyped]
    except ImportError:
        print("  (skipped: PyYAML is not installed; compose files are validated by `docker compose config`)")
        return []
    findings: list[Finding] = []
    for path in iter_files({".yaml", ".yml"}):
        try:
            yaml.safe_load(read(path))
        except yaml.YAMLError as exc:
            mark = getattr(exc, "problem_mark", None)
            findings.append((path, (mark.line + 1) if mark else 1, f"invalid YAML: {exc}"))
    return findings


# ---------------------------------------------------------------- secrets / identifiers

DUMMY_ACCOUNT = "000000000000"
DUMMY_IDS = {"0123456789abcdef0", "0fedcba9876543210"}
SECRET_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"\b(AKIA|ASIA)[0-9A-Z]{16}\b"), "AWS access key id"),
    (re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----\s*\n[A-Za-z0-9+/=]{40,}"), "private key body"),
    (re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36,}\b|\bgithub_pat_[A-Za-z0-9_]{50,}\b"), "GitHub token"),
    (re.compile(r"\bsk-ant-[A-Za-z0-9_-]{20,}"), "Anthropic API key"),
    (re.compile(r"\b[a-z0-9][a-z0-9_-]*\.(?:[a-z0-9-]+\.)?snowflakecomputing\.com\b"), "Snowflake account URL"),
    (re.compile(r"arn:aws:iam::(\d{12}):"), "IAM ARN with account id"),
    (re.compile(r"(?<![\w-])(\d{12})(?![\w-])"), "12-digit number (AWS account id?)"),
    (re.compile(r"\b(?:vpc|subnet|sg|igw|nat|eni|i|ami|vol|rtb)-([0-9a-f]{8,17})\b"), "AWS resource id"),
]
ASSIGNMENT = re.compile(r"^\s*[A-Za-z_]*(PASSWORD|PASSPHRASE|SECRET|TOKEN)[A-Za-z_]*\s*[=:]\s*[\"']?([^\s\"'#]+)", re.I)
IPV4 = re.compile(r"(?<![\d.])(\d{1,3}(?:\.\d{1,3}){3})(?:/\d{1,2})?(?![\d.])")


def check_secrets() -> list[Finding]:
    findings: list[Finding] = []
    for path in iter_files(TEXT_SUFFIXES):
        text = read(path)
        for pattern, label in SECRET_PATTERNS:
            for m in pattern.finditer(text):
                value = m.group(1) if m.groups() else m.group(0)
                if value in {DUMMY_ACCOUNT, *DUMMY_IDS}:
                    continue
                line = text.count("\n", 0, m.start()) + 1
                findings.append((path, line, f"{label}: {m.group(0)[:40]}"))
        config_like = path.suffix in {".hcl", ".tfvars", ".yaml", ".yml", ".example", ".toml"} or path.name.startswith(".env")
        for number, line in enumerate(text.splitlines(), 1):
            if config_like:
                m = ASSIGNMENT.match(line)
                if m and not re.match(r"^(<[A-Z0-9_]+>|/|\$|\{|null$|true$|false$)", m.group(2)):
                    findings.append((path, number, f"literal value for secret-like key: {line.strip()[:60]}"))
            for m in IPV4.finditer(line):
                try:
                    ip = ipaddress.ip_address(m.group(1))
                except ValueError:
                    continue
                documentation = any(ip in ipaddress.ip_network(n) for n in ("192.0.2.0/24", "198.51.100.0/24", "203.0.113.0/24"))
                if ip.is_global and not documentation:
                    findings.append((path, number, f"public IPv4 address: {m.group(0)}"))
    return findings


def check_public_terms() -> list[Finding]:
    findings: list[Finding] = []
    for base in PUBLIC_ELIGIBLE:
        for path in sorted((ROOT / base).rglob("*")):
            if not path.is_file() or path.name in PUBLIC_EXCLUDED_NAMES:
                continue
            if any(part in SKIP_DIRS for part in path.relative_to(ROOT).parts) or LOCK_FILES.match(path.name):
                continue
            for number, line in enumerate(read(path).splitlines(), 1):
                if ORG_TERMS.search(line):
                    findings.append((path, number, f"organisation-specific term in public-eligible file: {line.strip()[:60]}"))
    return findings


def check_gitignore() -> list[Finding]:
    lines = {ln.strip() for ln in read(ROOT / ".gitignore").splitlines()}
    return [(ROOT / ".gitignore", 1, f"missing mandatory entry: {e}") for e in MANDATORY_GITIGNORE if e not in lines]


def check_limits() -> list[Finding]:
    findings: list[Finding] = []
    for path in sorted((ROOT / "04_patterns/00_terraform-bootstrap/iam").glob("*.json")):
        size = len(re.sub(r"\s", "", read(path)))
        limit = 20480 if "bucket-policy" in path.name else 6144
        if size > limit:
            findings.append((path, 1, f"policy is {size} characters (limit {limit} without whitespace)"))
    win = ROOT / "04_patterns/01_windows-dev-ec2/scripts/Initialize-WindowsDev.ps1"
    lin = ROOT / "04_patterns/02_linux-docker-dev/scripts/bootstrap-linux-docker.sh"
    win_size = len(f"<powershell>\n{read(win)}\n</powershell>\n<persist>false</persist>\n".encode())
    lin_size = len(("#!/bin/bash\n" + "x" * 300 + "\n" + read(lin)).encode())
    for path, size in ((win, win_size), (lin, lin_size)):
        if size > 16384:
            findings.append((path, 1, f"EC2 user data would be {size} bytes (limit 16384)"))
    for path in iter_files({".ps1"}):
        data = path.read_bytes()
        if any(b > 127 for b in data):
            message = "PowerShell script must be ASCII only (Windows PowerShell 5.1 reads BOM-less files as ANSI)"
            findings.append((path, 1, message))
    return findings


# ---------------------------------------------------------------- placeholders

PLACEHOLDER = re.compile(r"<([A-Z][A-Z0-9_]{2,})>")


def list_placeholders() -> int:
    usage: dict[str, set[str]] = defaultdict(set)
    for path in iter_files(TEXT_SUFFIXES):
        for m in PLACEHOLDER.finditer(read(path)):
            usage[m.group(1)].add(rel(path))
    for name in sorted(usage):
        files = sorted(usage[name])
        shown = ", ".join(files[:3]) + (f", ... (+{len(files) - 3})" if len(files) > 3 else "")
        print(f"<{name}>\t{len(files)} file(s)\t{shown}")
    print(f"\n{len(usage)} distinct placeholders")
    return 0


CHECKS: dict[str, Callable[[], list[Finding]]] = {
    "links": check_links,
    "empty": check_empty,
    "json": check_json,
    "yaml": check_yaml,
    "secrets": check_secrets,
    "public-terms": check_public_terms,
    "gitignore": check_gitignore,
    "limits": check_limits,
}


def main(argv: list[str]) -> int:
    if len(argv) != 2 or argv[1] not in {*CHECKS, "all", "placeholders"}:
        print(__doc__)
        return 2
    if argv[1] == "placeholders":
        return list_placeholders()
    names = list(CHECKS) if argv[1] == "all" else [argv[1]]
    total = 0
    for name in names:
        findings = CHECKS[name]()
        print(f"[{'OK' if not findings else 'NG'}] {name}: {len(findings)} finding(s)")
        for path, line, message in findings:
            print(f"    {rel(path)}:{line}: {message}")
        total += len(findings)
    return 1 if total else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
