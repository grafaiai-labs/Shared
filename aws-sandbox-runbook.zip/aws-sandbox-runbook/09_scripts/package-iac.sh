#!/bin/bash
# =============================================================================
# 非公開 IaC ZIP の作成 (社内 PC の Git Bash / Linux / macOS)
#
#   09_scripts/package-iac.sh
#
# 含めるもの : Runner で使う IaC (Git 管理対象 + 未追跡の非無視ファイル)
#              + Git 管理外の backend.hcl / terraform.tfvars
# 含めないもの: State、Plan、.terraform/、.env、secrets/、鍵
# 出力        : dist/iac/iac-<日時>.zip と SHA256 (ZIP は .gitignore 対象)
#
# Windows PowerShell の場合は New-IacPackage.ps1 を使う。
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")/.."

INCLUDE=(
  08_iac
  04_patterns/00_terraform-bootstrap/scripts
  04_patterns/01_windows-dev-ec2
  04_patterns/02_linux-docker-dev
  09_scripts
)
PRIVATE=(
  08_iac/bootstrap/backend.hcl
  08_iac/bootstrap/smoke-test/terraform.tfvars
  04_patterns/01_windows-dev-ec2/terraform/terraform.tfvars
  04_patterns/02_linux-docker-dev/terraform/terraform.tfvars
)
EXCLUDE_RE='(^|/)\.terraform/|\.tfstate|\.tfplan$|(^|/)\.env$|(^|/)secrets/|\.(pem|key|p8|p12|pfx|zip|bundle)$|\.local\.json$'

git rev-parse --is-inside-work-tree >/dev/null 2>&1 || { echo "Git リポジトリで実行してください (git init 済みであること)" >&2; exit 1; }

[[ -f 08_iac/bootstrap/backend.hcl ]] || { echo "08_iac/bootstrap/backend.hcl がありません (backend.hcl.example からコピーして記入)" >&2; exit 1; }

# 非公開ファイルにプレースホルダーが残っていれば中止する (値は表示せず、名前だけを表示)
leftover=0
for f in "${PRIVATE[@]}"; do
  if [[ -f "${f}" ]]; then
    # コメント行 (# / //) は切替用の例なので対象外
    names="$(grep -vE '^[[:space:]]*(#|//)' "${f}" | grep -oE '<[A-Z0-9_]+>' | sort -u | tr '\n' ' ' || true)"
    if [[ -n "${names}" ]]; then
      echo "未記入のプレースホルダー: ${f}: ${names}" >&2
      leftover=1
    fi
  else
    echo "注意: ${f} がありません (そのパターンを使わない場合は問題なし)" >&2
  fi
done
[[ "${leftover}" -eq 0 ]] || { echo "プレースホルダーを実値に置き換えてから再実行してください" >&2; exit 1; }

files=()
while IFS= read -r f; do files+=("$f"); done < <(
  { git ls-files --cached --others --exclude-standard -- "${INCLUDE[@]}"
    for f in "${PRIVATE[@]}"; do [[ -f "${f}" ]] && echo "${f}"; done
  } | grep -Ev "${EXCLUDE_RE}" | sort -u
)

mkdir -p dist/iac
out="dist/iac/iac-$(date +%Y%m%d-%H%M%S).zip"
if command -v zip >/dev/null 2>&1; then
  zip -q -X "${out}" "${files[@]}"
elif command -v python3 >/dev/null 2>&1; then
  python3 - "${out}" "${files[@]}" <<'PY'
import sys, zipfile
with zipfile.ZipFile(sys.argv[1], "w", zipfile.ZIP_DEFLATED) as z:
    for name in sys.argv[2:]:
        z.write(name, name)
PY
else
  echo "zip または python3 が必要です。Windows では New-IacPackage.ps1 を使ってください" >&2
  exit 1
fi

if command -v sha256sum >/dev/null 2>&1; then
  sha="$(sha256sum "${out}" | awk '{print $1}')"
else
  sha="$(shasum -a 256 "${out}" | awk '{print $1}')"
fi
echo "files : ${#files[@]}"
echo "zip   : ${out}"
echo "sha256: ${sha}"
echo "次の手順: S3 の iac/ へアップロードし、Runner で iac-fetch s3://<BOOTSTRAP_BUCKET_NAME>/iac/$(basename "${out}") ${sha}"
