#Requires -Version 5.1
<#
.SYNOPSIS
  Create the private IaC ZIP for the Terraform runner (Windows PowerShell version of package-iac.sh).

.DESCRIPTION
  Includes : IaC files tracked or untracked-but-not-ignored by Git, plus the private
             backend.hcl / terraform.tfvars files that are ignored by Git.
  Excludes : Terraform state, plans, .terraform/, .env, secrets/, keys.
  Output   : dist\iac\iac-<timestamp>.zip and its SHA256.
  Stops if a private file still contains <PLACEHOLDER> values (only the names are printed).

.EXAMPLE
  powershell -NoProfile -ExecutionPolicy Bypass -File .\09_scripts\New-IacPackage.ps1
#>
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$Include = @(
  '08_iac',
  '04_patterns/00_terraform-bootstrap/scripts',
  '04_patterns/01_windows-dev-ec2',
  '04_patterns/02_linux-docker-dev',
  '09_scripts'
)
$Private = @(
  '08_iac/bootstrap/backend.hcl',
  '08_iac/bootstrap/smoke-test/terraform.tfvars',
  '04_patterns/01_windows-dev-ec2/terraform/terraform.tfvars',
  '04_patterns/02_linux-docker-dev/terraform/terraform.tfvars'
)
$ExcludeRe = '(^|/)\.terraform/|\.tfstate|\.tfplan$|(^|/)\.env$|(^|/)secrets/|\.(pem|key|p8|p12|pfx|zip|bundle)$|\.local\.json$'

& git rev-parse --is-inside-work-tree *> $null
if ($LASTEXITCODE -ne 0) { throw 'Run inside the Git repository (git init first).' }
if (-not (Test-Path '08_iac/bootstrap/backend.hcl')) {
  throw '08_iac/bootstrap/backend.hcl is missing. Copy backend.hcl.example and fill in the bucket name.'
}

$leftover = $false
foreach ($f in $Private) {
  if (Test-Path $f) {
    # Comment lines (# or //) hold optional examples and are ignored
    $names = Get-Content -Path $f | Where-Object { $_ -notmatch '^\s*(#|//)' } |
      Select-String -Pattern '<[A-Z0-9_]+>' -AllMatches |
      ForEach-Object { $_.Matches.Value } | Sort-Object -Unique
    if ($names) {
      Write-Warning ("Unfilled placeholders in {0}: {1}" -f $f, ($names -join ' '))
      $leftover = $true
    }
  } else {
    Write-Warning "$f not found (fine if you do not use that pattern)"
  }
}
if ($leftover) { throw 'Replace the placeholders with real values and run again.' }

$tracked = & git ls-files --cached --others --exclude-standard -- $Include
if ($LASTEXITCODE -ne 0) { throw 'git ls-files failed' }
$files = @($tracked) + @($Private | Where-Object { Test-Path $_ }) |
  ForEach-Object { $_ -replace '\\', '/' } |
  Where-Object { $_ -and ($_ -notmatch $ExcludeRe) } |
  Sort-Object -Unique

New-Item -ItemType Directory -Force -Path 'dist/iac' | Out-Null
$out = Join-Path (Resolve-Path 'dist/iac') ('iac-{0}.zip' -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
$zip = [System.IO.Compression.ZipFile]::Open($out, [System.IO.Compression.ZipArchiveMode]::Create)
try {
  foreach ($f in $files) {
    [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, (Resolve-Path $f), $f)
  }
} finally {
  $zip.Dispose()
}

$sha = (Get-FileHash -Path $out -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Output ('files : {0}' -f $files.Count)
Write-Output ('zip   : {0}' -f $out)
Write-Output ('sha256: {0}' -f $sha)
Write-Output ('next  : upload to s3://<BOOTSTRAP_BUCKET_NAME>/iac/ then run on the runner: iac-fetch s3://<BOOTSTRAP_BUCKET_NAME>/iac/{0} {1}' -f (Split-Path -Leaf $out), $sha)
