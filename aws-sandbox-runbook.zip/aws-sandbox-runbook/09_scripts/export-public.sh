#!/bin/bash
# =============================================================================
# Public GitHub 用の抽出
#
#   09_scripts/export-public.sh <EXPORT_DIR>
#
# 許可リストのパスだけを <EXPORT_DIR> へコピーし、組織固有の語・実在しうる ID・
# 秘密情報らしい値が含まれていないことを検査する。検査に失敗した場合は終了コード 1。
# <EXPORT_DIR> はリポジトリの外の、存在しないか空のディレクトリを指定する。
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")/.."
REPO="$(pwd)"

dest="${1:?usage: export-public.sh <EXPORT_DIR>}"
mkdir -p "${dest}"
dest="$(cd "${dest}" && pwd)"
case "${dest}/" in "${REPO}/"*) echo "抽出先はリポジトリの外にしてください" >&2; exit 1 ;; esac
[[ -z "$(ls -A "${dest}")" ]] || { echo "抽出先が空ではありません: ${dest}" >&2; exit 1; }

ALLOW=(
  .gitignore
  .gitattributes
  .claude/settings.json
  08_iac/modules
  08_iac/bootstrap/backend.hcl.example
  08_iac/bootstrap/smoke-test
  04_patterns/00_terraform-bootstrap/scripts
  04_patterns/01_windows-dev-ec2/scripts
  04_patterns/01_windows-dev-ec2/terraform
  04_patterns/02_linux-docker-dev/scripts
  04_patterns/02_linux-docker-dev/terraform
  04_patterns/03_docker-react-fastapi-snowflake
  04_patterns/04_scheduled-etl
)
# パターンの README (組織固有の運用情報を含む) は抽出しない
DENY_RE='^04_patterns/[^/]+/README\.md$'

git rev-parse --is-inside-work-tree >/dev/null 2>&1 || { echo "Git リポジトリで実行してください" >&2; exit 1; }
files=()
while IFS= read -r f; do files+=("$f"); done < <(
  git ls-files --cached --others --exclude-standard -- "${ALLOW[@]}" | grep -Ev "${DENY_RE}" | sort -u
)
tar -cf - "${files[@]}" | tar -xf - -C "${dest}"

# ---- 検査 -------------------------------------------------------------------
fail=0
# テスト用のダミー値 (000000000000 / vpc-0123456789abcdef0 など) は除外する
DUMMY_RE='000000000000|0123456789abcdef0|0fedcba9876543210'
scan() {
  local label="$1" pattern="$2"
  local hits
  hits="$(grep -rInE "${pattern}" "${dest}" --exclude=package-lock.json --exclude='requirements*.txt' --exclude=.terraform.lock.hcl \
    | grep -Ev "${DUMMY_RE}" || true)"
  if [[ -n "${hits}" ]]; then
    echo "NG: ${label}"
    echo "${hits}" | sed "s#${dest}/#  #" | cut -c1-160
    fail=1
  else
    echo "OK: ${label}"
  fi
}
scan "組織固有の語" 'C-MAC|CMAC|SMART[ _-]?Gateway|CP-SandD|ChildAccountRoleBoundary|ChildAdmin'
scan "12 桁の数字 (アカウント ID)" '(^|[^0-9A-Za-z_-])[0-9]{12}([^0-9A-Za-z_-]|$)'
scan "実在形式のリソース ID" '\b(vpc|subnet|sg|igw|i|ami)-[0-9a-f]{8,17}\b'
scan "秘密鍵・トークン" 'BEGIN [A-Z ]*PRIVATE KEY-----$|AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{36}|github_pat_'
for f in terraform.tfvars backend.hcl .env; do
  if find "${dest}" -name "${f}" | grep -q .; then echo "NG: ${f} が含まれています"; fail=1; fi
done

if [[ "${fail}" -ne 0 ]]; then
  echo "検査に失敗しました。${dest} を削除し、原因を修正してから再実行してください。" >&2
  exit 1
fi
echo "files: ${#files[@]} -> ${dest}"
echo "README.md は Public 向けに別途作成してください (ランブックの README は抽出していません)。"
