#!/bin/bash
# =============================================================================
# リポジトリ全体の検査 (AWS へは接続しない)
#
#   09_scripts/check-repo.sh           # 静的検査 + Terraform + 構文検査
#   09_scripts/check-repo.sh --full    # 上記 + コンテナ内のテスト (pytest / vitest / ビルド)
#
# 必要なツールがない検査は SKIP と理由を表示し、失敗扱いにしない。
# 終了コード: 0 = すべて成功 (SKIP を含む), 1 = 失敗あり
# =============================================================================
set -uo pipefail

cd "$(dirname "$0")/.." || exit 1
FULL=0
[[ "${1:-}" == "--full" ]] && FULL=1

SHELLCHECK_IMAGE="koalaman/shellcheck:v0.11.0"
PWSH_IMAGE="mcr.microsoft.com/dotnet/sdk:10.0.401"

failed=()
skipped=()

section() { printf '\n==== %s\n' "$1"; }
ok() { printf 'PASS  %s\n' "$1"; }
ng() { printf 'FAIL  %s\n' "$1"; failed+=("$1"); }
skip() { printf 'SKIP  %s (%s)\n' "$1" "$2"; skipped+=("$1: $2"); }
check() { local name="$1"; shift; if "$@"; then ok "${name}"; else ng "${name}"; fi; }
has() { command -v "$1" >/dev/null 2>&1; }
docker_ok() { has docker && docker info >/dev/null 2>&1; }

TF_ROOTS=(
  08_iac/bootstrap/smoke-test
  04_patterns/01_windows-dev-ec2/terraform
  04_patterns/02_linux-docker-dev/terraform
)
TF_TESTS=(
  08_iac/modules/ssm-instance-role
  08_iac/modules/windows-dev-ec2
  08_iac/modules/linux-docker-host
  04_patterns/01_windows-dev-ec2/terraform
  04_patterns/02_linux-docker-dev/terraform
)
# bash 3.2 (macOS 標準) でも動くように mapfile を使わない
list_files() { find . -name "$1" -not -path '*/node_modules/*' -not -path '*/.terraform/*' | sort; }
SH_FILES=(); while IFS= read -r f; do SH_FILES+=("$f"); done < <(list_files '*.sh')
PS_FILES=(); while IFS= read -r f; do PS_FILES+=("$f"); done < <(list_files '*.ps1')
COMPOSE_FILES=(); while IFS= read -r f; do COMPOSE_FILES+=("$f"); done < <(list_files 'compose.yaml')

# ---------------------------------------------------------------------------
section "Markdown / JSON / YAML / 秘密情報 / 公開境界 / .gitignore / サイズ上限"
if has python3; then
  check "check_repo.py all" python3 09_scripts/check_repo.py all
else
  skip "check_repo.py" "python3 not found"
fi

# ---------------------------------------------------------------------------
section "Terraform"
if has terraform; then
  check "terraform fmt -check -recursive" terraform fmt -check -recursive .
  for d in "${TF_ROOTS[@]}"; do
    check "terraform validate ${d}" bash -c "cd '${d}' && terraform init -backend=false -input=false -no-color >/dev/null && terraform validate -no-color >/dev/null"
  done
  for d in "${TF_TESTS[@]}"; do
    check "terraform test ${d}" bash -c "cd '${d}' && terraform init -backend=false -input=false -no-color >/dev/null && terraform test -no-color >/dev/null"
  done
else
  skip "terraform fmt / validate / test" "terraform not found. Install 1.16.4 and rerun"
fi

# ---------------------------------------------------------------------------
section "Shell"
for f in "${SH_FILES[@]}"; do
  check "bash -n ${f}" bash -n "${f}"
done
if has shellcheck; then
  check "shellcheck" shellcheck -S warning "${SH_FILES[@]}"
elif docker_ok; then
  check "shellcheck (${SHELLCHECK_IMAGE})" docker run --rm -v "${PWD}:/mnt:ro" -w /mnt "${SHELLCHECK_IMAGE}" -S warning "${SH_FILES[@]}"
else
  skip "shellcheck" "shellcheck and docker not available"
fi

# ---------------------------------------------------------------------------
section "PowerShell (構文解析)"
PS_PARSE='$bad = 0; foreach ($f in $args) { $t = $null; $e = $null; [void][System.Management.Automation.Language.Parser]::ParseFile((Resolve-Path $f), [ref]$t, [ref]$e); if ($e) { $bad++; $e | ForEach-Object { Write-Output ("{0}:{1}: {2}" -f $f, $_.Extent.StartLineNumber, $_.Message) } } }; exit $bad'
if has pwsh; then
  check "PowerShell parse" pwsh -NoProfile -Command "& { ${PS_PARSE} }" "${PS_FILES[@]}"
elif docker_ok; then
  check "PowerShell parse (${PWSH_IMAGE})" docker run --rm -v "${PWD}:/mnt:ro" -w /mnt "${PWSH_IMAGE}" pwsh -NoProfile -Command "& { ${PS_PARSE} }" "${PS_FILES[@]}"
else
  skip "PowerShell parse" "pwsh and docker not available"
fi

# ---------------------------------------------------------------------------
section "Docker Compose"
if docker_ok && docker compose version >/dev/null 2>&1; then
  for f in "${COMPOSE_FILES[@]}"; do
    check "docker compose config ${f}" docker compose -f "${f}" config -q
  done
else
  skip "docker compose config" "docker compose not available"
fi

# ---------------------------------------------------------------------------
if [[ "${FULL}" -eq 1 ]]; then
  section "コンテナ内のテスト (--full)"
  if docker_ok; then
    check "api: ruff + pytest" docker build -q --target test 04_patterns/03_docker-react-fastapi-snowflake/api
    check "etl: ruff + pytest" docker build -q --target test 04_patterns/04_scheduled-etl/etl
    check "frontend: vitest + tsc + vite build" docker build -q 04_patterns/03_docker-react-fastapi-snowflake/frontend
  else
    skip "container tests" "docker not available"
  fi
fi

# ---------------------------------------------------------------------------
section "結果"
printf 'FAIL: %d  SKIP: %d\n' "${#failed[@]}" "${#skipped[@]}"
for f in ${failed[@]+"${failed[@]}"}; do printf '  FAIL %s\n' "${f}"; done
for s in ${skipped[@]+"${skipped[@]}"}; do printf '  SKIP %s\n' "${s}"; done
[[ "${#failed[@]}" -eq 0 ]]
