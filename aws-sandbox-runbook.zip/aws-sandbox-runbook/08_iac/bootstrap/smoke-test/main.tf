# Runner と S3 Backend の疎通確認用 Root Module。
# AWS 上には何も作成しない (terraform_data は State 内だけに存在する)。
# 確認内容:
#   1. インスタンスロールで AWS API を呼べること
#   2. S3 Backend へ State を書き込み、Lockfile (.tflock) を作成・解放できること
#   3. 指定した Subnet の経路 (IGW / NAT) を読み取り、Public / Private の判定材料を得ること

provider "aws" {
  region              = "ap-northeast-1"
  allowed_account_ids = [var.aws_account_id]
}

variable "aws_account_id" {
  description = "操作対象の AWS アカウント ID。"
  type        = string

  validation {
    condition     = can(regex("^[0-9]{12}$", var.aws_account_id))
    error_message = "aws_account_id は 12 桁の数字で指定してください。"
  }
}

variable "vpc_id" {
  description = "確認対象 VPC の ID。"
  type        = string
}

variable "subnet_ids" {
  description = "経路を確認する Subnet ID (Public / Private 候補)。"
  type        = list(string)
  default     = []
}

data "aws_caller_identity" "current" {}

data "aws_region" "current" {}

data "aws_vpc" "target" {
  id = var.vpc_id
}

data "aws_subnet" "target" {
  for_each = toset(var.subnet_ids)
  id       = each.value
}

# 明示的に関連付けられたルートテーブル。なければ VPC のメインルートテーブルを使う。
data "aws_route_tables" "explicit" {
  for_each = toset(var.subnet_ids)
  vpc_id   = var.vpc_id

  filter {
    name   = "association.subnet-id"
    values = [each.value]
  }
}

data "aws_route_tables" "main" {
  vpc_id = var.vpc_id

  filter {
    name   = "association.main"
    values = ["true"]
  }
}

data "aws_route_table" "effective" {
  for_each       = toset(var.subnet_ids)
  route_table_id = length(data.aws_route_tables.explicit[each.value].ids) > 0 ? data.aws_route_tables.explicit[each.value].ids[0] : data.aws_route_tables.main.ids[0]
}

resource "terraform_data" "smoke" {
  input = "backend-write-check"
}

check "region" {
  assert {
    condition     = data.aws_region.current.region == "ap-northeast-1"
    error_message = "リージョンが ap-northeast-1 ではありません。"
  }
}

output "caller_arn_role_name" {
  description = "呼び出し元のロール名部分 (アカウント ID は表示しない)。"
  value       = element(split("/", data.aws_caller_identity.current.arn), 1)
}

output "vpc_cidr" {
  description = "VPC の CIDR。"
  value       = data.aws_vpc.target.cidr_block
}

output "subnet_routes" {
  description = "Subnet ごとの判定材料。default_route_via が igw なら Public、nat なら NAT 経由の Private。"
  value = {
    for id in var.subnet_ids : id => {
      availability_zone       = data.aws_subnet.target[id].availability_zone
      map_public_ip_on_launch = data.aws_subnet.target[id].map_public_ip_on_launch
      default_route_via = one(concat([
        for r in data.aws_route_table.effective[id].routes :
        r.gateway_id != "" && startswith(r.gateway_id, "igw-") ? "igw" :
        r.nat_gateway_id != "" ? "nat" :
        r.transit_gateway_id != "" ? "transit-gateway" :
        r.vpc_endpoint_id != "" ? "vpc-endpoint" :
        r.network_interface_id != "" ? "eni" : "other"
        if r.cidr_block == "0.0.0.0/0"
      ], length([for r in data.aws_route_table.effective[id].routes : r if r.cidr_block == "0.0.0.0/0"]) == 0 ? ["none"] : []))
    }
  }
}
