# bucket は backend.hcl (Git 管理外) から -backend-config で渡す。
terraform {
  backend "s3" {
    key          = "state/00_smoke-test/terraform.tfstate"
    region       = "ap-northeast-1"
    encrypt      = true
    use_lockfile = true
  }
}
