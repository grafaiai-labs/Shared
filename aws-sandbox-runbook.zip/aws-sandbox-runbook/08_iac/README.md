# IaC (Terraform)

Terraform 関連の置き場所と、ローカル・Runner での実行方法。設計方針は [Terraform と State](../02_common-design/terraform-and-state.md) を参照。

## 1. 構成

| パス | 内容 | 公開可否 |
| --- | --- | --- |
| [bootstrap/backend.hcl.example](bootstrap/backend.hcl.example) | 全 Root Module 共通の Backend 設定の雛形 (bucket のみ) | Public 可。コピーした `backend.hcl` は Git 管理外 |
| [bootstrap/smoke-test/](bootstrap/smoke-test/main.tf) | Runner と Backend の疎通確認 (AWS リソースを作らない) | Public 可 |
| [modules/ssm-instance-role/](modules/ssm-instance-role/main.tf) | EC2 用ロール + インスタンスプロファイル (Boundary 必須、SSM Core、退避用 S3 プレフィックス) | Public 可 |
| [modules/windows-dev-ec2/](modules/windows-dev-ec2/main.tf) | Windows 開発用 EC2 (公式 AMI 検索、RDP 許可元の検証、IMDSv2、gp2) | Public 可 |
| [modules/linux-docker-host/](modules/linux-docker-host/main.tf) | Linux Docker ホスト (インバウンドなし、SG 参照のみの任意受信、IMDS hop 1) | Public 可 |
| [patterns/](patterns/README.md) | Root Module の一覧、State キー、依存関係、適用・破棄の順序 | 非公開 |

Root Module 本体は各パターンのディレクトリ (`04_patterns/0[12]_*/terraform/`) にある。Bootstrap リソース (S3、Runner、Runner 用 IAM / SG) は Terraform 管理外。

## 2. バージョン

| 対象 | Root Module | 再利用 Module |
| --- | --- | --- |
| Terraform | `= 1.16.4` | `>= 1.10.0, < 2.0.0` |
| AWS Provider | `= 6.66.0` | `>= 6.0.0, < 7.0.0` |

Root Module で完全一致に固定し、Module は互換範囲だけを宣言する。`.terraform.lock.hcl` は Root Module ごとに Git 管理する (`linux_amd64`、`darwin_arm64`、`darwin_amd64`、`windows_amd64` のハッシュを含む)。

## 3. AWS に接続しない検査 (どこでも実行可)

```bash
# リポジトリのルートで
terraform fmt -check -recursive .
for d in 08_iac/bootstrap/smoke-test 04_patterns/01_windows-dev-ec2/terraform 04_patterns/02_linux-docker-dev/terraform; do
  (cd "$d" && terraform init -backend=false -input=false >/dev/null && terraform validate)
done
# モック Provider によるテスト (Module と Root Module)
for d in 08_iac/modules/ssm-instance-role 08_iac/modules/windows-dev-ec2 08_iac/modules/linux-docker-host \
         04_patterns/01_windows-dev-ec2/terraform 04_patterns/02_linux-docker-dev/terraform; do
  (cd "$d" && terraform init -backend=false -input=false >/dev/null && terraform test)
done
```

まとめて実行する場合は [09_scripts/check-repo.sh](../09_scripts/check-repo.sh)。

## 4. Runner での実行

```bash
cd ~/iac/current/<ROOT_MODULE_DIR>
terraform init -input=false -backend-config=<08_iac/bootstrap/backend.hcl への相対パス>
terraform plan -out=run.tfplan
terraform apply run.tfplan
rm -f run.tfplan
```

## 5. 非公開の設定ファイル

| ファイル | 雛形 | 置き場所 |
| --- | --- | --- |
| `08_iac/bootstrap/backend.hcl` | `backend.hcl.example` | 社内 PC の作業ツリー (Git 管理外)。IaC ZIP に含める |
| `08_iac/bootstrap/smoke-test/terraform.tfvars` | `terraform.tfvars.example` | 同上 |
| `04_patterns/01_windows-dev-ec2/terraform/terraform.tfvars` | 同上 | 同上 |
| `04_patterns/02_linux-docker-dev/terraform/terraform.tfvars` | 同上 | 同上 |

IaC ZIP の作成: [09_scripts/package-iac.sh](../09_scripts/package-iac.sh) / [New-IacPackage.ps1](../09_scripts/New-IacPackage.ps1)。
