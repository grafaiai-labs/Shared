# Root Module 一覧と適用順序

Terraform を実行するパターンの一覧。新しいパターンを追加したら、この表を更新する。

## 1. 一覧

| パターン | Root Module | State キー | 主なリソース | 依存 |
| --- | --- | --- | --- | --- |
| 00 smoke-test | [08_iac/bootstrap/smoke-test](../bootstrap/smoke-test/main.tf) | `state/00_smoke-test/terraform.tfstate` | なし (`terraform_data` のみ) | Bootstrap (手動) |
| 01 Windows 開発用 EC2 | [04_patterns/01_windows-dev-ec2/terraform](../../04_patterns/01_windows-dev-ec2/terraform/main.tf) | `state/01_windows-dev-ec2/terraform.tfstate` | IAM ロール、SG、キーペア、EC2 | Bootstrap |
| 02 Linux Docker 開発用 EC2 | [04_patterns/02_linux-docker-dev/terraform](../../04_patterns/02_linux-docker-dev/terraform/main.tf) | `state/02_linux-docker-dev/terraform.tfstate` | IAM ロール、SG、EC2 | Bootstrap。`app_ingress_source_security_group_ids` 指定時は 01 の SG |
| 03 React + FastAPI + Snowflake | なし (Docker Compose) | - | - | 02 |
| 04 定期 ETL | なし (Docker Compose + systemd) | - | - | 02 |
| 05 Web 公開 | 未実装 | (予定) `state/05_public-web/terraform.tfstate` | ALB、WAF、ACM、EC2 | 02 の構成を流用 |

## 2. 適用順序 (週末後)

```mermaid
flowchart LR
  B["Bootstrap (手動)"] --> S["00 smoke-test"] --> W["01 Windows"] --> L["02 Linux"] --> A["03 / 04 アプリ"]
```

01 と 02 は独立しているため、Windows を使わない週は 01 を省略できる (02 で Windows SG を参照しない場合)。

## 3. 破棄順序 (週末前)

```mermaid
flowchart LR
  A["03 / 04 アプリ停止"] --> L["02 destroy"] --> W["01 destroy"] --> S["00 smoke-test destroy"] --> B["Bootstrap 手動削除<br/>Runner → SG → S3 → IAM"]
```

- 02 が 01 の SG を参照している場合、01 を先に destroy すると SG の削除が依存関係エラーになる。
- Runner は destroy を実行するため最後に削除する。
