# terraform init && terraform test (モック Provider。AWS へ接続しない)

mock_provider "aws" {
  mock_data "aws_ami" {
    defaults = { id = "ami-0123456789abcdef0", name = "Windows_Server-2022-Japanese-Full-Base-2026.09.10" }
  }
}

variables {
  name                      = "tester-windev-ec2-01"
  vpc_id                    = "vpc-0123456789abcdef0"
  subnet_id                 = "subnet-0123456789abcdef0"
  rdp_allowed_cidrs         = ["192.0.2.10/32", "198.51.100.0/28"]
  key_name                  = "tester-windev-key-01"
  public_key_openssh        = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDexample tester"
  iam_instance_profile_name = "tester-windev-role-01"
}

run "secure_defaults" {
  command = plan

  assert {
    condition     = length(aws_vpc_security_group_ingress_rule.rdp) == 2
    error_message = "RDP ルールは許可 CIDR ごとに 1 件だけ作成すること。"
  }
  assert {
    condition     = alltrue([for r in aws_vpc_security_group_ingress_rule.rdp : r.from_port == 3389 && r.to_port == 3389 && r.cidr_ipv4 != "0.0.0.0/0"])
    error_message = "RDP 以外のポート、または全開放のルールがある。"
  }
  assert {
    condition     = aws_instance.this.instance_type == "t3.medium"
    error_message = "既定のインスタンスタイプは t3.medium。"
  }
  assert {
    condition     = aws_instance.this.associate_public_ip_address == true
    error_message = "Public IPv4 を付与すること。"
  }
  assert {
    condition     = aws_instance.this.metadata_options[0].http_tokens == "required"
    error_message = "IMDSv2 を必須にすること。"
  }
  assert {
    condition     = aws_instance.this.root_block_device[0].volume_type == "gp2" && aws_instance.this.root_block_device[0].encrypted == true
    error_message = "ルート EBS は gp2 かつ暗号化すること。"
  }
  assert {
    condition     = aws_key_pair.this[0].key_name == "tester-windev-key-01"
    error_message = "公開鍵指定時はキーペアを作成すること。"
  }
}

run "existing_key_pair" {
  command = plan

  variables {
    public_key_openssh = null
  }

  assert {
    condition     = length(aws_key_pair.this) == 0 && aws_instance.this.key_name == "tester-windev-key-01"
    error_message = "公開鍵未指定時は既存キーペア名を参照すること。"
  }
}

run "open_rdp_rejected" {
  command = plan
  variables {
    rdp_allowed_cidrs = ["0.0.0.0/0"]
  }
  expect_failures = [var.rdp_allowed_cidrs]
}

run "wide_rdp_rejected" {
  command = plan
  variables {
    rdp_allowed_cidrs = ["10.0.0.0/8"]
  }
  expect_failures = [var.rdp_allowed_cidrs]
}

run "non_rsa_key_rejected" {
  command = plan
  variables {
    public_key_openssh = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIexample tester"
  }
  expect_failures = [var.public_key_openssh]
}

run "gp3_rejected" {
  command = plan
  variables {
    root_volume_type = "gp3"
  }
  expect_failures = [var.root_volume_type]
}
