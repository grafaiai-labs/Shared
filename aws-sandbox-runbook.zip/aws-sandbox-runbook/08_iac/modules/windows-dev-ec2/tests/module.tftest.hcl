# terraform init && terraform test (モック Provider。AWS へ接続しない)

mock_provider "aws" {
  mock_data "aws_ami" {
    defaults = { id = "ami-0123456789abcdef0", name = "Windows_Server-2022-Japanese-Full-Base-2026.09.10" }
  }
}

# gateway_allowed_cidrs は実環境と同じく接続ゲートウェイの送信元 3 件 (/32) を想定する。値は RFC 5737 のドキュメント用アドレス
variables {
  name                      = "tester-windev-ec2-01"
  vpc_id                    = "vpc-0123456789abcdef0"
  subnet_id                 = "subnet-0123456789abcdef0"
  gateway_allowed_cidrs     = ["192.0.2.10/32", "198.51.100.20/32", "203.0.113.30/32"]
  key_name                  = "tester-windev-key-01"
  public_key_openssh        = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDexample tester"
  iam_instance_profile_name = "tester-windev-role-01"
}

run "secure_defaults" {
  command = plan

  assert {
    condition = (
      length(aws_vpc_security_group_ingress_rule.rdp) == 3 &&
      length(aws_vpc_security_group_ingress_rule.ssh) == 3 &&
      length(aws_vpc_security_group_ingress_rule.icmp) == 3
    )
    error_message = "RDP / SSH / ICMP のルールは許可 CIDR ごとに 1 件ずつ (3 CIDR x 3 種類 = 9 件) 作成すること。"
  }
  assert {
    condition = alltrue([
      for rules in [aws_vpc_security_group_ingress_rule.rdp, aws_vpc_security_group_ingress_rule.ssh, aws_vpc_security_group_ingress_rule.icmp] :
      toset([for r in rules : r.cidr_ipv4]) == toset(var.gateway_allowed_cidrs)
    ])
    error_message = "各ルールの送信元は gateway_allowed_cidrs と一致すること。"
  }
  assert {
    condition     = alltrue([for r in aws_vpc_security_group_ingress_rule.rdp : r.ip_protocol == "tcp" && r.from_port == 3389 && r.to_port == 3389])
    error_message = "RDP ルールは TCP 3389 のみ。"
  }
  assert {
    condition     = alltrue([for r in aws_vpc_security_group_ingress_rule.ssh : r.ip_protocol == "tcp" && r.from_port == 22 && r.to_port == 22])
    error_message = "SSH ルールは TCP 22 のみ。"
  }
  assert {
    condition     = alltrue([for r in aws_vpc_security_group_ingress_rule.icmp : r.ip_protocol == "icmp" && r.from_port == -1 && r.to_port == -1])
    error_message = "ICMP ルールは全種別 (type / code = -1)。"
  }
  assert {
    condition     = aws_security_group.this.description == "Windows dev EC2: RDP from allowed gateway CIDRs only"
    error_message = "SG の description を変えると SG が再作成されるため据え置くこと。"
  }
  assert {
    condition     = aws_instance.this.instance_type == "t3.medium"
    error_message = "既定のインスタンスタイプは t3.medium。"
  }
  assert {
    condition     = aws_instance.this.associate_public_ip_address == true
    error_message = "Public IPv4 を付与すること。"
  }
  assert {
    condition     = aws_instance.this.metadata_options[0].http_tokens == "required"
    error_message = "IMDSv2 を必須にすること。"
  }
  assert {
    condition     = aws_instance.this.root_block_device[0].volume_type == "gp2" && aws_instance.this.root_block_device[0].encrypted == true
    error_message = "ルート EBS は gp2 かつ暗号化すること。"
  }
  assert {
    condition     = aws_key_pair.this[0].key_name == "tester-windev-key-01"
    error_message = "公開鍵指定時はキーペアを作成すること。"
  }
}

run "existing_key_pair" {
  command = plan

  variables {
    public_key_openssh = null
  }

  assert {
    condition     = length(aws_key_pair.this) == 0 && aws_instance.this.key_name == "tester-windev-key-01"
    error_message = "公開鍵未指定時は既存キーペア名を参照すること。"
  }
}

run "gateway_cidr_added" {
  # CIDR の追加は変数の変更だけで、3 種類のルールがそれぞれ 1 件ずつ増える
  command = plan
  variables {
    gateway_allowed_cidrs = ["192.0.2.10/32", "198.51.100.20/32", "203.0.113.30/32", "203.0.113.40/32"]
  }

  assert {
    condition = (
      length(aws_vpc_security_group_ingress_rule.rdp) == 4 &&
      length(aws_vpc_security_group_ingress_rule.ssh) == 4 &&
      length(aws_vpc_security_group_ingress_rule.icmp) == 4
    )
    error_message = "CIDR を 1 件追加したら RDP / SSH / ICMP が 1 件ずつ増えること。"
  }
  assert {
    condition     = aws_vpc_security_group_ingress_rule.icmp["203.0.113.40/32"].cidr_ipv4 == "203.0.113.40/32"
    error_message = "ルールのキーは CIDR (既存ルールのキーが変わらないこと)。"
  }
}

run "open_cidr_rejected" {
  command = plan
  variables {
    gateway_allowed_cidrs = ["192.0.2.10/32", "0.0.0.0/0"]
  }
  expect_failures = [var.gateway_allowed_cidrs]
}

run "wide_cidr_rejected" {
  command = plan
  variables {
    gateway_allowed_cidrs = ["10.0.0.0/8"]
  }
  expect_failures = [var.gateway_allowed_cidrs]
}

run "empty_cidrs_rejected" {
  command = plan
  variables {
    gateway_allowed_cidrs = []
  }
  expect_failures = [var.gateway_allowed_cidrs]
}

run "cidr_without_prefix_rejected" {
  command = plan
  variables {
    gateway_allowed_cidrs = ["192.0.2.10"]
  }
  expect_failures = [var.gateway_allowed_cidrs]
}

run "ipv6_cidr_rejected" {
  command = plan
  variables {
    gateway_allowed_cidrs = ["2001:db8::/64"]
  }
  expect_failures = [var.gateway_allowed_cidrs]
}

run "non_rsa_key_rejected" {
  command = plan
  variables {
    public_key_openssh = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIexample tester"
  }
  expect_failures = [var.public_key_openssh]
}

run "gp3_rejected" {
  command = plan
  variables {
    root_volume_type = "gp3"
  }
  expect_failures = [var.root_volume_type]
}
