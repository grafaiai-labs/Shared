variable "name" {
  description = "Name タグおよびリソース名の接頭辞。"
  type        = string

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,50}$", var.name))
    error_message = "name は小文字英数字とハイフンのみ、3〜51 文字で指定してください。"
  }
}

variable "vpc_id" {
  description = "Security Group を作成する VPC の ID。"
  type        = string

  validation {
    condition     = can(regex("^vpc-[0-9a-f]{8,17}$", var.vpc_id))
    error_message = "vpc_id は vpc-xxxxxxxx 形式で指定してください。"
  }
}

variable "subnet_id" {
  description = "配置先 Public Subnet の ID。"
  type        = string

  validation {
    condition     = can(regex("^subnet-[0-9a-f]{8,17}$", var.subnet_id))
    error_message = "subnet_id は subnet-xxxxxxxx 形式で指定してください。"
  }
}

variable "ami_name_pattern" {
  description = "公式 Windows AMI を検索する名前パターン。"
  type        = string
  default     = "Windows_Server-2022-Japanese-Full-Base-*"
}

variable "instance_type" {
  description = "EC2 インスタンスタイプ。"
  type        = string
  default     = "t3.medium"
}

variable "root_volume_size_gb" {
  description = "ルート EBS のサイズ (GB)。"
  type        = number
  default     = 50

  validation {
    condition     = var.root_volume_size_gb >= 30 && var.root_volume_size_gb <= 100
    error_message = "Windows のルート EBS は 30〜100 GB で指定してください。"
  }
}

variable "root_volume_type" {
  description = "ルート EBS のボリュームタイプ。"
  type        = string
  default     = "gp2"

  validation {
    condition     = contains(["gp2", "standard"], var.root_volume_type)
    error_message = "ルートボリュームには gp2 または standard を指定してください。"
  }
}

variable "rdp_allowed_cidrs" {
  description = "RDP (TCP 3389) を許可する送信元 CIDR。接続ゲートウェイの送信元 IP のみを指定する。"
  type        = list(string)

  validation {
    condition = length(var.rdp_allowed_cidrs) > 0 && alltrue([
      for c in var.rdp_allowed_cidrs :
      can(cidrhost(c, 0)) && tonumber(split("/", c)[1]) >= 16
    ])
    error_message = "rdp_allowed_cidrs は 1 件以上、かつ /16 以上に絞った IPv4 CIDR を指定してください (0.0.0.0/0 は不可)。"
  }
}

variable "allow_http_egress" {
  description = "TCP 80 のアウトバウンドを許可する。Windows の証明書失効確認 (CRL/OCSP) に必要。"
  type        = bool
  default     = true
}

variable "key_name" {
  description = "Administrator パスワード復号に使う RSA キーペア名。"
  type        = string
}

variable "public_key_openssh" {
  description = "RSA 公開鍵 (OpenSSH 形式)。指定時は key_name でキーペアを作成する。null の場合は既存キーペアを参照する。"
  type        = string
  default     = null

  validation {
    condition     = var.public_key_openssh == null || can(regex("^ssh-rsa ", var.public_key_openssh))
    error_message = "Windows のパスワード復号には RSA キーが必要です。ssh-rsa で始まる公開鍵を指定してください。"
  }
}

variable "iam_instance_profile_name" {
  description = "関連付けるインスタンスプロファイル名 (SSM 用)。"
  type        = string
}

variable "user_data" {
  description = "初回起動時に実行する user data (<powershell> ブロックを含む文字列)。null の場合は実行しない。"
  type        = string
  default     = null
}

variable "encrypt_root_volume" {
  description = "ルート EBS を暗号化する (AWS マネージドキー)。"
  type        = bool
  default     = true
}

variable "tags" {
  description = "追加タグ。共通タグはプロバイダーの default_tags で付与する。"
  type        = map(string)
  default     = {}
}
