output "instance_id" {
  description = "インスタンス ID。"
  value       = aws_instance.this.id
}

output "public_ip" {
  description = "RDP 接続先の Public IPv4。停止・起動で変わる。"
  value       = aws_instance.this.public_ip
}

output "private_ip" {
  description = "VPC 内の Private IPv4。"
  value       = aws_instance.this.private_ip
}

output "security_group_id" {
  description = "Windows 用 Security Group の ID。Linux 側で送信元として参照できる。"
  value       = aws_security_group.this.id
}

output "gateway_ingress_cidrs" {
  description = "接続ゲートウェイからのインバウンドルールの送信元 CIDR (rdp / ssh / icmp ごと、昇順)。"
  value = {
    rdp  = sort([for r in aws_vpc_security_group_ingress_rule.rdp : r.cidr_ipv4])
    ssh  = sort([for r in aws_vpc_security_group_ingress_rule.ssh : r.cidr_ipv4])
    icmp = sort([for r in aws_vpc_security_group_ingress_rule.icmp : r.cidr_ipv4])
  }
}

output "ami_id" {
  description = "起動に使用した AMI ID。"
  value       = aws_instance.this.ami
}

output "ami_name" {
  description = "検索で選ばれた AMI 名。"
  value       = data.aws_ami.windows.name
}
