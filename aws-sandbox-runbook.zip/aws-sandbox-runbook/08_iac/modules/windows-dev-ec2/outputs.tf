output "instance_id" {
  description = "インスタンス ID。"
  value       = aws_instance.this.id
}

output "public_ip" {
  description = "RDP 接続先の Public IPv4。停止・起動で変わる。"
  value       = aws_instance.this.public_ip
}

output "private_ip" {
  description = "VPC 内の Private IPv4。"
  value       = aws_instance.this.private_ip
}

output "security_group_id" {
  description = "Windows 用 Security Group の ID。Linux 側で送信元として参照できる。"
  value       = aws_security_group.this.id
}

output "ami_id" {
  description = "起動に使用した AMI ID。"
  value       = aws_instance.this.ami
}

output "ami_name" {
  description = "検索で選ばれた AMI 名。"
  value       = data.aws_ami.windows.name
}
