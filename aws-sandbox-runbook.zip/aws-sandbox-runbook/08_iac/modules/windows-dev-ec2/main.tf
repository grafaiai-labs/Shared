# 公式 (所有者 amazon) の最新 AMI を構築時に検索する。AMI ID は固定しない。
data "aws_ami" "windows" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = [var.ami_name_pattern]
  }

  filter {
    name   = "architecture"
    values = ["x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

resource "aws_security_group" "this" {
  name = "${var.name}-sg"
  # description の変更は SG の再作成 (EC2 からの付け替え) を伴うため、SSH / ICMP 追加後も据え置く。
  description = "Windows dev EC2: RDP from allowed gateway CIDRs only"
  vpc_id      = var.vpc_id
  tags        = merge(var.tags, { Name = "${var.name}-sg" })
}

# 接続ゲートウェイの送信元 CIDR ごとに RDP / SSH / ICMP を 1 ルールずつ作成する。
# CIDR の追加・削除は gateway_allowed_cidrs の変更だけで済む (キーは CIDR)。
resource "aws_vpc_security_group_ingress_rule" "rdp" {
  for_each = toset(var.gateway_allowed_cidrs)

  security_group_id = aws_security_group.this.id
  description       = "RDP from allowed gateway"
  ip_protocol       = "tcp"
  from_port         = 3389
  to_port           = 3389
  cidr_ipv4         = each.value
}

resource "aws_vpc_security_group_ingress_rule" "ssh" {
  for_each = toset(var.gateway_allowed_cidrs)

  security_group_id = aws_security_group.this.id
  description       = "SSH from allowed gateway"
  ip_protocol       = "tcp"
  from_port         = 22
  to_port           = 22
  cidr_ipv4         = each.value
}

resource "aws_vpc_security_group_ingress_rule" "icmp" {
  for_each = toset(var.gateway_allowed_cidrs)

  security_group_id = aws_security_group.this.id
  description       = "ICMP (all types) from allowed gateway"
  ip_protocol       = "icmp"
  from_port         = -1
  to_port           = -1
  cidr_ipv4         = each.value
}

resource "aws_vpc_security_group_egress_rule" "https" {
  security_group_id = aws_security_group.this.id
  description       = "HTTPS outbound (SSM, package download, GitHub, Snowflake)"
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
  cidr_ipv4         = "0.0.0.0/0"
}

resource "aws_vpc_security_group_egress_rule" "http" {
  count = var.allow_http_egress ? 1 : 0

  security_group_id = aws_security_group.this.id
  description       = "HTTP outbound (certificate revocation checks)"
  ip_protocol       = "tcp"
  from_port         = 80
  to_port           = 80
  cidr_ipv4         = "0.0.0.0/0"
}

resource "aws_key_pair" "this" {
  count = var.public_key_openssh == null ? 0 : 1

  key_name   = var.key_name
  public_key = var.public_key_openssh
  tags       = var.tags
}

resource "aws_instance" "this" {
  ami                         = data.aws_ami.windows.id
  instance_type               = var.instance_type
  subnet_id                   = var.subnet_id
  associate_public_ip_address = true
  vpc_security_group_ids      = [aws_security_group.this.id]
  key_name                    = var.public_key_openssh == null ? var.key_name : aws_key_pair.this[0].key_name
  iam_instance_profile        = var.iam_instance_profile_name
  user_data                   = var.user_data
  get_password_data           = false

  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required"
    http_put_response_hop_limit = 1
  }

  root_block_device {
    volume_type           = var.root_volume_type
    volume_size           = var.root_volume_size_gb
    encrypted             = var.encrypt_root_volume
    delete_on_termination = true
    tags                  = merge(var.tags, { Name = "${var.name}-root" })
  }

  tags = merge(var.tags, { Name = var.name })

  lifecycle {
    # 週の途中で新しい AMI が公開されても、作業中のインスタンスを再作成しない。
    # 週末後の再構築時に最新 AMI が選ばれる。
    ignore_changes = [ami, user_data]
  }
}
