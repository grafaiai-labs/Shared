data "aws_partition" "current" {}

data "aws_iam_policy_document" "assume_role" {
  statement {
    sid     = "AllowEc2AssumeRole"
    effect  = "Allow"
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "this" {
  name                 = var.name
  description          = "EC2 instance role for SSM Session Manager"
  assume_role_policy   = data.aws_iam_policy_document.assume_role.json
  permissions_boundary = var.permissions_boundary_arn
  tags                 = var.tags
}

resource "aws_iam_role_policy_attachment" "ssm_core" {
  role       = aws_iam_role.this.name
  policy_arn = "arn:${data.aws_partition.current.partition}:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

# 退避用 S3 プレフィックスだけに限定した読み書き権限。
# バケット全体やバケット削除の権限は付与しない。
data "aws_iam_policy_document" "transfer" {
  count = var.transfer_bucket_name == null ? 0 : 1

  statement {
    sid       = "ListTransferPrefixOnly"
    effect    = "Allow"
    actions   = ["s3:ListBucket"]
    resources = ["arn:${data.aws_partition.current.partition}:s3:::${var.transfer_bucket_name}"]

    condition {
      test     = "StringLike"
      variable = "s3:prefix"
      values   = ["${var.transfer_prefix}/", "${var.transfer_prefix}/*"]
    }
  }

  statement {
    sid    = "ReadWriteTransferObjects"
    effect = "Allow"
    actions = [
      "s3:GetObject",
      "s3:PutObject",
      "s3:DeleteObject",
    ]
    resources = ["arn:${data.aws_partition.current.partition}:s3:::${var.transfer_bucket_name}/${var.transfer_prefix}/*"]
  }
}

resource "aws_iam_role_policy" "transfer" {
  count = var.transfer_bucket_name == null ? 0 : 1

  name   = "transfer-prefix-access"
  role   = aws_iam_role.this.id
  policy = data.aws_iam_policy_document.transfer[0].json
}

resource "aws_iam_instance_profile" "this" {
  name = var.name
  role = aws_iam_role.this.name
  tags = var.tags
}
