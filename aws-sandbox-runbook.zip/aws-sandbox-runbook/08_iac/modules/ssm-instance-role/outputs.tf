output "role_name" {
  description = "作成した IAM ロール名。"
  value       = aws_iam_role.this.name
}

output "role_arn" {
  description = "作成した IAM ロールの ARN。"
  value       = aws_iam_role.this.arn
}

output "instance_profile_name" {
  description = "EC2 へ関連付けるインスタンスプロファイル名。"
  value       = aws_iam_instance_profile.this.name
}
