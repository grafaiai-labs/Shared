# terraform init && terraform test (モック Provider。AWS へ接続しない)

mock_provider "aws" {
  mock_data "aws_partition" {
    defaults = { partition = "aws" }
  }
  mock_data "aws_iam_policy_document" {
    defaults = { json = "{\"Version\":\"2012-10-17\",\"Statement\":[]}" }
  }
}

variables {
  name                     = "tester-dockdev-role-01"
  permissions_boundary_arn = "arn:aws:iam::000000000000:policy/example-boundary"
}

run "boundary_and_ssm_core" {
  command = plan

  assert {
    condition     = aws_iam_role.this.permissions_boundary == "arn:aws:iam::000000000000:policy/example-boundary"
    error_message = "Permissions Boundary を必ず適用すること。"
  }
  assert {
    condition     = aws_iam_role_policy_attachment.ssm_core.policy_arn == "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
    error_message = "SSM 用 AWS 管理ポリシーを付与すること。"
  }
  assert {
    condition     = length(aws_iam_role_policy.transfer) == 0
    error_message = "バケット未指定時は S3 権限を付与しないこと。"
  }
}

run "transfer_policy_when_bucket_given" {
  command = plan

  variables {
    transfer_bucket_name = "example-bootstrap-bucket"
    transfer_prefix      = "transfer/tester-dockdev"
  }

  assert {
    condition     = length(aws_iam_role_policy.transfer) == 1
    error_message = "バケット指定時は退避用プレフィックスの権限を付与すること。"
  }
}

run "boundary_required_format" {
  command = plan
  variables {
    permissions_boundary_arn = "example-boundary"
  }
  expect_failures = [var.permissions_boundary_arn]
}
