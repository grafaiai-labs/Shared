variable "name" {
  description = "IAM ロールとインスタンスプロファイルの名前。呼び出し側の命名規則に従う。"
  type        = string

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,62}$", var.name))
    error_message = "name は小文字英数字とハイフンのみ、3〜63 文字で指定してください。"
  }
}

variable "permissions_boundary_arn" {
  description = "ロールへ必ず適用する Permissions Boundary の ARN。"
  type        = string

  validation {
    condition     = can(regex("^arn:aws:iam::[0-9]{12}:policy/.+$", var.permissions_boundary_arn))
    error_message = "permissions_boundary_arn は arn:aws:iam::<12桁>:policy/<名前> の形式で指定してください。"
  }
}

variable "transfer_bucket_name" {
  description = "インスタンスとの退避用ファイル受け渡しに使う S3 バケット名。null の場合は S3 権限を付与しない。"
  type        = string
  default     = null
}

variable "transfer_prefix" {
  description = "退避用に読み書きを許可する S3 プレフィックス（末尾スラッシュなし）。"
  type        = string
  default     = "transfer"

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9_./-]*[a-zA-Z0-9_-]$", var.transfer_prefix))
    error_message = "transfer_prefix は英数字で始まり、末尾スラッシュなしで指定してください。"
  }
}

variable "tags" {
  description = "追加タグ。共通タグはプロバイダーの default_tags で付与する。"
  type        = map(string)
  default     = {}
}
