output "instance_id" {
  description = "インスタンス ID。SSM 接続時に指定する。"
  value       = aws_instance.this.id
}

output "private_ip" {
  description = "VPC 内の Private IPv4。"
  value       = aws_instance.this.private_ip
}

output "public_ip" {
  description = "Public IPv4 (付与した場合のみ)。インバウンドは許可していない。"
  value       = aws_instance.this.public_ip
}

output "security_group_id" {
  description = "Linux 用 Security Group の ID。"
  value       = aws_security_group.this.id
}

output "ami_id" {
  description = "起動に使用した AMI ID。"
  value       = aws_instance.this.ami
}

output "ami_name" {
  description = "検索で選ばれた AMI 名。"
  value       = data.aws_ami.al2023.name
}
