# terraform init && terraform test (モック Provider。AWS へ接続しない)

mock_provider "aws" {
  mock_data "aws_ami" {
    defaults = { id = "ami-0fedcba9876543210", name = "al2023-ami-2023.9.20260915.0-kernel-6.12-x86_64" }
  }
}

variables {
  name                      = "tester-dockdev-ec2-01"
  vpc_id                    = "vpc-0123456789abcdef0"
  subnet_id                 = "subnet-0123456789abcdef0"
  iam_instance_profile_name = "tester-dockdev-role-01"
}

run "no_inbound_by_default" {
  command = plan

  assert {
    condition     = length(aws_vpc_security_group_ingress_rule.app) == 0
    error_message = "既定ではインバウンドルールを作成しないこと。"
  }
  assert {
    condition     = length(aws_vpc_security_group_egress_rule.http) == 0 && aws_vpc_security_group_egress_rule.https.to_port == 443
    error_message = "既定のアウトバウンドは HTTPS のみ。"
  }
  assert {
    condition     = aws_instance.this.metadata_options[0].http_tokens == "required" && aws_instance.this.metadata_options[0].http_put_response_hop_limit == 1
    error_message = "IMDSv2 必須かつ hop limit 1 にすること。"
  }
  assert {
    condition     = aws_instance.this.root_block_device[0].volume_type == "gp2"
    error_message = "ルート EBS は gp2 を明示すること (AMI 既定の gp3 は使用不可)。"
  }
}

run "app_ingress_from_security_group_only" {
  command = plan

  variables {
    app_ingress_ports                     = [8080]
    app_ingress_source_security_group_ids = ["sg-0123456789abcdef0"]
  }

  assert {
    condition     = length(aws_vpc_security_group_ingress_rule.app) == 1 && aws_vpc_security_group_ingress_rule.app["sg-0123456789abcdef0-8080"].cidr_ipv4 == null
    error_message = "アプリ確認用の受信は SG 参照のみで、CIDR 許可を作らないこと。"
  }
}

run "private_mode_without_public_ip" {
  command = plan

  variables {
    associate_public_ip_address = false
  }

  assert {
    condition     = aws_instance.this.associate_public_ip_address == false
    error_message = "Private Subnet 案では Public IPv4 を付与しないこと。"
  }
}

run "docker_api_port_rejected" {
  command = plan
  variables {
    app_ingress_ports                     = [2375]
    app_ingress_source_security_group_ids = ["sg-0123456789abcdef0"]
  }
  expect_failures = [var.app_ingress_ports]
}

run "oversized_volume_rejected" {
  command = plan
  variables {
    root_volume_size_gb = 200
  }
  expect_failures = [var.root_volume_size_gb]
}
