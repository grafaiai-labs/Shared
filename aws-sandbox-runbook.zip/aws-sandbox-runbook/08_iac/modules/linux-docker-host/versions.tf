# 再利用 Module は互換範囲だけを宣言し、正確なバージョン固定は呼び出し側の Root Module で行う。
terraform {
  required_version = ">= 1.10.0, < 2.0.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.0.0, < 7.0.0"
    }
  }
}
