variable "name" {
  description = "Name タグおよびリソース名の接頭辞。"
  type        = string

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,50}$", var.name))
    error_message = "name は小文字英数字とハイフンのみ、3〜51 文字で指定してください。"
  }
}

variable "vpc_id" {
  description = "Security Group を作成する VPC の ID。"
  type        = string

  validation {
    condition     = can(regex("^vpc-[0-9a-f]{8,17}$", var.vpc_id))
    error_message = "vpc_id は vpc-xxxxxxxx 形式で指定してください。"
  }
}

variable "subnet_id" {
  description = "配置先 Subnet の ID。"
  type        = string

  validation {
    condition     = can(regex("^subnet-[0-9a-f]{8,17}$", var.subnet_id))
    error_message = "subnet_id は subnet-xxxxxxxx 形式で指定してください。"
  }
}

variable "associate_public_ip_address" {
  description = "Public IPv4 を付与する。Public Subnet 案では true、Private Subnet + NAT/Proxy 案では false。"
  type        = bool
  default     = true
}

variable "ami_name_pattern" {
  description = "公式 Amazon Linux 2023 AMI を検索する名前パターン (minimal / ECS 最適化版を除外)。"
  type        = string
  default     = "al2023-ami-2023.*-x86_64"
}

variable "instance_type" {
  description = "EC2 インスタンスタイプ。"
  type        = string
  default     = "t3.medium"
}

variable "root_volume_size_gb" {
  description = "ルート EBS のサイズ (GB)。コンテナイメージを保持するため 30 GB 以上を推奨。"
  type        = number
  default     = 30

  validation {
    condition     = var.root_volume_size_gb >= 8 && var.root_volume_size_gb <= 100
    error_message = "ルート EBS は 8〜100 GB で指定してください。"
  }
}

variable "root_volume_type" {
  description = "ルート EBS のボリュームタイプ。AMI 既定値 (gp3) を使わず明示する。"
  type        = string
  default     = "gp2"

  validation {
    condition     = contains(["gp2", "standard"], var.root_volume_type)
    error_message = "ルートボリュームには gp2 または standard を指定してください。"
  }
}

variable "allow_http_egress" {
  description = "TCP 80 のアウトバウンドを許可する。既定では HTTPS のみ。"
  type        = bool
  default     = false
}

variable "app_ingress_ports" {
  description = "app_ingress_source_security_group_ids からの受信を許可する TCP ポート。既定は受信なし。"
  type        = list(number)
  default     = []

  validation {
    condition     = alltrue([for p in var.app_ingress_ports : p >= 1024 && p <= 65535 && p != 2375 && p != 2376])
    error_message = "app_ingress_ports は 1024〜65535 の範囲で指定してください。Docker API ポート (2375/2376) は指定できません。"
  }
}

variable "app_ingress_source_security_group_ids" {
  description = "アプリ確認用の受信を許可する送信元 Security Group ID (例: Windows 開発用 EC2 の SG)。CIDR 指定は受け付けない。"
  type        = list(string)
  default     = []
}

variable "iam_instance_profile_name" {
  description = "関連付けるインスタンスプロファイル名 (SSM 用)。"
  type        = string
}

variable "user_data" {
  description = "初回起動時に実行する user data (bash スクリプト)。null の場合は実行しない。"
  type        = string
  default     = null
}

variable "encrypt_root_volume" {
  description = "ルート EBS を暗号化する (AWS マネージドキー)。"
  type        = bool
  default     = true
}

variable "tags" {
  description = "追加タグ。共通タグはプロバイダーの default_tags で付与する。"
  type        = map(string)
  default     = {}
}
