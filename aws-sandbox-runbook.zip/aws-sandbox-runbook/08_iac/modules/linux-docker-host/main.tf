# 公式 (所有者 amazon) の最新 Amazon Linux 2023 AMI を構築時に検索する。
data "aws_ami" "al2023" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = [var.ami_name_pattern]
  }

  filter {
    name   = "architecture"
    values = ["x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

locals {
  app_ingress = {
    for pair in setproduct(var.app_ingress_source_security_group_ids, var.app_ingress_ports) :
    "${pair[0]}-${pair[1]}" => { source_sg = pair[0], port = pair[1] }
  }
}

# SSM Session Manager だけで管理するため、既定ではインバウンドルールを作成しない。
resource "aws_security_group" "this" {
  name        = "${var.name}-sg"
  description = "Linux docker host: no inbound by default, SSM only"
  vpc_id      = var.vpc_id
  tags        = merge(var.tags, { Name = "${var.name}-sg" })
}

resource "aws_vpc_security_group_ingress_rule" "app" {
  for_each = local.app_ingress

  security_group_id            = aws_security_group.this.id
  description                  = "App check from trusted security group"
  ip_protocol                  = "tcp"
  from_port                    = each.value.port
  to_port                      = each.value.port
  referenced_security_group_id = each.value.source_sg
}

resource "aws_vpc_security_group_egress_rule" "https" {
  security_group_id = aws_security_group.this.id
  description       = "HTTPS outbound (SSM, dnf, container registry, GitHub, Snowflake)"
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
  cidr_ipv4         = "0.0.0.0/0"
}

resource "aws_vpc_security_group_egress_rule" "http" {
  count = var.allow_http_egress ? 1 : 0

  security_group_id = aws_security_group.this.id
  description       = "HTTP outbound"
  ip_protocol       = "tcp"
  from_port         = 80
  to_port           = 80
  cidr_ipv4         = "0.0.0.0/0"
}

resource "aws_instance" "this" {
  ami                         = data.aws_ami.al2023.id
  instance_type               = var.instance_type
  subnet_id                   = var.subnet_id
  associate_public_ip_address = var.associate_public_ip_address
  vpc_security_group_ids      = [aws_security_group.this.id]
  iam_instance_profile        = var.iam_instance_profile_name
  user_data                   = var.user_data

  # SSH キーは使用しない。
  key_name = null

  metadata_options {
    http_endpoint = "enabled"
    http_tokens   = "required"
    # 1 にすることで、コンテナ (ブリッジネットワーク) からインスタンスロールの資格情報を取得させない。
    http_put_response_hop_limit = 1
  }

  root_block_device {
    volume_type           = var.root_volume_type
    volume_size           = var.root_volume_size_gb
    encrypted             = var.encrypt_root_volume
    delete_on_termination = true
    tags                  = merge(var.tags, { Name = "${var.name}-root" })
  }

  tags = merge(var.tags, { Name = var.name })

  lifecycle {
    # 週の途中の AMI 更新や user data 修正で作業中のインスタンスを再作成しない。
    ignore_changes = [ami, user_data]
  }
}
