# Pattern 03: Docker Compose による React + FastAPI + Snowflake

React (nginx で配信) と FastAPI を Docker Compose で一括起動し、FastAPI からだけ Snowflake へ接続する最小構成のサンプル。Snowflake 未設定でも起動し、ヘルスチェックとエラーコードで状態を判別できる。

## 1. 用途

- React + FastAPI + Snowflake の Web アプリを検証する出発点。
- ヘルスチェック、構造化ログ、相関 ID、入力検証、制御された例外処理、タイムアウトの実装例。

## 2. 成功条件

- [ ] `docker compose up -d --build` で `api` と `frontend` が `healthy` になる (Snowflake 未設定でも)
- [ ] `/api/healthz` が 200、未設定時の `/api/readyz` が 503 で不足項目名 (値ではない) を返す
- [ ] Snowflake 設定後、`/api/readyz` が 200、画面の「取得」で Snowflake のバージョンが表示される
- [ ] 不正な入力が 422 `VALIDATION_ERROR` になり、入力値がレスポンスとログに出ない
- [ ] すべてのレスポンスに `X-Request-ID` があり、nginx と FastAPI のログで同じ ID を追跡できる
- [ ] API のユニットテスト (27 件)、フロントエンドのテスト (5 件)・型検査・ビルドが成功する
- [ ] コンテナが非 root で動き、秘密情報がイメージ・Compose・`.env` に含まれない

## 3. 非スコープ

- 認証・認可 (ログイン画面、API キー)
- インターネット公開、TLS 終端 ([Pattern 05](../05_public-web/README.md))
- 書き込み系 API、DB マイグレーション
- 本番向けのコネクションプール、キャッシュ

## 4. 前提条件

- [Pattern 02](../02_linux-docker-dev/README.md) の Linux EC2 で `check-devhost.sh` が PASS。
- Snowflake に接続する場合: ユーザー、ウェアハウス、認証用の鍵または PAT ([Snowflake 接続](../../05_components/snowflake-connection.md))。

## 5. 設計判断

| 判断 | 内容 | 理由 |
| --- | --- | --- |
| Snowflake への接続 | FastAPI だけが接続。React は同一オリジンの `/api` だけを呼ぶ | 資格情報をブラウザーへ渡さない |
| 配信 | React はビルド済み静的ファイルを nginx (非 root) で配信し、`/api` を FastAPI へ転送 | CORS 不要。本番に近い形 |
| 資格情報の渡し方 | `./secrets/` のファイルを読み取り専用でマウント。`.env` にはパスだけ | 環境変数は `docker inspect` で見えるため |
| 接続方式 | リクエストごとに短命な接続を開く | サンプルの単純さと古いセッションの回避。遅延が問題になったらプールを検討 |
| タイムアウト | ログイン / ネットワーク / ステートメント / リクエスト全体の 4 段 | ハングの防止 |
| エラー | ドライバーの例外を安定したコードへ変換し、生のメッセージは返さない | 内部情報の漏えい防止と判別容易性 |
| ヘルスチェック | `healthz` (Snowflake に触れない) と `readyz` (Snowflake を確認) を分離 | 未設定でもコンテナを healthy に保つ |
| SQL | 値はバインド、識別子は正規表現で検証 | SQL インジェクション対策 |

## 6. 採用コンポーネント

| コンポーネント | バージョン |
| --- | --- |
| React / React DOM | 19.3.0 |
| Vite / TypeScript / Vitest | 8.3.1 / 6.0.3 / 5.0.2 |
| nginx (nginx-unprivileged) | 1.30.5 (alpine3.24、ダイジェスト固定) |
| FastAPI / Uvicorn / Pydantic / pydantic-settings | 0.141.1 / 0.54.0 / 2.13.5 / 2.15.0 |
| snowflake-connector-python | 4.7.5 |
| Python ベースイメージ | 3.13.15-slim-trixie (ダイジェスト固定) |

## 7. 不採用コンポーネントと切替条件

| 不採用 | 理由 | 切替条件 |
| --- | --- | --- |
| ブラウザーから Snowflake へ直接接続 | 資格情報がブラウザーへ渡る | 採用しない |
| Vite 開発サーバーをコンテナで常駐 | 本番構成と乖離。ビルド済み配信で十分 | UI を頻繁に修正する期間はホストで `npm run dev` |
| ローカル DB コンテナ | Snowflake を対象にしているため不要 | Snowflake を使わない検証を行う場合 ([Docker 方針 §4](../../02_common-design/docker-policy.md#4-ローカル検証用-db)) |
| Snowflake SQLAlchemy / ORM | 参照クエリだけのため不要 | 書き込み・モデル定義が増えた場合 |
| コネクションプール | 1 名利用で負荷が小さい | 1 リクエストあたりのログイン時間が問題になった場合 |
| Docker secrets (Swarm) | Compose 単体では実体はバインドマウントと同等 | Swarm / オーケストレーターへ移行した場合 |

## 8. 制約、代替策、残存リスク

| 項目 | 内容 |
| --- | --- |
| 社内 PC のブラウザーからは開けない | Linux EC2 上の `curl`、または Windows 開発用 EC2 のブラウザー (Pattern 02 §19) |
| 認証なしの API | `127.0.0.1` バインドが既定。Windows へ開く場合も SG 参照で限定 |
| スレッドのタイムアウト | リクエスト全体のタイムアウトで応答は返すが、ドライバー呼び出しのスレッドは Snowflake 側のタイムアウトまで残る |
| エラー分類の推測 | 認証エラーを Snowflake の 390xxx 番台で判定している (ドライバーの仕様変更で分類が変わる可能性) |

## 9. Mermaid 構成図

```mermaid
flowchart LR
  BR["ブラウザー<br/>(EC2 上の curl / Windows EC2)"] -- "HTTP 8080<br/>127.0.0.1 既定" --> FE
  subgraph Host["Linux Docker EC2"]
    subgraph Compose["docker compose (network: default)"]
      FE["frontend<br/>nginx-unprivileged :8080<br/>静的ファイル + /api 転送"]
      API["api<br/>FastAPI :8000<br/>UID 10001"]
    end
    SEC["./secrets/ (ro mount)<br/>鍵 / PAT"]
  end
  FE -- "/api/*" --> API
  SEC -.-> API
  API -- "HTTPS 443" --> SF["Snowflake"]
```

## 10. 通信フロー

| # | 送信元 | 宛先 | 内容 |
| --- | --- | --- | --- |
| 1 | ブラウザー | frontend:8080 `/` | 静的ファイル |
| 2 | ブラウザー | frontend:8080 `/api/...` | API 呼び出し (`X-Request-ID` 付き) |
| 3 | frontend | api:8000 | 転送 (`/api/healthz` → `/healthz`、`/api/readyz` → `/readyz`、`/api/v1/*` はそのまま) |
| 4 | api | Snowflake | ログイン → クエリ → 切断 |

## 11. データフロー

| データ | 流れ | 備考 |
| --- | --- | --- |
| Snowflake の参照結果 | Snowflake → api → ブラウザー | 最大 500 行 (`MAX_ROWS`)、テーブル一覧は最大 100 件 |
| 相関 ID | ブラウザー生成 → nginx → api → レスポンスヘッダー / エラー本文 / ログ | 形式外の値は破棄して再生成 |
| 資格情報 | `./secrets/` → api プロセスのメモリ | ログ・レスポンスに出さない |

## 12. 作成する AWS リソース

なし (Pattern 02 の EC2 上で動かす)。

## 13. パラメーター

[.env.example](.env.example) を `.env` にコピーして記入する (Git 管理外)。

| 変数 | 既定 | 説明 |
| --- | --- | --- |
| `API_HOST_PORT` / `FRONTEND_HOST_PORT` | `8000` / `8080` | ホスト側ポート |
| `FRONTEND_BIND_ADDRESS` | `127.0.0.1` | Windows から確認する場合のみ `0.0.0.0` |
| `SNOWFLAKE_ACCOUNT` / `USER` / `ROLE` / `WAREHOUSE` / `DATABASE` / `SCHEMA` | プレースホルダー | `<...>` のままなら未設定として扱う |
| `SNOWFLAKE_AUTH_METHOD` | `keypair` | `keypair` / `pat` / `password` |
| `SNOWFLAKE_PRIVATE_KEY_FILE` | `/run/secrets/app/snowflake_rsa_key.p8` | コンテナ内のパス |
| `SNOWFLAKE_PRIVATE_KEY_PASSPHRASE_FILE` | なし | 鍵を暗号化した場合 |
| `SNOWFLAKE_SECRET_FILE` | なし | `pat` / `password` の場合 |
| `SNOWFLAKE_LOGIN_TIMEOUT_SECONDS` | `10` | ログイン |
| `SNOWFLAKE_NETWORK_TIMEOUT_SECONDS` | `30` | ネットワーク / ソケット |
| `SNOWFLAKE_STATEMENT_TIMEOUT_SECONDS` | `30` | `STATEMENT_TIMEOUT_IN_SECONDS` とカーソルのタイムアウト |
| `REQUEST_TIMEOUT_SECONDS` | `45` | API のリクエスト全体 |

### API

| メソッド・パス | 説明 | 主な応答 |
| --- | --- | --- |
| `GET /healthz` | 生存確認。Snowflake に触れない | 200 |
| `GET /readyz` | Snowflake の設定と `SELECT 1` を確認 | 200 / 503 (`checks.snowflake.status` = `not_configured` / `error`) |
| `GET /api/v1/snowflake/info` | バージョン、ロール、ウェアハウス等 | 200 / 5xx |
| `GET /api/v1/tables?schema=PUBLIC&limit=50` | `SNOWFLAKE_DATABASE` 内のテーブル一覧 | 200 / 422 / 5xx |

nginx 経由では `/api/healthz`、`/api/readyz` で到達する。

### エラーコード

| コード | HTTP | 意味 | 利用者の対処 |
| --- | --- | --- | --- |
| `VALIDATION_ERROR` | 422 | 入力が不正 | `detail.errors[].loc` の項目を修正 |
| `SNOWFLAKE_NOT_CONFIGURED` | 503 | 設定不足・資格情報ファイルを読めない | `detail.missing_settings` / `detail.setting` を確認 |
| `SNOWFLAKE_AUTH_FAILED` | 503 | 認証失敗・鍵の形式 / パスフレーズ誤り | ユーザー、公開鍵の登録、PAT の有効期限 |
| `SNOWFLAKE_UNREACHABLE` | 503 | 接続不可 | アカウント識別子、外向き 443 |
| `SNOWFLAKE_TIMEOUT` | 504 | タイムアウト | ウェアハウスの状態、タイムアウト値 |
| `SNOWFLAKE_QUERY_FAILED` | 502 | クエリ拒否 | 権限、DB / スキーマ名 |
| `INTERNAL_ERROR` | 500 | 想定外 | `correlation_id` で API ログを検索 |

エラー本文の形式:

```json
{"error": {"code": "SNOWFLAKE_NOT_CONFIGURED", "message": "...", "correlation_id": "4c32ce5e...", "detail": {"missing_settings": ["SNOWFLAKE_ACCOUNT"]}}}
```

## 14. 命名とタグ

AWS リソースなし。コンテナイメージ名は `local/sample-api:0.1.0`、`local/sample-frontend:0.1.0`、Compose プロジェクト名は `react-fastapi-snowflake`。

## 15. IAM 設計

AWS の IAM は使わない。コンテナは IMDS へ到達できない (Pattern 02 の hop limit 1)。Snowflake 側はこのアプリ専用のユーザー・ロールを使い、参照権限だけを与える ([Snowflake 接続](../../05_components/snowflake-connection.md))。

## 16. Permissions Boundary

該当なし。

## 17. Security Group 設計

Pattern 02 の SG に従う。Windows から確認する場合のみ `app_ingress_ports = [8080]` を Windows SG 参照で許可する。

## 18. Terraform 構成

なし。

## 19. 手動例外手順

### Snowflake 資格情報ファイルの配置

```bash
cd ~/work/<GITHUB_REPO>/04_patterns/03_docker-react-fastapi-snowflake
# ディレクトリは 711 (他ユーザーは一覧不可・通過のみ可)。コンテナ (UID 10001) がファイルへ到達するために必要
install -d -m 711 secrets
# キーペア認証: 秘密鍵 (PKCS#8 PEM) を貼り付けて保存する。履歴に残さないため cat + ヒアドキュメントは使わない
nano secrets/snowflake_rsa_key.p8
# コンテナ (UID 10001) だけが読めるようにする
sudo chown 10001:10001 secrets/snowflake_rsa_key.p8
sudo chmod 400 secrets/snowflake_rsa_key.p8
```

PAT の場合はファイル名 `secrets/snowflake_secret` とし、`.env` を次のようにする。

```dotenv
SNOWFLAKE_AUTH_METHOD=pat
SNOWFLAKE_SECRET_FILE=/run/secrets/app/snowflake_secret
# SNOWFLAKE_PRIVATE_KEY_FILE は使わないため行ごと削除するかコメントにする
```

## 20. OS とミドルウェア初期設定

Pattern 02 で完了している。

## 21. Docker 構成

| サービス | イメージ | ユーザー | 公開 | ヘルスチェック | 制限 |
| --- | --- | --- | --- | --- | --- |
| `api` | [api/Dockerfile](api/Dockerfile) (`runtime` ステージ) | 10001 | `127.0.0.1:8000` | `GET /healthz` (Python 標準ライブラリ) | read-only、cap_drop ALL、no-new-privileges、512 MB |
| `frontend` | [frontend/Dockerfile](frontend/Dockerfile) | 101 (nginx) | `${FRONTEND_BIND_ADDRESS}:8080` | `GET /nginx-health` | read-only、cap_drop ALL、no-new-privileges、128 MB |

- API のビルドは `deps` (ハッシュ検証付き pip) → `test` (ruff + pytest) → `runtime` のマルチステージ。
- フロントエンドはビルドステージで `npm ci` → テスト → 型検査 → ビルドし、成果物だけを nginx へコピーする。
- 定義: [compose.yaml](compose.yaml)。両サービスに共通の制限は YAML アンカーで定義している。

```yaml
x-hardening: &hardening
  read_only: true
  cap_drop: [ALL]
  security_opt: ["no-new-privileges:true"]
  tmpfs:
    - /tmp:size=16m
  restart: unless-stopped
```

## 22. アプリケーション配置

```bash
sudo -iu dev
cd ~/work/<GITHUB_REPO>/04_patterns/03_docker-react-fastapi-snowflake
cp .env.example .env
chmod 600 .env
nano .env                       # Snowflake の値を記入 (未記入でも起動する)
docker compose up -d --build
docker compose ps
```

## 23. 正常系確認

```bash
curl -s -i http://127.0.0.1:8080/api/healthz | head -5
curl -s http://127.0.0.1:8080/api/readyz | python3 -m json.tool
curl -s -H 'X-Request-ID: manual-check-0001' 'http://127.0.0.1:8080/api/v1/snowflake/info' | python3 -m json.tool
curl -s 'http://127.0.0.1:8080/api/v1/tables?schema=PUBLIC&limit=5' | python3 -m json.tool
docker compose logs --no-log-prefix api | grep manual-check-0001
```

| 確認 | 期待値 |
| --- | --- |
| `healthz` | `HTTP/1.1 200`、`X-Request-ID` ヘッダーあり |
| `readyz` (設定済み) | `{"status": "ready", ...}` |
| `snowflake/info` | `snowflake_version` などが返る |
| ログ | `"correlation_id": "manual-check-0001"` の JSON 行が nginx と api の両方にある |

テスト (イメージ内で実行。ホストに Python / Node の依存は不要):

```bash
docker build --target test ./api
docker build ./frontend        # ビルド中に npm test / 型検査 / vite build を実行
```

## 24. 異常系確認

```bash
# 入力検証 → 422 VALIDATION_ERROR (入力値は応答に含まれない)
curl -s "http://127.0.0.1:8080/api/v1/tables?schema=PUBLIC';DROP" | python3 -m json.tool
# 範囲外 → 422
curl -s "http://127.0.0.1:8080/api/v1/tables?limit=1000" | python3 -m json.tool
```

| 状況 | 期待値 |
| --- | --- |
| `.env` 未作成 | 両コンテナ healthy、`readyz` = 503 `not_configured`、`missing_settings` に不足項目名 |
| 鍵ファイルなし | `readyz` = 503 `SNOWFLAKE_NOT_CONFIGURED`、`detail.setting = SNOWFLAKE_PRIVATE_KEY_FILE` |
| 誤ったアカウント識別子 / 外向き不可 | `SNOWFLAKE_UNREACHABLE` (errno 250001) |
| 誤った鍵 / 未登録の公開鍵 | `SNOWFLAKE_AUTH_FAILED` |
| ウェアハウス停止中で応答が遅い | `SNOWFLAKE_TIMEOUT` (504) |

## 25. ログと監視

- すべて JSON 1 行形式で標準出力へ。主なキー: `timestamp`、`level`、`logger`、`message`、`correlation_id`、`event`。
- `event` の種類: `http_request` (アクセスログ)、`snowflake_query` (`query_name`、`row_count`、`duration_ms`、失敗時は `error_code`、`driver_errno`)、`app_error`、`validation_error`、`unhandled_exception`。
- キー名に `password` / `token` / `secret` / `private_key` 等を含む値は `[REDACTED]` に置き換わる。
- SQL の値、入力値、Snowflake のエラーメッセージ本文はログに出さない。

```bash
docker compose logs --no-log-prefix api | python3 -c 'import sys,json; [print(json.loads(l)["event"] if l.startswith("{") else l.strip()) for l in sys.stdin]' | sort | uniq -c
```

## 26. 停止手順

```bash
docker compose stop      # 停止 (コンテナは残る)
docker compose start     # 再開
```

## 27. 個別削除

```bash
docker compose rm -sf frontend          # フロントエンドだけ削除
docker compose up -d --build frontend   # 再作成
```

## 28. 全体削除

```bash
docker compose down --volumes --rmi local
rm -f .env
sudo rm -rf secrets
```

> [!WARNING]
> `secrets/` を削除すると Snowflake の鍵がこの EC2 から消える。鍵の正本は Snowflake 管理者の手順に従って別途保管していること。

## 29. 週末前の退避

コードは Git へ push する。`.env` と `secrets/` は退避しない (EC2 と一緒に削除されてよい)。Snowflake 上のデータは Snowflake が正本。

## 30. 週末後の再構築

1. Pattern 02 の再構築と `check-devhost.sh` の PASS。
2. §22 の clone → `.env` 作成 → §19 の資格情報ファイル配置。
3. `docker compose up -d --build` → §23 の確認。

## 31. トラブルシューティング

| 症状 | 参照 |
| --- | --- |
| `readyz` が 503 | §13 エラーコード表と [06 Snowflake](../../06_troubleshooting/README.md#snowflake-へ接続できない) |
| `frontend` が起動しない (`api` を待ち続ける) | `docker compose logs api`。API の起動失敗時は依存関係で frontend も起動しない |
| ビルドで依存の取得に失敗 | [06 pull](../../06_troubleshooting/README.md#イメージの-pull--パッケージの取得に失敗する) |
| `permission denied` (鍵ファイル) | 所有者が `10001:10001`、権限 `400` か |

## 32. コスト

AWS 追加費用なし (Pattern 02 の EC2 のみ)。Snowflake はクエリ実行時にウェアハウスのクレジットを消費する。検証用ウェアハウスは `XSMALL` と自動停止 (`AUTO_SUSPEND = 60`) を推奨。

## 33. 未確定事項

U-12、U-13、U-14 ([未確定事項台帳](../../01_constraints/unconfirmed-items.md))。

## 34. 更新履歴

| 日付 | 内容 |
| --- | --- |
| 2026-09-29 | 初版 |
