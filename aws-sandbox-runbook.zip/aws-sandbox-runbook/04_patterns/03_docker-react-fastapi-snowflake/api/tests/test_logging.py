from __future__ import annotations

import json
import logging

from app.logging_config import JsonFormatter, correlation_id_var, redact


def test_json_log_contains_correlation_id_and_redacts_secrets() -> None:
    token = correlation_id_var.set("cid-0001")
    try:
        record = logging.makeLogRecord(
            {
                "name": "app",
                "levelname": "INFO",
                "levelno": 20,
                "msg": "hello",
                "password": "p@ss",
                "nested": {"api_token": "t"},
            }
        )
        line = json.loads(JsonFormatter().format(record))
    finally:
        correlation_id_var.reset(token)
    assert line["correlation_id"] == "cid-0001"
    assert line["message"] == "hello"
    assert line["password"] == "[REDACTED]"
    assert line["nested"]["api_token"] == "[REDACTED]"
    assert "timestamp" in line and line["level"] == "INFO"


def test_redact_keeps_non_sensitive_values() -> None:
    assert redact({"row_count": 3, "items": [{"secret_key": 1}]}) == {
        "row_count": 3,
        "items": [{"secret_key": "[REDACTED]"}],
    }
