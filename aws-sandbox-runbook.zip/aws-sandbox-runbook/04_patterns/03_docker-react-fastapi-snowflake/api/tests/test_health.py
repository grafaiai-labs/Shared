from __future__ import annotations

import re

from app.errors import SnowflakeAuthError
from tests.conftest import CONFIGURED, FakeSnowflakeClient


def test_healthz_is_ok_without_snowflake(make_client):
    client, fake = make_client()
    res = client.get("/healthz")
    assert res.status_code == 200
    assert res.json()["status"] == "ok"
    assert re.fullmatch(r"[0-9a-f]{32}", res.headers["X-Request-ID"])
    assert fake.calls == []


def test_incoming_correlation_id_is_propagated(make_client):
    client, _ = make_client()
    res = client.get("/healthz", headers={"X-Request-ID": "req-12345678"})
    assert res.headers["X-Request-ID"] == "req-12345678"


def test_malformed_correlation_id_is_replaced(make_client):
    client, _ = make_client()
    res = client.get("/healthz", headers={"X-Request-ID": "bad id\x7f"})
    assert re.fullmatch(r"[0-9a-f]{32}", res.headers["X-Request-ID"])


def test_readyz_reports_missing_settings_by_name(make_client):
    client, fake = make_client({"snowflake_account": "<SNOWFLAKE_ACCOUNT_IDENTIFIER>"})
    res = client.get("/readyz")
    assert res.status_code == 503
    check = res.json()["checks"]["snowflake"]
    assert check["status"] == "not_configured"
    assert check["error_code"] == "SNOWFLAKE_NOT_CONFIGURED"
    assert "SNOWFLAKE_ACCOUNT" in check["missing_settings"]
    assert "SNOWFLAKE_SECRET_FILE" not in check["missing_settings"]  # keypair is the default method
    assert "SNOWFLAKE_PRIVATE_KEY_FILE" in check["missing_settings"]
    assert fake.calls == []


def test_readyz_ready_when_ping_succeeds(make_client):
    client, fake = make_client(CONFIGURED, FakeSnowflakeClient(rows=[{"OK": 1}]))
    res = client.get("/readyz")
    assert res.status_code == 200
    assert res.json() == {
        "status": "ready",
        "checks": {"snowflake": {"status": "ok", "error_code": None, "missing_settings": []}},
    }
    assert fake.calls[0][0] == "readiness_ping"


def test_readyz_distinguishes_auth_failure(make_client):
    client, _ = make_client(CONFIGURED, FakeSnowflakeClient(error=SnowflakeAuthError()))
    res = client.get("/readyz")
    assert res.status_code == 503
    assert res.json()["checks"]["snowflake"]["status"] == "error"
    assert res.json()["checks"]["snowflake"]["error_code"] == "SNOWFLAKE_AUTH_FAILED"
