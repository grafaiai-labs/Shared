from __future__ import annotations

from datetime import UTC, datetime

from app.errors import SnowflakeQueryError
from tests.conftest import CONFIGURED, FakeSnowflakeClient

TABLE_ROWS = [
    {
        "TABLE_NAME": "ORDERS",
        "TABLE_TYPE": "BASE TABLE",
        "ROW_COUNT": 10,
        "LAST_ALTERED": datetime(2026, 9, 1, tzinfo=UTC),
    },
    {"TABLE_NAME": "V_ORDERS", "TABLE_TYPE": "VIEW", "ROW_COUNT": None, "LAST_ALTERED": None},
]


def test_tables_binds_validated_parameters(make_client):
    client, fake = make_client(CONFIGURED, FakeSnowflakeClient(rows=TABLE_ROWS))
    res = client.get("/api/v1/tables", params={"schema": "public", "limit": 5})
    assert res.status_code == 200
    body = res.json()
    assert body["database"] == "DUMMY_DB"
    assert body["schema_name"] == "PUBLIC"
    assert body["count"] == 2
    name, sql, params = fake.calls[0]
    assert name == "list_tables"
    assert "%(schema)s" in sql and "public" not in sql.lower().replace("information_schema", "")
    assert params == {"schema": "PUBLIC", "limit": 5}


def test_tables_rejects_injection_without_echoing_input(make_client):
    client, fake = make_client(CONFIGURED)
    payload = "PUBLIC';DROP TABLE X;--"
    res = client.get("/api/v1/tables", params={"schema": payload})
    assert res.status_code == 422
    body = res.json()
    assert body["error"]["code"] == "VALIDATION_ERROR"
    assert body["error"]["correlation_id"] == res.headers["X-Request-ID"]
    assert "DROP" not in res.text
    assert fake.calls == []


def test_tables_limit_out_of_range(make_client):
    client, _ = make_client(CONFIGURED)
    res = client.get("/api/v1/tables", params={"limit": 1000})
    assert res.status_code == 422
    assert res.json()["error"]["detail"]["errors"][0]["loc"] == ["query", "limit"]


def test_tables_requires_database(make_client):
    settings = {k: v for k, v in CONFIGURED.items() if k != "snowflake_database"}
    client, fake = make_client(settings)
    res = client.get("/api/v1/tables")
    assert res.status_code == 503
    assert res.json()["error"]["code"] == "SNOWFLAKE_NOT_CONFIGURED"
    assert res.json()["error"]["detail"]["missing_settings"] == ["SNOWFLAKE_DATABASE"]
    assert fake.calls == []


def test_driver_error_is_returned_with_stable_code(make_client):
    client, _ = make_client(CONFIGURED, FakeSnowflakeClient(error=SnowflakeQueryError(detail={"driver_errno": 2003})))
    res = client.get("/api/v1/tables")
    assert res.status_code == 502
    assert res.json()["error"]["code"] == "SNOWFLAKE_QUERY_FAILED"


def test_request_timeout(make_client):
    settings = {**CONFIGURED, "request_timeout_seconds": 0.05}
    client, _ = make_client(settings, FakeSnowflakeClient(rows=TABLE_ROWS, delay=0.3))
    res = client.get("/api/v1/tables")
    assert res.status_code == 504
    assert res.json()["error"]["code"] == "SNOWFLAKE_TIMEOUT"


def test_unhandled_exception_returns_safe_500(make_client):
    client, _ = make_client(CONFIGURED, FakeSnowflakeClient(error=RuntimeError("secret-ish internal text")))
    res = client.get("/api/v1/snowflake/info")
    assert res.status_code == 500
    body = res.json()
    assert body["error"]["code"] == "INTERNAL_ERROR"
    assert body["error"]["correlation_id"] == res.headers["X-Request-ID"]
    assert "secret-ish" not in res.text


def test_snowflake_info(make_client):
    row = {
        "SNOWFLAKE_VERSION": "9.30.0",
        "CURRENT_ROLE": "DUMMY_ROLE",
        "CURRENT_WAREHOUSE": "DUMMY_WH",
        "CURRENT_DATABASE": "DUMMY_DB",
        "CURRENT_SCHEMA": None,
        "SERVER_TIME": datetime(2026, 9, 29, tzinfo=UTC),
    }
    client, _ = make_client(CONFIGURED, FakeSnowflakeClient(rows=[row]))
    res = client.get("/api/v1/snowflake/info")
    assert res.status_code == 200
    assert res.json()["snowflake_version"] == "9.30.0"
