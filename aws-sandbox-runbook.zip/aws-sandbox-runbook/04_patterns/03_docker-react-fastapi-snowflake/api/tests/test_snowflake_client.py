from __future__ import annotations

from pathlib import Path

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from snowflake.connector import errors as sf_errors

from app.config import Settings
from app.errors import (
    SnowflakeAuthError,
    SnowflakeNotConfiguredError,
    SnowflakeQueryError,
    SnowflakeTimeoutError,
    SnowflakeUnreachableError,
)
from app.snowflake_client import build_connect_kwargs, translate_error


def _settings(**overrides: object) -> Settings:
    base = {
        "snowflake_account": "dummy-account",
        "snowflake_user": "DUMMY_USER",
        "snowflake_warehouse": "DUMMY_WH",
    }
    return Settings(_env_file=None, **{**base, **overrides})  # type: ignore[arg-type]


@pytest.mark.parametrize(
    ("exc", "expected"),
    [
        (sf_errors.DatabaseError(msg="x", errno=390100), SnowflakeAuthError),
        (sf_errors.DatabaseError(msg="x", errno=390144), SnowflakeAuthError),
        (sf_errors.OperationalError(msg="x", errno=250001), SnowflakeUnreachableError),
        (sf_errors.ProgrammingError(msg="x", errno=604), SnowflakeTimeoutError),
        (sf_errors.ProgrammingError(msg="x", errno=2003), SnowflakeQueryError),
        (ConnectionResetError(), SnowflakeUnreachableError),
    ],
)
def test_translate_error(exc: Exception, expected: type) -> None:
    translated = translate_error(exc)
    assert isinstance(translated, expected)
    assert "x" not in translated.message.split()


def test_keypair_kwargs(tmp_path: Path) -> None:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    key_file = tmp_path / "rsa_key.p8"
    key_file.write_bytes(
        key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
    )
    kwargs = build_connect_kwargs(
        _settings(snowflake_private_key_file=key_file, snowflake_statement_timeout_seconds=12)
    )
    assert kwargs["authenticator"] == "SNOWFLAKE_JWT"
    assert isinstance(kwargs["private_key"], bytes)
    assert "password" not in kwargs
    assert kwargs["session_parameters"]["STATEMENT_TIMEOUT_IN_SECONDS"] == 12
    assert kwargs["login_timeout"] == 10
    assert "role" not in kwargs  # unset optional values are omitted


def test_encrypted_key_with_wrong_passphrase(tmp_path: Path) -> None:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    key_file = tmp_path / "rsa_key.p8"
    key_file.write_bytes(
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.BestAvailableEncryption(b"correct-passphrase"),
        )
    )
    pass_file = tmp_path / "passphrase"
    pass_file.write_text("wrong-passphrase\n")
    with pytest.raises(SnowflakeAuthError):
        build_connect_kwargs(
            _settings(snowflake_private_key_file=key_file, snowflake_private_key_passphrase_file=pass_file)
        )


def test_missing_key_file_is_not_configured(tmp_path: Path) -> None:
    with pytest.raises(SnowflakeNotConfiguredError) as info:
        build_connect_kwargs(_settings(snowflake_private_key_file=tmp_path / "missing.p8"))
    assert info.value.detail["setting"] == "SNOWFLAKE_PRIVATE_KEY_FILE"


def test_pat_is_read_from_file(tmp_path: Path) -> None:
    secret = tmp_path / "pat"
    secret.write_text("dummy-token-value\n")
    kwargs = build_connect_kwargs(_settings(snowflake_auth_method="pat", snowflake_secret_file=secret))
    assert kwargs["password"] == "dummy-token-value"
    assert "authenticator" not in kwargs


def test_placeholder_values_are_not_configured() -> None:
    settings = _settings(snowflake_account="<SNOWFLAKE_ACCOUNT_IDENTIFIER>")
    assert "SNOWFLAKE_ACCOUNT" in settings.snowflake_missing_settings()
