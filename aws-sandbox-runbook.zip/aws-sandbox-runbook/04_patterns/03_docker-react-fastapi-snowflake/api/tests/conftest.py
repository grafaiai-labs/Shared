from __future__ import annotations

import time
from collections.abc import Callable, Iterator, Mapping
from typing import Any

import pytest
from fastapi.testclient import TestClient

from app.config import Settings, get_settings
from app.main import app, get_snowflake_client

CONFIGURED = {
    "snowflake_account": "dummy-account",
    "snowflake_user": "DUMMY_USER",
    "snowflake_warehouse": "DUMMY_WH",
    "snowflake_database": "DUMMY_DB",
    "snowflake_auth_method": "pat",
    "snowflake_secret_file": "/run/secrets/app/does-not-matter",
}


class FakeSnowflakeClient:
    def __init__(
        self, rows: list[dict[str, Any]] | None = None, error: Exception | None = None, delay: float = 0
    ) -> None:
        self.rows = rows or []
        self.error = error
        self.delay = delay
        self.calls: list[tuple[str, str, Mapping[str, Any] | None]] = []

    def query(self, name: str, sql: str, params: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
        self.calls.append((name, sql, params))
        if self.delay:
            time.sleep(self.delay)
        if self.error:
            raise self.error
        return self.rows


@pytest.fixture
def make_client() -> Iterator[Callable[..., tuple[TestClient, FakeSnowflakeClient]]]:
    def factory(
        settings: dict[str, Any] | None = None, fake: FakeSnowflakeClient | None = None
    ) -> tuple[TestClient, FakeSnowflakeClient]:
        resolved = Settings(_env_file=None, **(settings or {}))  # type: ignore[call-arg]
        fake = fake or FakeSnowflakeClient()
        app.dependency_overrides[get_settings] = lambda: resolved
        app.dependency_overrides[get_snowflake_client] = lambda: fake
        return TestClient(app, raise_server_exceptions=False), fake

    yield factory
    app.dependency_overrides.clear()
