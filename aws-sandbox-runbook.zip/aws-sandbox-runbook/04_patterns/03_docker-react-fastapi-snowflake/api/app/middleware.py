"""Correlation ID + access log middleware (pure ASGI)."""

from __future__ import annotations

import json
import logging
import re
import time
import uuid

from starlette.datastructures import MutableHeaders
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from .logging_config import correlation_id_var

logger = logging.getLogger("app.access")

HEADER = "X-Request-ID"
_VALID_ID = re.compile(r"^[A-Za-z0-9._-]{8,128}$")


def resolve_correlation_id(incoming: str | None) -> str:
    """Accept a well-formed incoming ID (from nginx/the browser); otherwise generate one."""
    if incoming and _VALID_ID.fullmatch(incoming):
        return incoming
    return uuid.uuid4().hex


class CorrelationIdMiddleware:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        raw = dict(scope.get("headers") or []).get(HEADER.lower().encode("latin-1"), b"")
        correlation_id = resolve_correlation_id(raw.decode("latin-1") if raw else None)
        correlation_id_var.set(correlation_id)
        started = time.perf_counter()
        response_started = False
        status_code = 500

        async def send_with_header(message: Message) -> None:
            nonlocal response_started, status_code
            if message["type"] == "http.response.start":
                response_started = True
                status_code = message["status"]
                MutableHeaders(scope=message)[HEADER] = correlation_id
            await send(message)

        try:
            await self.app(scope, receive, send_with_header)
        except Exception:
            # Unhandled errors are answered here so that the response still carries the correlation ID.
            logger.exception("unhandled exception", extra={"event": "unhandled_exception"})
            if not response_started:
                body = json.dumps(
                    {
                        "error": {
                            "code": "INTERNAL_ERROR",
                            "message": "Unexpected error.",
                            "correlation_id": correlation_id,
                            "detail": {},
                        }
                    }
                ).encode()
                await send_with_header(
                    {
                        "type": "http.response.start",
                        "status": 500,
                        "headers": [
                            (b"content-type", b"application/json"),
                            (b"content-length", str(len(body)).encode()),
                        ],
                    }
                )
                await send({"type": "http.response.body", "body": body})
        finally:
            logger.info(
                "request completed",
                extra={
                    "event": "http_request",
                    "method": scope.get("method"),
                    "path": scope.get("path"),
                    "status": status_code,
                    "duration_ms": round((time.perf_counter() - started) * 1000, 1),
                },
            )
