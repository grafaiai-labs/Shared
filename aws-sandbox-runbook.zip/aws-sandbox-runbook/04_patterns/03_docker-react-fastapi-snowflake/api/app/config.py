"""Application settings loaded from environment variables.

Secrets are never passed as environment variables: only *file paths* to credential files
mounted read-only into the container are configured here.
"""

from __future__ import annotations

import re
from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

_PLACEHOLDER = re.compile(r"^<[A-Z0-9_]+>$")

AuthMethod = Literal["keypair", "pat", "password"]


def _is_set(value: str | Path | None) -> bool:
    """Treat empty values and unreplaced ``<PLACEHOLDER>`` values as not configured."""
    if value is None:
        return False
    text = str(value).strip()
    return bool(text) and not _PLACEHOLDER.match(text)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(extra="ignore", frozen=True)

    app_env: Literal["local", "sandbox"] = "local"
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"

    snowflake_account: str | None = None
    snowflake_user: str | None = None
    snowflake_role: str | None = None
    snowflake_warehouse: str | None = None
    snowflake_database: str | None = None
    snowflake_schema: str | None = None
    snowflake_auth_method: AuthMethod = "keypair"
    # keypair: PKCS#8 private key file (+ optional passphrase file)
    snowflake_private_key_file: Path | None = None
    snowflake_private_key_passphrase_file: Path | None = None
    # pat / password: file containing the token or password
    snowflake_secret_file: Path | None = None

    snowflake_login_timeout_seconds: int = Field(default=10, ge=1, le=60)
    snowflake_network_timeout_seconds: int = Field(default=30, ge=1, le=120)
    snowflake_statement_timeout_seconds: int = Field(default=30, ge=1, le=600)
    request_timeout_seconds: float = Field(default=45.0, gt=0, le=300)

    def snowflake_missing_settings(self) -> list[str]:
        """Return the names (never the values) of settings required but not configured."""
        required: dict[str, str | Path | None] = {
            "SNOWFLAKE_ACCOUNT": self.snowflake_account,
            "SNOWFLAKE_USER": self.snowflake_user,
            "SNOWFLAKE_WAREHOUSE": self.snowflake_warehouse,
        }
        if self.snowflake_auth_method == "keypair":
            required["SNOWFLAKE_PRIVATE_KEY_FILE"] = self.snowflake_private_key_file
        else:
            required["SNOWFLAKE_SECRET_FILE"] = self.snowflake_secret_file
        return [name for name, value in required.items() if not _is_set(value)]

    @property
    def snowflake_configured(self) -> bool:
        return not self.snowflake_missing_settings()

    def optional(self, value: str | None) -> str | None:
        return value if _is_set(value) else None


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
