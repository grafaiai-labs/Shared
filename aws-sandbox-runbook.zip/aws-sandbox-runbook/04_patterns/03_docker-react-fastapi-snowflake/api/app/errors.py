"""Application error types with stable, client-safe error codes."""

from __future__ import annotations


class AppError(Exception):
    """Base error. ``message`` must be safe to return to clients (no secrets, no raw driver text)."""

    code = "INTERNAL_ERROR"
    status_code = 500
    message = "Unexpected error."

    def __init__(self, message: str | None = None, *, detail: dict[str, object] | None = None) -> None:
        super().__init__(message or self.message)
        if message:
            self.message = message
        self.detail = detail or {}


class SnowflakeNotConfiguredError(AppError):
    code = "SNOWFLAKE_NOT_CONFIGURED"
    status_code = 503
    message = "Snowflake connection settings are not configured."


class SnowflakeAuthError(AppError):
    code = "SNOWFLAKE_AUTH_FAILED"
    status_code = 503
    message = "Snowflake authentication failed. Check user, role and credential file."


class SnowflakeUnreachableError(AppError):
    code = "SNOWFLAKE_UNREACHABLE"
    status_code = 503
    message = "Snowflake could not be reached. Check account identifier and outbound HTTPS."


class SnowflakeTimeoutError(AppError):
    code = "SNOWFLAKE_TIMEOUT"
    status_code = 504
    message = "Snowflake did not respond within the configured timeout."


class SnowflakeQueryError(AppError):
    code = "SNOWFLAKE_QUERY_FAILED"
    status_code = 502
    message = "Snowflake rejected the query. Check object names and privileges."
