"""FastAPI backend: the only component that talks to Snowflake."""

__version__ = "0.1.0"
