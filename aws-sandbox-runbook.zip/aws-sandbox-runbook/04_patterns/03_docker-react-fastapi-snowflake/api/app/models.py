"""Pydantic request/response models."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    status: Literal["ok"] = "ok"
    version: str


class SnowflakeCheck(BaseModel):
    status: Literal["ok", "not_configured", "error"]
    error_code: str | None = None
    missing_settings: list[str] = Field(default_factory=list)


class ReadinessResponse(BaseModel):
    status: Literal["ready", "not_ready"]
    checks: dict[str, SnowflakeCheck]


class SnowflakeInfo(BaseModel):
    snowflake_version: str
    current_role: str | None
    current_warehouse: str | None
    current_database: str | None
    current_schema: str | None
    server_time: datetime


class TableInfo(BaseModel):
    name: str
    table_type: str
    row_count: int | None
    last_altered: datetime | None


class TablesResponse(BaseModel):
    database: str
    schema_name: str
    count: int
    items: list[TableInfo]


class ErrorBody(BaseModel):
    code: str
    message: str
    correlation_id: str
    detail: dict[str, object] = Field(default_factory=dict)


class ErrorResponse(BaseModel):
    error: ErrorBody
