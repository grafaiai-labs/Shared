"""Snowflake access layer: connection settings, timeouts and error translation.

Each call opens a short-lived connection. This keeps the sample simple and avoids stale sessions;
switch to a connection pool only when latency becomes a measured problem.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Mapping
from pathlib import Path
from typing import Any, Protocol

from cryptography.hazmat.primitives import serialization
from snowflake.connector import DictCursor, connect
from snowflake.connector import errors as sf_errors

from .config import Settings
from .errors import (
    AppError,
    SnowflakeAuthError,
    SnowflakeNotConfiguredError,
    SnowflakeQueryError,
    SnowflakeTimeoutError,
    SnowflakeUnreachableError,
)

logger = logging.getLogger(__name__)

MAX_ROWS = 500
# Snowflake login (GS) errors are reported in the 390xxx range (e.g. 390100 incorrect credentials,
# 390144 invalid JWT). Treating the whole range as authentication failures is a deliberate heuristic.
_AUTH_ERRNO_RANGE = range(390000, 391000)
_STATEMENT_CANCELLED_ERRNO = 604


class SnowflakeClient(Protocol):
    def query(self, name: str, sql: str, params: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
        """Run a read-only query and return at most ``MAX_ROWS`` rows."""
        ...


def translate_error(exc: Exception) -> AppError:
    """Map driver exceptions to client-safe application errors (never expose raw driver messages)."""
    if isinstance(exc, AppError):
        return exc
    errno = getattr(exc, "errno", None)
    detail: dict[str, object] = {"driver_errno": errno, "sqlstate": getattr(exc, "sqlstate", None)}
    if isinstance(exc, sf_errors.ProgrammingError):
        if errno == _STATEMENT_CANCELLED_ERRNO:
            return SnowflakeTimeoutError(detail=detail)
        return SnowflakeQueryError(detail=detail)
    if isinstance(exc, sf_errors.DatabaseError) and isinstance(errno, int) and errno in _AUTH_ERRNO_RANGE:
        return SnowflakeAuthError(detail=detail)
    if isinstance(exc, sf_errors.Error | OSError):
        return SnowflakeUnreachableError(detail=detail)
    return AppError(detail={"exception_type": type(exc).__name__})


def _read_secret_file(path: Path | None, setting: str) -> bytes:
    if path is None:
        raise SnowflakeNotConfiguredError(detail={"missing_settings": [setting]})
    try:
        return path.read_bytes().strip()
    except OSError as exc:
        raise SnowflakeNotConfiguredError(
            "A Snowflake credential file could not be read.",
            detail={"setting": setting, "reason": type(exc).__name__},
        ) from None


def load_private_key_der(key_file: Path | None, passphrase_file: Path | None) -> bytes:
    pem = _read_secret_file(key_file, "SNOWFLAKE_PRIVATE_KEY_FILE")
    passphrase = (
        _read_secret_file(passphrase_file, "SNOWFLAKE_PRIVATE_KEY_PASSPHRASE_FILE") if passphrase_file else None
    )
    try:
        key = serialization.load_pem_private_key(pem, password=passphrase)
    except (ValueError, TypeError):
        raise SnowflakeAuthError(
            "The Snowflake private key could not be loaded (format or passphrase).",
            detail={"reason": "invalid_private_key"},
        ) from None
    return key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


def build_connect_kwargs(settings: Settings) -> dict[str, Any]:
    missing = settings.snowflake_missing_settings()
    if missing:
        raise SnowflakeNotConfiguredError(detail={"missing_settings": missing})

    kwargs: dict[str, Any] = {
        "account": settings.snowflake_account,
        "user": settings.snowflake_user,
        "warehouse": settings.snowflake_warehouse,
        "role": settings.optional(settings.snowflake_role),
        "database": settings.optional(settings.snowflake_database),
        "schema": settings.optional(settings.snowflake_schema),
        "login_timeout": settings.snowflake_login_timeout_seconds,
        "network_timeout": settings.snowflake_network_timeout_seconds,
        "socket_timeout": settings.snowflake_network_timeout_seconds,
        "client_session_keep_alive": False,
        "session_parameters": {
            "STATEMENT_TIMEOUT_IN_SECONDS": settings.snowflake_statement_timeout_seconds,
            "QUERY_TAG": "sample-api",
        },
    }
    if settings.snowflake_auth_method == "keypair":
        kwargs["authenticator"] = "SNOWFLAKE_JWT"
        kwargs["private_key"] = load_private_key_der(
            settings.snowflake_private_key_file, settings.snowflake_private_key_passphrase_file
        )
    else:
        # A programmatic access token (PAT) is passed in place of a password.
        kwargs["password"] = _read_secret_file(settings.snowflake_secret_file, "SNOWFLAKE_SECRET_FILE").decode()
    return {k: v for k, v in kwargs.items() if v is not None}


class ConnectorSnowflakeClient:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings

    def query(self, name: str, sql: str, params: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
        started = time.perf_counter()
        try:
            kwargs = build_connect_kwargs(self._settings)
            with connect(**kwargs) as conn, conn.cursor(DictCursor) as cur:
                cur.execute(sql, params, timeout=self._settings.snowflake_statement_timeout_seconds)
                rows = cur.fetchmany(MAX_ROWS)
        except Exception as exc:
            error = translate_error(exc)
            logger.warning(
                "snowflake query failed",
                extra={
                    "event": "snowflake_query",
                    "query_name": name,
                    "error_code": error.code,
                    "duration_ms": round((time.perf_counter() - started) * 1000, 1),
                    **{k: v for k, v in error.detail.items() if k in ("driver_errno", "sqlstate", "reason")},
                },
            )
            raise error from None
        logger.info(
            "snowflake query succeeded",
            extra={
                "event": "snowflake_query",
                "query_name": name,
                "row_count": len(rows),
                "duration_ms": round((time.perf_counter() - started) * 1000, 1),
            },
        )
        return [dict(row) for row in rows]
