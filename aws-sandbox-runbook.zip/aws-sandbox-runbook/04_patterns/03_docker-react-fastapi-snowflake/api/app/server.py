"""Container entry point: JSON logging first, then uvicorn without its own log config."""

from __future__ import annotations

import uvicorn

from .config import get_settings
from .logging_config import configure_logging


def main() -> None:
    settings = get_settings()
    configure_logging(settings.log_level)
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        log_config=None,
        access_log=False,
        server_header=False,
        timeout_graceful_shutdown=10,
    )


if __name__ == "__main__":
    main()
