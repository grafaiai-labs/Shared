"""FastAPI application.

The React frontend never talks to Snowflake directly: every Snowflake call goes through this API,
which owns the credentials, validates input, applies timeouts and returns stable error codes.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable
from typing import Annotated, Any

from fastapi import Depends, FastAPI, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.concurrency import run_in_threadpool

from . import __version__
from .config import Settings, get_settings
from .errors import AppError, SnowflakeNotConfiguredError, SnowflakeTimeoutError
from .logging_config import configure_logging, correlation_id_var
from .middleware import CorrelationIdMiddleware
from .models import (
    ErrorResponse,
    HealthResponse,
    ReadinessResponse,
    SnowflakeCheck,
    SnowflakeInfo,
    TableInfo,
    TablesResponse,
)
from .snowflake_client import ConnectorSnowflakeClient, SnowflakeClient

logger = logging.getLogger("app")

# Unquoted Snowflake identifier. Quoted identifiers are intentionally not accepted by this sample.
IDENTIFIER_PATTERN = r"^[A-Za-z_][A-Za-z0-9_$]{0,254}$"

configure_logging(get_settings().log_level)

app = FastAPI(
    title="Sample API (React + FastAPI + Snowflake)",
    version=__version__,
    responses={503: {"model": ErrorResponse}, 504: {"model": ErrorResponse}},
)
app.add_middleware(CorrelationIdMiddleware)

SettingsDep = Annotated[Settings, Depends(get_settings)]


def get_snowflake_client(settings: SettingsDep) -> SnowflakeClient:
    return ConnectorSnowflakeClient(settings)


ClientDep = Annotated[SnowflakeClient, Depends(get_snowflake_client)]


def _error_json(status_code: int, code: str, message: str, detail: dict[str, Any] | None = None) -> JSONResponse:
    body = {
        "error": {
            "code": code,
            "message": message,
            "correlation_id": correlation_id_var.get(),
            "detail": detail or {},
        }
    }
    return JSONResponse(status_code=status_code, content=body)


@app.exception_handler(AppError)
async def app_error_handler(_: Request, exc: AppError) -> JSONResponse:
    logger.warning("request failed", extra={"event": "app_error", "error_code": exc.code})
    return _error_json(exc.status_code, exc.code, exc.message, exc.detail)


@app.exception_handler(RequestValidationError)
async def validation_error_handler(_: Request, exc: RequestValidationError) -> JSONResponse:
    # Echo only location and reason, never the submitted value.
    errors = [{"loc": list(e.get("loc", [])), "msg": e.get("msg", ""), "type": e.get("type", "")} for e in exc.errors()]
    logger.info("validation failed", extra={"event": "validation_error", "error_count": len(errors)})
    return _error_json(422, "VALIDATION_ERROR", "Request validation failed.", {"errors": errors})


async def _run_blocking[T](settings: Settings, func: Callable[..., T], *args: Any) -> T:  # noqa: ANN401
    """Run a blocking driver call in the thread pool with an overall deadline."""
    try:
        return await asyncio.wait_for(run_in_threadpool(func, *args), timeout=settings.request_timeout_seconds)
    except TimeoutError:
        raise SnowflakeTimeoutError(detail={"timeout_seconds": settings.request_timeout_seconds}) from None


@app.get("/healthz", response_model=HealthResponse, tags=["health"])
async def healthz() -> HealthResponse:
    """Liveness: does not touch Snowflake, so it stays green while Snowflake is not configured."""
    return HealthResponse(version=__version__)


@app.get("/readyz", response_model=ReadinessResponse, tags=["health"], responses={503: {"model": ReadinessResponse}})
async def readyz(settings: SettingsDep, client: ClientDep) -> JSONResponse:
    """Readiness: tells apart 'not configured' from 'configured but failing' without exposing secrets."""
    missing = settings.snowflake_missing_settings()
    if missing:
        check = SnowflakeCheck(
            status="not_configured", error_code=SnowflakeNotConfiguredError.code, missing_settings=missing
        )
    else:
        try:
            await _run_blocking(settings, client.query, "readiness_ping", "SELECT 1 AS OK")
            check = SnowflakeCheck(status="ok")
        except AppError as exc:
            missing_detail = exc.detail.get("missing_settings", [])
            check = SnowflakeCheck(
                status="not_configured" if isinstance(exc, SnowflakeNotConfiguredError) else "error",
                error_code=exc.code,
                missing_settings=missing_detail if isinstance(missing_detail, list) else [],
            )
    ready = check.status == "ok"
    body = ReadinessResponse(status="ready" if ready else "not_ready", checks={"snowflake": check})
    return JSONResponse(status_code=200 if ready else 503, content=body.model_dump())


@app.get("/api/v1/snowflake/info", response_model=SnowflakeInfo, tags=["snowflake"])
async def snowflake_info(settings: SettingsDep, client: ClientDep) -> SnowflakeInfo:
    rows = await _run_blocking(
        settings,
        client.query,
        "snowflake_info",
        "SELECT CURRENT_VERSION() AS SNOWFLAKE_VERSION, CURRENT_ROLE() AS CURRENT_ROLE, "
        "CURRENT_WAREHOUSE() AS CURRENT_WAREHOUSE, CURRENT_DATABASE() AS CURRENT_DATABASE, "
        "CURRENT_SCHEMA() AS CURRENT_SCHEMA, CURRENT_TIMESTAMP() AS SERVER_TIME",
    )
    row = rows[0]
    return SnowflakeInfo(
        snowflake_version=str(row["SNOWFLAKE_VERSION"]),
        current_role=row.get("CURRENT_ROLE"),
        current_warehouse=row.get("CURRENT_WAREHOUSE"),
        current_database=row.get("CURRENT_DATABASE"),
        current_schema=row.get("CURRENT_SCHEMA"),
        server_time=row["SERVER_TIME"],
    )


@app.get("/api/v1/tables", response_model=TablesResponse, tags=["snowflake"])
async def list_tables(
    settings: SettingsDep,
    client: ClientDep,
    schema: Annotated[str, Query(min_length=1, max_length=255, pattern=IDENTIFIER_PATTERN)] = "PUBLIC",
    limit: Annotated[int, Query(ge=1, le=100)] = 50,
) -> TablesResponse:
    """List tables of one schema in SNOWFLAKE_DATABASE. Values are bound, never concatenated."""
    database = settings.optional(settings.snowflake_database)
    if database is None:
        raise SnowflakeNotConfiguredError(
            "SNOWFLAKE_DATABASE is required for this endpoint.", detail={"missing_settings": ["SNOWFLAKE_DATABASE"]}
        )
    schema_name = schema.upper()
    rows = await _run_blocking(
        settings,
        client.query,
        "list_tables",
        "SELECT TABLE_NAME, TABLE_TYPE, ROW_COUNT, LAST_ALTERED "
        "FROM INFORMATION_SCHEMA.TABLES "
        "WHERE TABLE_SCHEMA = %(schema)s "
        "ORDER BY TABLE_NAME LIMIT %(limit)s",
        {"schema": schema_name, "limit": limit},
    )
    items = [
        TableInfo(
            name=r["TABLE_NAME"],
            table_type=r["TABLE_TYPE"],
            row_count=r.get("ROW_COUNT"),
            last_altered=r.get("LAST_ALTERED"),
        )
        for r in rows
    ]
    return TablesResponse(database=database, schema_name=schema_name, count=len(items), items=items)
