import { API_BASE_PATH, REQUEST_TIMEOUT_MS } from "./config";

export type SnowflakeCheck = {
  status: "ok" | "not_configured" | "error";
  error_code: string | null;
  missing_settings: string[];
};

export type Readiness = { status: "ready" | "not_ready"; checks: { snowflake: SnowflakeCheck } };
export type Health = { status: "ok"; version: string };
export type SnowflakeInfo = {
  snowflake_version: string;
  current_role: string | null;
  current_warehouse: string | null;
  current_database: string | null;
  current_schema: string | null;
  server_time: string;
};
export type TableInfo = { name: string; table_type: string; row_count: number | null; last_altered: string | null };
export type TablesResponse = { database: string; schema_name: string; count: number; items: TableInfo[] };

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
    readonly correlationId: string,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

// FastAPI 側の IDENTIFIER_PATTERN と同じ規則 (引用符なし識別子)
const IDENTIFIER = /^[A-Za-z_][A-Za-z0-9_$]{0,254}$/;

export function validateSchemaName(value: string): string | null {
  if (value.trim() === "") return "スキーマ名を入力してください。";
  if (!IDENTIFIER.test(value)) return "英字または _ で始まる英数字・_・$ のみ使用できます。";
  return null;
}

export function validateLimit(value: number): string | null {
  if (!Number.isInteger(value) || value < 1 || value > 100) return "件数は 1〜100 の整数で指定してください。";
  return null;
}

export function parseApiError(status: number, body: unknown, fallbackId: string): ApiError {
  const err = (body as { error?: { code?: unknown; message?: unknown; correlation_id?: unknown } } | null)?.error;
  const code = typeof err?.code === "string" ? err.code : `HTTP_${status}`;
  const message = typeof err?.message === "string" ? err.message : "予期しない応答です。";
  const id = typeof err?.correlation_id === "string" ? err.correlation_id : fallbackId;
  return new ApiError(status, code, message, id);
}

function newRequestId(): string {
  return crypto.randomUUID().replaceAll("-", "");
}

// 200 以外でも本文を返したい readyz 用に acceptStatuses を指定できる
async function request<T>(path: string, acceptStatuses: number[] = [200]): Promise<T> {
  const requestId = newRequestId();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const res = await fetch(`${API_BASE_PATH}${path}`, {
      headers: { Accept: "application/json", "X-Request-ID": requestId },
      signal: controller.signal,
    });
    const id = res.headers.get("X-Request-ID") ?? requestId;
    const body: unknown = await res.json().catch(() => null);
    if (!acceptStatuses.includes(res.status)) throw parseApiError(res.status, body, id);
    return body as T;
  } catch (e) {
    if (e instanceof ApiError) throw e;
    if (e instanceof DOMException && e.name === "AbortError") {
      throw new ApiError(0, "CLIENT_TIMEOUT", "API が時間内に応答しませんでした。", requestId);
    }
    throw new ApiError(0, "NETWORK_ERROR", "API へ接続できませんでした。", requestId);
  } finally {
    clearTimeout(timer);
  }
}

export const api = {
  health: () => request<Health>("/healthz"),
  readiness: () => request<Readiness>("/readyz", [200, 503]),
  snowflakeInfo: () => request<SnowflakeInfo>("/v1/snowflake/info"),
  tables: (schema: string, limit: number) =>
    request<TablesResponse>(`/v1/tables?${new URLSearchParams({ schema, limit: String(limit) }).toString()}`),
};
