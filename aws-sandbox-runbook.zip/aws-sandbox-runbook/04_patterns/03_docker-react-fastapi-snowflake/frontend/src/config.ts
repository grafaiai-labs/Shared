// フロントエンドの設定境界。
// ここに置けるのはブラウザへ公開してよい値だけ。Snowflake の接続情報や資格情報は置かない。
// API は同一オリジンの /api 配下 (nginx が FastAPI へ転送) を既定とする。
export const API_BASE_PATH: string = import.meta.env.VITE_API_BASE_PATH ?? "/api";
export const REQUEST_TIMEOUT_MS = 15_000;
