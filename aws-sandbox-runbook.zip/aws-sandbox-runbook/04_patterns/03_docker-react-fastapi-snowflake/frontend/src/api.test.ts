import { describe, expect, it } from "vitest";
import { ApiError, parseApiError, validateLimit, validateSchemaName } from "./api";

describe("validateSchemaName", () => {
  it("accepts unquoted identifiers", () => {
    expect(validateSchemaName("PUBLIC")).toBeNull();
    expect(validateSchemaName("_raw$1")).toBeNull();
  });
  it("rejects empty and injection-like input", () => {
    expect(validateSchemaName("")).not.toBeNull();
    expect(validateSchemaName("PUBLIC';DROP TABLE X;--")).not.toBeNull();
    expect(validateSchemaName("1abc")).not.toBeNull();
  });
});

describe("validateLimit", () => {
  it("accepts 1..100 integers only", () => {
    expect(validateLimit(1)).toBeNull();
    expect(validateLimit(100)).toBeNull();
    expect(validateLimit(0)).not.toBeNull();
    expect(validateLimit(101)).not.toBeNull();
    expect(validateLimit(1.5)).not.toBeNull();
  });
});

describe("parseApiError", () => {
  it("reads the FastAPI error envelope", () => {
    const e = parseApiError(
      503,
      { error: { code: "SNOWFLAKE_NOT_CONFIGURED", message: "not configured", correlation_id: "abc12345" } },
      "fallback",
    );
    expect(e).toBeInstanceOf(ApiError);
    expect(e.code).toBe("SNOWFLAKE_NOT_CONFIGURED");
    expect(e.correlationId).toBe("abc12345");
  });
  it("falls back for non-JSON bodies", () => {
    const e = parseApiError(502, null, "fallback-id");
    expect(e.code).toBe("HTTP_502");
    expect(e.correlationId).toBe("fallback-id");
  });
});
