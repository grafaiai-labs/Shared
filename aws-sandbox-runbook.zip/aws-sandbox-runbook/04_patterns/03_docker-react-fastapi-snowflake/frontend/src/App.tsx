import { useCallback, useEffect, useState, type FormEvent } from "react";
import {
  api,
  ApiError,
  validateLimit,
  validateSchemaName,
  type Health,
  type Readiness,
  type SnowflakeInfo,
  type TablesResponse,
} from "./api";

function ErrorView({ error }: { error: ApiError | null }) {
  if (!error) return null;
  return (
    <div className="error" role="alert">
      <strong>{error.code}</strong>: {error.message}
      <div className="muted">相関ID: {error.correlationId}</div>
    </div>
  );
}

function StatusPanel() {
  const [health, setHealth] = useState<Health | null>(null);
  const [ready, setReady] = useState<Readiness | null>(null);
  const [error, setError] = useState<ApiError | null>(null);

  const refresh = useCallback(async () => {
    setError(null);
    try {
      setHealth(await api.health());
      setReady(await api.readiness());
    } catch (e) {
      setError(e instanceof ApiError ? e : null);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const sf = ready?.checks.snowflake;
  return (
    <section>
      <h2>状態</h2>
      <button onClick={() => void refresh()}>再確認</button>
      <ul>
        <li>API: {health ? `OK (v${health.version})` : "未確認"}</li>
        <li>
          Snowflake: {sf ? sf.status : "未確認"}
          {sf?.error_code && <span className="muted"> ({sf.error_code})</span>}
        </li>
        {sf && sf.missing_settings.length > 0 && <li>未設定: {sf.missing_settings.join(", ")}</li>}
      </ul>
      <ErrorView error={error} />
    </section>
  );
}

function InfoPanel() {
  const [info, setInfo] = useState<SnowflakeInfo | null>(null);
  const [error, setError] = useState<ApiError | null>(null);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      setInfo(await api.snowflakeInfo());
    } catch (e) {
      setInfo(null);
      setError(e instanceof ApiError ? e : null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section>
      <h2>Snowflake 接続情報</h2>
      <button onClick={() => void load()} disabled={loading}>
        {loading ? "取得中..." : "取得"}
      </button>
      {info && (
        <dl>
          <dt>Version</dt>
          <dd>{info.snowflake_version}</dd>
          <dt>Role</dt>
          <dd>{info.current_role ?? "-"}</dd>
          <dt>Warehouse</dt>
          <dd>{info.current_warehouse ?? "-"}</dd>
          <dt>Database / Schema</dt>
          <dd>
            {info.current_database ?? "-"} / {info.current_schema ?? "-"}
          </dd>
          <dt>Server time</dt>
          <dd>{info.server_time}</dd>
        </dl>
      )}
      <ErrorView error={error} />
    </section>
  );
}

function TablesPanel() {
  const [schema, setSchema] = useState("PUBLIC");
  const [limit, setLimit] = useState(20);
  const [inputError, setInputError] = useState<string | null>(null);
  const [result, setResult] = useState<TablesResponse | null>(null);
  const [error, setError] = useState<ApiError | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const invalid = validateSchemaName(schema) ?? validateLimit(limit);
    setInputError(invalid);
    if (invalid) return;
    setError(null);
    try {
      setResult(await api.tables(schema, limit));
    } catch (err) {
      setResult(null);
      setError(err instanceof ApiError ? err : null);
    }
  };

  return (
    <section>
      <h2>テーブル一覧 (SNOWFLAKE_DATABASE 内)</h2>
      <form onSubmit={(e) => void submit(e)}>
        <label>
          スキーマ
          <input value={schema} onChange={(e) => setSchema(e.target.value)} maxLength={255} />
        </label>
        <label>
          件数
          <input type="number" min={1} max={100} value={limit} onChange={(e) => setLimit(Number(e.target.value))} />
        </label>
        <button type="submit">検索</button>
      </form>
      {inputError && <div className="error">{inputError}</div>}
      <ErrorView error={error} />
      {result && (
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Type</th>
              <th>Rows</th>
              <th>Last altered</th>
            </tr>
          </thead>
          <tbody>
            {result.items.map((t) => (
              <tr key={t.name}>
                <td>{t.name}</td>
                <td>{t.table_type}</td>
                <td>{t.row_count ?? "-"}</td>
                <td>{t.last_altered ?? "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}

export default function App() {
  return (
    <main>
      <h1>React + FastAPI + Snowflake</h1>
      <p className="muted">ブラウザは FastAPI だけに接続します。Snowflake の資格情報はブラウザへ渡りません。</p>
      <StatusPanel />
      <InfoPanel />
      <TablesPanel />
    </main>
  );
}
