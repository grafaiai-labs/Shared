import react from "@vitejs/plugin-react";
import { defineConfig, loadEnv } from "vite";

// ブラウザへ埋め込まれるのは VITE_ で始まる変数だけ。
// 秘密情報らしい名前の VITE_ 変数があればビルドを失敗させる (環境変数の境界)。
const FORBIDDEN = /(SECRET|TOKEN|PASSWORD|PASSPHRASE|PRIVATE|SNOWFLAKE|CREDENTIAL|KEY)/i;

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "VITE_");
  const leaked = Object.keys(env).filter((name) => FORBIDDEN.test(name));
  if (leaked.length > 0) {
    throw new Error(`Secret-like variables must not be exposed to the browser: ${leaked.join(", ")}`);
  }
  return {
    plugins: [react()],
    server: {
      // ローカル開発時 (npm run dev) は API へプロキシする。本番相当は nginx が同じ役割を持つ。
      proxy: { "/api": { target: "http://127.0.0.1:8000", rewrite: (p) => p.replace(/^\/api\/(healthz|readyz)$/, "/$1") } },
    },
    build: { sourcemap: false },
  };
});
