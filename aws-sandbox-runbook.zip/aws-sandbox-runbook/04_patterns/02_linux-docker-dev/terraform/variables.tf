variable "aws_account_id" {
  description = "操作対象の AWS アカウント ID。誤アカウントへの適用を防ぐため allowed_account_ids に使う。"
  type        = string

  validation {
    condition     = can(regex("^[0-9]{12}$", var.aws_account_id))
    error_message = "aws_account_id は 12 桁の数字で指定してください。"
  }
}

variable "aws_region" {
  description = "利用リージョン。"
  type        = string
  default     = "ap-northeast-1"

  validation {
    condition     = var.aws_region == "ap-northeast-1"
    error_message = "このランブックは ap-northeast-1 のみを対象とします。"
  }
}

variable "owner" {
  description = "命名の先頭要素とタグ Owner に使う利用者識別子。小文字英字で始まる 3〜16 文字 (ハイフン不可)。"
  type        = string

  validation {
    condition     = can(regex("^[a-z][a-z0-9]{2,15}$", var.owner))
    error_message = "owner は小文字英字で始まる英数字 3〜16 文字で指定してください (ハイフン不可)。"
  }
}

variable "purpose" {
  description = "命名の 2 番目の要素とタグ Purpose。"
  type        = string
  default     = "dockdev"

  validation {
    condition     = can(regex("^[a-z][a-z0-9]{1,15}$", var.purpose))
    error_message = "purpose は小文字英字で始まる英数字 2〜16 文字で指定してください (ハイフン不可)。"
  }
}

variable "sequence" {
  description = "命名の末尾に付ける 2 桁の連番。"
  type        = string
  default     = "01"

  validation {
    condition     = can(regex("^[0-9]{2}$", var.sequence))
    error_message = "sequence は 2 桁の数字で指定してください。"
  }
}

variable "expires_at" {
  description = "タグ ExpiresAt。通常は直近の定期削除日 (YYYY-MM-DD)。"
  type        = string

  validation {
    condition     = can(regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}$", var.expires_at))
    error_message = "expires_at は YYYY-MM-DD 形式で指定してください。"
  }
}

variable "vpc_id" {
  description = "既存 VPC の ID。"
  type        = string
}

variable "subnet_mode" {
  description = "配置方式。public = Public Subnet + Public IPv4 (初期採用)、private = Private Subnet + NAT または承認済み Proxy。"
  type        = string
  default     = "public"

  validation {
    condition     = contains(["public", "private"], var.subnet_mode)
    error_message = "subnet_mode は public または private を指定してください。"
  }
}

variable "subnet_id" {
  description = "配置先 Subnet の ID。subnet_mode に対応する Subnet を指定する。"
  type        = string
}

variable "proxy_url" {
  description = "subnet_mode = private で承認済み Proxy を使う場合の URL (http://host:port)。NAT の場合は null。"
  type        = string
  default     = null

  validation {
    condition     = var.proxy_url == null || can(regex("^https?://[A-Za-z0-9.-]+(:[0-9]{1,5})?/?$", var.proxy_url))
    error_message = "proxy_url は http(s)://host:port 形式で指定してください。認証情報を URL に含めないでください。"
  }
}

variable "no_proxy" {
  description = "Proxy を経由しない宛先 (カンマ区切り)。"
  type        = string
  default     = "localhost,127.0.0.1,169.254.169.254,.amazonaws.com"

  validation {
    condition     = can(regex("^[A-Za-z0-9.,*-]*$", var.no_proxy))
    error_message = "no_proxy には英数字、ドット、カンマ、ハイフン、アスタリスクのみ使用できます。"
  }
}

variable "permissions_boundary_arn" {
  description = "IAM ロール作成時に必ず適用する Permissions Boundary の ARN。"
  type        = string
}

variable "instance_type" {
  description = "インスタンスタイプ。Docker ビルドを行うため t3.medium を既定とする。"
  type        = string
  default     = "t3.medium"

  validation {
    condition     = contains(["t3.nano", "t3.micro", "t3.small", "t3.medium", "t2.nano", "t2.micro", "t2.small", "t2.medium"], var.instance_type)
    error_message = "利用可能なインスタンスタイプ (t3/t2 の nano〜medium) から指定してください。"
  }
}

variable "root_volume_size_gb" {
  description = "ルート EBS のサイズ (GB)。"
  type        = number
  default     = 30
}

variable "app_ingress_ports" {
  description = "Windows 開発用 EC2 などからアプリ確認を許可するポート。既定は受信なし。"
  type        = list(number)
  default     = []
}

variable "app_ingress_source_security_group_ids" {
  description = "アプリ確認を許可する送信元 SG ID (Pattern 01 の security_group_id 出力など)。"
  type        = list(string)
  default     = []
}

variable "transfer_bucket_name" {
  description = "週末前の退避に使う S3 バケット名。null の場合は S3 権限を付与しない。"
  type        = string
  default     = null
}

variable "dev_user" {
  description = "Docker を非 root で利用する作業ユーザー名。"
  type        = string
  default     = "dev"

  validation {
    condition     = can(regex("^[a-z][a-z0-9_-]{1,30}$", var.dev_user)) && !contains(["root", "ec2-user", "ssm-user"], var.dev_user)
    error_message = "dev_user は小文字英字で始まる 2〜31 文字で、root / ec2-user / ssm-user 以外を指定してください。"
  }
}

variable "run_bootstrap_on_boot" {
  description = "初回起動時に bootstrap-linux-docker.sh を user data として実行する。"
  type        = bool
  default     = true
}
