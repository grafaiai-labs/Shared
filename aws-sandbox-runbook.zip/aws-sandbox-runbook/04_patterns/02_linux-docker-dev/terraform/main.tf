locals {
  base_name = "${var.owner}-${var.purpose}"

  # 共通スクリプト本体の前に、環境依存の値だけを環境変数として差し込む。
  bootstrap_env = join("\n", [
    "#!/bin/bash",
    "export BOOTSTRAP_DEV_USER='${var.dev_user}'",
    "export BOOTSTRAP_PROXY_URL='${var.proxy_url == null ? "" : var.proxy_url}'",
    "export BOOTSTRAP_NO_PROXY='${var.no_proxy}'",
  ])
  user_data = var.run_bootstrap_on_boot ? "${local.bootstrap_env}\n${file("${path.module}/../scripts/bootstrap-linux-docker.sh")}" : null
}

module "instance_role" {
  source = "../../../08_iac/modules/ssm-instance-role"

  name                     = "${local.base_name}-role-${var.sequence}"
  permissions_boundary_arn = var.permissions_boundary_arn
  transfer_bucket_name     = var.transfer_bucket_name
  transfer_prefix          = "transfer/${local.base_name}"
}

module "linux" {
  source = "../../../08_iac/modules/linux-docker-host"

  name                                  = "${local.base_name}-ec2-${var.sequence}"
  vpc_id                                = var.vpc_id
  subnet_id                             = var.subnet_id
  associate_public_ip_address           = var.subnet_mode == "public"
  instance_type                         = var.instance_type
  root_volume_size_gb                   = var.root_volume_size_gb
  app_ingress_ports                     = var.app_ingress_ports
  app_ingress_source_security_group_ids = var.app_ingress_source_security_group_ids
  iam_instance_profile_name             = module.instance_role.instance_profile_name
  user_data                             = local.user_data
}
