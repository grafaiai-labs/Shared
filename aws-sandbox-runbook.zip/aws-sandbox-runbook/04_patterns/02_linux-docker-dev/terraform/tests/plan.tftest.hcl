# terraform test (モック Provider)。AWS へ接続せず、SG・Public IP・user data・入力検証を確認する。
#   terraform init -backend=false && terraform test

mock_provider "aws" {
  mock_data "aws_ami" {
    defaults = {
      id   = "ami-0fedcba9876543210"
      name = "al2023-ami-2023.9.20260915.0-kernel-6.12-x86_64"
    }
  }
  mock_data "aws_partition" {
    defaults = { partition = "aws" }
  }
  mock_data "aws_iam_policy_document" {
    defaults = { json = "{\"Version\":\"2012-10-17\",\"Statement\":[]}" }
  }
}

variables {
  aws_account_id           = "000000000000"
  owner                    = "tester"
  expires_at               = "2026-10-04"
  vpc_id                   = "vpc-0123456789abcdef0"
  subnet_id                = "subnet-0123456789abcdef0"
  permissions_boundary_arn = "arn:aws:iam::000000000000:policy/example-boundary"

  # 作業ツリーの terraform.tfvars に影響されないよう、テストが前提とする値をすべて明示する
  purpose                               = "dockdev"
  sequence                              = "01"
  subnet_mode                           = "public"
  proxy_url                             = null
  instance_type                         = "t3.medium"
  dev_user                              = "dev"
  app_ingress_ports                     = []
  app_ingress_source_security_group_ids = []
  transfer_bucket_name                  = null
  run_bootstrap_on_boot                 = true
}

run "public_mode_has_no_inbound" {
  command = plan

  assert {
    condition     = module.instance_role.role_name == "tester-dockdev-role-01"
    error_message = "ロール名が命名規則に従っていない。"
  }
  assert {
    condition     = output.transfer_s3_uri == null
    error_message = "transfer_bucket_name 未指定時は S3 権限を付与しないこと。"
  }
  assert {
    condition     = startswith(local.user_data, "#!/bin/bash\nexport BOOTSTRAP_DEV_USER='dev'")
    error_message = "user data の先頭に環境変数が差し込まれていない。"
  }
  assert {
    condition     = strcontains(local.user_data, "BOOTSTRAP_PROXY_URL=''")
    error_message = "Public Subnet 案では Proxy を設定しないこと。"
  }
}

run "private_mode_with_proxy" {
  command = plan

  variables {
    subnet_mode = "private"
    proxy_url   = "http://proxy.example.internal:3128"
  }

  assert {
    condition     = strcontains(local.user_data, "BOOTSTRAP_PROXY_URL='http://proxy.example.internal:3128'")
    error_message = "Proxy URL が user data へ渡っていない。"
  }
}

run "proxy_with_credentials_rejected" {
  command = plan

  variables {
    subnet_mode = "private"
    proxy_url   = "http://user:pass@proxy.example.internal:3128"
  }

  expect_failures = [var.proxy_url]
}

run "reserved_dev_user_rejected" {
  command = plan

  variables {
    dev_user = "root"
  }

  expect_failures = [var.dev_user]
}
