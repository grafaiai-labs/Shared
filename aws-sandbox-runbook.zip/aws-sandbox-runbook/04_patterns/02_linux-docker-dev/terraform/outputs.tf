output "instance_id" {
  description = "SSM Session Manager で接続するインスタンス ID。"
  value       = module.linux.instance_id
}

output "private_ip" {
  description = "Private IPv4。Windows 開発用 EC2 からのアプリ確認に使う。"
  value       = module.linux.private_ip
}

output "security_group_id" {
  description = "Linux 用 SG。"
  value       = module.linux.security_group_id
}

output "ami_name" {
  description = "使用した公式 AMI 名。"
  value       = module.linux.ami_name
}

output "dev_user" {
  description = "Docker を利用する作業ユーザー。SSM 接続後に sudo -iu で切り替える。"
  value       = var.dev_user
}

output "transfer_s3_uri" {
  description = "退避用 S3 URI (transfer_bucket_name 指定時のみ)。"
  value       = var.transfer_bucket_name == null ? null : "s3://${var.transfer_bucket_name}/transfer/${local.base_name}/"
}
