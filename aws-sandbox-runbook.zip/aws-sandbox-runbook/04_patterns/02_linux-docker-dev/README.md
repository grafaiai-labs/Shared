# Pattern 02: Linux Docker 開発用 EC2

SSM Session Manager だけで管理する Amazon Linux 2023 の Docker 開発ホストを Terraform で構築し、Docker Engine / Compose Plugin / Git / Python / Node.js / Claude Code / Snowflake 接続クライアントを初期化スクリプトで導入する。SSH キーとインバウンドは使わない。

## 1. 用途

- Docker Compose による Web アプリ検証 ([Pattern 03](../03_docker-react-fastapi-snowflake/README.md))、定期バッチ ([Pattern 04](../04_scheduled-etl/README.md)) の実行環境。
- CLI 中心の開発 (Claude Code、Git、Python、Node.js)。

## 2. 成功条件

- [ ] `terraform plan` でインバウンドルールが 0 件、`key_name` なし、IMDSv2 必須 + hop limit 1、ルート EBS `gp2`
- [ ] Session Manager で接続でき、`sudo -iu dev` で作業ユーザーになれる
- [ ] `/var/lib/dev-bootstrap/status` が `success`
- [ ] [check-devhost.sh](scripts/check-devhost.sh) がすべて PASS (Docker API が TCP で待ち受けていない、コンテナから IMDS に届かない、を含む)
- [ ] 作業ユーザーが `sudo` なしで `docker compose` を実行できる
- [ ] 週末前に `terraform destroy` で全リソースが削除される

## 3. 非スコープ

- SSH 接続、踏み台
- Rootless Docker ([Docker 方針 §3](../../02_common-design/docker-policy.md#3-docker-グループと非-root-利用))
- ECS / EKS などのコンテナオーケストレーション
- インターネットからのアプリ公開 ([Pattern 05](../05_public-web/README.md) の範囲)

## 4. 前提条件

- [Pattern 00](../00_terraform-bootstrap/README.md) が完了している。
- Windows からアプリを確認する場合は [Pattern 01](../01_windows-dev-ec2/README.md) が構築済み。

## 5. 設計判断

| 判断 | 内容 | 理由 |
| --- | --- | --- |
| OS | Amazon Linux 2023 (公式 AMI を検索) | SSM Agent 標準搭載、Docker と `python3.13` が公式リポジトリにある、Runner と同じ OS で運用を統一 |
| 接続 | SSM Session Manager のみ | 仕様。SSH キー・インバウンド不要 |
| 配置 | 初期は Public Subnet + Public IPv4 (インバウンドなし) | Private Subnet の外向き通信が未確認 ([ネットワーク §2](../../02_common-design/network.md#2-外向き通信の案と切替条件)) |
| Docker | AL2023 の `docker` + 公式 Compose / Buildx バイナリ (SHA256 固定) | AL2023 リポジトリに Compose Plugin がないため |
| 非 root 利用 | 作業ユーザー `dev` を `docker` グループへ。`sudo` 権限なし | Claude Code 等を管理者権限なしで動かす |
| IMDS | IMDSv2 必須、hop limit 1 | コンテナからインスタンスロールの資格情報を取得させない |
| インスタンスタイプ | `t3.medium` | フロントエンドと Python 依存のビルドにメモリが必要 |

## 6. 採用コンポーネント

| コンポーネント | 内容 |
| --- | --- |
| EC2 | AL2023 x86_64、`t3.medium`、gp2 30 GB (暗号化) |
| Security Group | インバウンドなし (任意で Windows SG からのアプリ確認ポート)、443 → any |
| IAM ロール | SSM Core + 退避用 S3 プレフィックス (Boundary 適用) |
| ソフトウェア | Docker Engine (AL2023)、Compose v5.5.1、Buildx v0.37.1、Git、Python 3.13、Node.js 24.21.0、Claude Code 2.1.284、Snowflake Connector 4.7.5 / CLI 3.28.0 |

## 7. 不採用コンポーネントと切替条件

| 不採用 | 理由 | 切替条件 |
| --- | --- | --- |
| Private Subnet + NAT / Proxy (案 B) | NAT / Proxy の有無が未確認 | [ネットワーク §2](../../02_common-design/network.md#2-外向き通信の案と切替条件) の 3 条件を満たしたら `subnet_mode = "private"` |
| Ubuntu 等の他 OS | SSM Agent の導入・運用手順が増える | AL2023 で必要なパッケージが得られない場合 |
| Docker 公式リポジトリの Docker CE | AL2023 は公式サポート対象外 | AL2023 版 Docker で必要機能が不足する場合 |
| Rootless Docker | AL2023 標準では提供されない | [Docker 方針 §3](../../02_common-design/docker-policy.md#3-docker-グループと非-root-利用) |
| SSH / 踏み台 | SSM で代替できる | なし |
| SSM ポートフォワード | 社内 PC に AWS CLI / Session Manager Plugin を入れられない | 社内 PC で利用が許可された場合 (アプリ確認に使える) |

## 8. 制約、代替策、残存リスク

| 項目 | 内容 |
| --- | --- |
| `docker` グループは実質 root 相当 | `dev` に `sudo` を与えない。信頼できないイメージを実行しない |
| ブラウザーでアプリを確認する手段 | ① Windows 開発用 EC2 から Private IP へ (SG 参照で許可)、② EC2 上で `curl`。社内 PC から直接は不可 |
| Compose v5 と AL2023 の Docker 25 の互換性 | Docker 25.0.5 (API 1.44) の dind 環境で Compose v5.5.1 / Buildx v0.37.1 による build と run を確認済み (検証は arm64 版バイナリ。EC2 では §23 で実機確認する) |
| `ssm-user` は `sudo` 可能 | 管理作業だけに使い、開発作業は `dev` で行う |
| Public IPv4 を持つ | インバウンドなし。SG 変更は Terraform 経由のみ |

## 9. Mermaid 構成図

```mermaid
flowchart LR
  CON["AWS コンソール<br/>Session Manager"] -.-> VPCE["SSM VPC Endpoint"] -.-> LNX
  subgraph Pub["Public Subnet (案 A)"]
    subgraph LNX["Linux Docker EC2 (AL2023 / t3.medium)<br/>SG: inbound なし"]
      DK["dockerd<br/>(unix socket のみ)"]
      C1["container: frontend"]
      C2["container: api"]
      DEV["user: dev<br/>docker group / no sudo"]
    end
  end
  LNX -- "HTTPS 443" --> REG["Docker Hub / npm / PyPI / GitHub"]
  C2 -- "HTTPS 443" --> SF["Snowflake"]
  WIN["Windows 開発用 EC2"] -. "任意: 8080 (SG 参照)" .-> C1
```

## 10. 通信フロー

| # | 送信元 | 宛先 | ポート | 用途 |
| --- | --- | --- | --- | --- |
| 1 | SSM Agent | SSM VPC Endpoint | 443 | セッション |
| 2 | EC2 | AL2023 リポジトリ、GitHub、nodejs.org、npm、PyPI | 443 | 初期化 |
| 3 | dockerd | Docker Hub | 443 | イメージ取得 |
| 4 | api コンテナ | Snowflake | 443 | クエリ |
| 5 | Windows EC2 | EC2 の 8080 | 8080 | アプリ確認 (任意、SG 参照) |

## 11. データフロー

| データ | 保存場所 | 退避先 | 寿命 |
| --- | --- | --- | --- |
| ソースコード | `/home/dev/work/` | 個人 Public GitHub | 週末まで |
| `.env`、`secrets/` | `/home/dev/work/.../` (`chmod 600` / `400`) | **退避しない** | 週末まで |
| コンテナイメージ | Docker のローカルストア | 退避しない (再ビルド) | 週末まで |
| 初期化ログ | `/var/log/dev-bootstrap.log` | 不要 | 週末まで |

## 12. 作成する AWS リソース

| リソース | 名前 | 定義 |
| --- | --- | --- |
| IAM ロール / インスタンスプロファイル | `<owner>-dockdev-role-01` | [ssm-instance-role](../../08_iac/modules/ssm-instance-role/main.tf) |
| Security Group + ルール | `<owner>-dockdev-ec2-01-sg` | [linux-docker-host](../../08_iac/modules/linux-docker-host/main.tf) |
| EC2 + ルート EBS | `<owner>-dockdev-ec2-01` | 同上 |

## 13. パラメーター

[terraform.tfvars.example](terraform/terraform.tfvars.example) を `terraform.tfvars` にコピーして記入する。

| 変数 | 既定 | 説明 |
| --- | --- | --- |
| `aws_account_id` / `owner` / `expires_at` / `vpc_id` / `permissions_boundary_arn` | (必須) | 共通 |
| `purpose` / `sequence` | `dockdev` / `01` | 命名 |
| `subnet_mode` | `public` | `public` (案 A) / `private` (案 B) |
| `subnet_id` | (必須) | `subnet_mode` に対応する Subnet |
| `proxy_url` / `no_proxy` | `null` / AWS 関連を除外 | 案 B で Proxy を使う場合のみ。URL に認証情報を含めると検証エラー |
| `instance_type` / `root_volume_size_gb` | `t3.medium` / `30` | |
| `app_ingress_ports` / `app_ingress_source_security_group_ids` | `[]` / `[]` | Windows からのアプリ確認用。Docker API ポートは指定不可 |
| `transfer_bucket_name` | `null` | 退避用 S3 |
| `dev_user` | `dev` | 作業ユーザー |
| `run_bootstrap_on_boot` | `true` | 初期化スクリプトの自動実行 |

### 案 A → 案 B への切替手順

1. [ネットワーク §2](../../02_common-design/network.md#2-外向き通信の案と切替条件) の切替条件を満たすことを確認する。
2. `terraform.tfvars` を変更する。

   ```hcl
   subnet_mode = "private"
   subnet_id   = "<PRIVATE_SUBNET_ID>"
   proxy_url   = "<APPROVED_PROXY_URL>"   # NAT の場合は指定しない
   ```

3. `terraform plan` で EC2 が **再作成** (`-/+`) されることを確認し、§29 の退避後に適用する。

## 14. 命名とタグ

共通規則 ([命名とタグ](../../02_common-design/naming-and-tagging.md))。`Purpose = dockdev`。

## 15. IAM 設計

インスタンスロールは SSM Core + `s3://<BOOTSTRAP_BUCKET_NAME>/transfer/<owner>-dockdev/` のみ。コンテナは IMDS へ到達できないため、このロールもコンテナからは使えない。

## 16. Permissions Boundary

Pattern 01 と同じ ([ssm-instance-role](../../08_iac/modules/ssm-instance-role/main.tf) が必ず適用)。

## 17. Security Group 設計

| 方向 | プロトコル | ポート | 相手 | 説明 |
| --- | --- | --- | --- | --- |
| インバウンド | - | - | - | **既定はなし** |
| インバウンド (任意) | TCP | `app_ingress_ports` | Windows 開発用 EC2 の SG (SG 参照) | アプリ確認。CIDR 指定はできない |
| アウトバウンド | TCP | 443 | `0.0.0.0/0` | HTTPS |

## 18. Terraform 構成

```bash
cd ~/iac/current/04_patterns/02_linux-docker-dev/terraform
terraform init -input=false -backend-config=../../../08_iac/bootstrap/backend.hcl
terraform validate
terraform plan -out=run.tfplan
terraform apply run.tfplan
rm -f run.tfplan
terraform output
```

user data は [main.tf](terraform/main.tf) で「環境変数の export 数行 + [bootstrap-linux-docker.sh](scripts/bootstrap-linux-docker.sh)」として組み立てる。スクリプト本体に環境依存値はない。

## 19. 手動例外手順

### Windows からのアプリ確認を許可する (任意)

1. Pattern 01 で `terraform output security_group_id` を確認する。
2. Pattern 02 の `terraform.tfvars` に記入して apply する。

   ```hcl
   app_ingress_ports                     = [8080]
   app_ingress_source_security_group_ids = ["<PATTERN01_SECURITY_GROUP_ID>"]
   ```

3. Linux 側で `.env` の `FRONTEND_BIND_ADDRESS=0.0.0.0` にしてアプリを起動し、Windows のブラウザーで `http://<Linux の private_ip>:8080/` を開く。

## 20. OS とミドルウェア初期設定

[bootstrap-linux-docker.sh](scripts/bootstrap-linux-docker.sh) が初回起動時に root で実行される。

| 手順 | 内容 |
| --- | --- |
| 1 | Proxy 設定 (案 B で `proxy_url` 指定時のみ): `/etc/profile.d/proxy.sh`、`dnf.conf`、Docker の systemd drop-in |
| 2 | 外向き到達性をログに記録 |
| 3 | `dnf install docker git jq tar xz nano python3.13 python3.13-pip` |
| 4 | `/etc/docker/daemon.json` (ログローテーション、`live-restore`、`no-new-privileges`)。`hosts` 設定がないことを検査 |
| 5 | Compose / Buildx を `/usr/local/lib/docker/cli-plugins/` へ (SHA256 検証) |
| 6 | 作業ユーザー `dev` を作成し `docker` グループへ追加 (sudo なし) |
| 7 | Node.js を `/opt/node-v24.21.0` へ (SHA256 検証) |
| 8 | Claude Code を `dev` の `~/.npm-global` へ。`DISABLE_AUTOUPDATER=1` |
| 9 | Snowflake Connector / CLI を `dev` の `~/.venvs/snowflake` へ |
| 10 | バージョンを `/var/lib/dev-bootstrap/versions` へ記録し、2375/2376 が待ち受けていないことを検査 |

再実行 (冪等):

```bash
# ssm-user で。スクリプトは GitHub から取得した作業コピー、または貼り付けたファイル
sudo BOOTSTRAP_DEV_USER=dev bash bootstrap-linux-docker.sh
```

## 21. Docker 構成

| 項目 | 設定 |
| --- | --- |
| ソケット | `/var/run/docker.sock` (root:docker 660) のみ。TCP 待ち受けなし |
| daemon.json | `json-file` (10 MB × 3)、`live-restore: true`、`no-new-privileges: true` |
| プラグイン | `docker compose` (v5.5.1)、`docker buildx` (v0.37.1) |
| 利用者 | `dev` (docker グループ) |
| コンテナ側の規則 | [Docker 方針](../../02_common-design/docker-policy.md) |

## 22. アプリケーション配置

```bash
sudo -iu dev
git config --global user.name "<GIT_USER_NAME>"
git config --global user.email "<GIT_USER_EMAIL>"
mkdir -p ~/work && cd ~/work
git clone https://github.com/<GITHUB_USER>/<GITHUB_REPO>.git
cd <GITHUB_REPO>
```

アプリの起動は [Pattern 03 §22](../03_docker-react-fastapi-snowflake/README.md#22-アプリケーション配置) を参照。

### Docker Compose の基本操作

| 操作 | コマンド |
| --- | --- |
| 起動 (ビルド込み) | `docker compose up -d --build` |
| 状態 | `docker compose ps` |
| ログ (追従) | `docker compose logs -f --tail=100 api` |
| 停止 (コンテナを残す) | `docker compose stop` |
| 再開 | `docker compose start` |
| 削除 (コンテナ・ネットワーク) | `docker compose down` |
| 削除 (+ ボリューム・ローカルビルドイメージ) | `docker compose down --volumes --rmi local` |
| ディスク使用量 | `docker system df` |
| 未使用データの削除 | `docker system prune` (確認が表示される) |

## 23. 正常系確認

```bash
# ssm-user で
cat /var/lib/dev-bootstrap/status      # success
cat /var/lib/dev-bootstrap/versions
sudo -iu dev
# dev で (スクリプトは clone したリポジトリ内)
bash ~/work/<GITHUB_REPO>/04_patterns/02_linux-docker-dev/scripts/check-devhost.sh https://github.com/<GITHUB_USER>/<GITHUB_REPO>.git
```

期待値: すべて `PASS`、終了コード 0。主な項目:

| 項目 | 期待値 |
| --- | --- |
| `docker compose plugin` | `5.5.1` |
| `user has no passwordless sudo` | PASS |
| `docker API not listening on TCP` | PASS |
| `IMDS unreachable from container` | PASS |

## 24. 異常系確認

| 確認 | 手順 | 期待値 |
| --- | --- | --- |
| インバウンドがない | EC2 → セキュリティ → インバウンドルール | 0 件 (任意設定時のみ SG 参照 1 件) |
| Docker API ポートの指定 | `app_ingress_ports = [2375]` で `terraform plan` | 変数検証エラー |
| Proxy URL に認証情報 | `proxy_url = "http://user:pass@..."` | 変数検証エラー |
| `dev` の sudo | `sudo -n true` | `a password is required` |
| 初期化失敗 | `/var/lib/dev-bootstrap/status` | `failed:<行番号>`。ログで原因確認後に再実行 |

## 25. ログと監視

| ログ | 場所 / コマンド |
| --- | --- |
| 初期化 | `/var/log/dev-bootstrap.log`、`/var/log/cloud-init-output.log` |
| Docker daemon | `sudo journalctl -u docker --since today` |
| コンテナ | `docker compose logs <service>` (JSON 構造化ログ) |
| バッチ (systemd) | `journalctl -u sample-etl.service` |

## 26. 停止手順

1. `docker compose stop` (アプリ)。
2. EC2 → `<owner>-dockdev-ec2-01` →「インスタンスを停止」。Docker イメージとコンテナは EBS に残る。

## 27. 個別削除

| 目的 | 方法 |
| --- | --- |
| EC2 を作り直す | `terraform plan -replace=module.linux.aws_instance.this -out=run.tfplan` → 確認 → apply |
| アプリ確認用の受信を閉じる | `app_ingress_ports = []` にして apply |
| コンテナ・イメージだけを消す | §22 の `docker compose down --volumes --rmi local` |

## 28. 全体削除

> [!CAUTION]
> Linux EC2 (ホーム、Docker イメージ、`.env`、`secrets/` を含む)、SG、IAM ロール を完全に削除する。復元できない。先に §29 の退避を行う。

```bash
cd ~/iac/current/04_patterns/02_linux-docker-dev/terraform
terraform plan -destroy -out=destroy.tfplan
terraform apply destroy.tfplan
rm -f destroy.tfplan
terraform state list
```

## 29. 週末前の退避

```bash
# dev で
cd ~/work/<GITHUB_REPO>
git status --short
git add -A && git commit -m "<COMMIT_MESSAGE>" && git push
# 非公開ファイル (秘密情報を除く) を S3 経由で社内 PC へ
aws s3 cp ~/work/private-notes.tar.gz s3://<BOOTSTRAP_BUCKET_NAME>/transfer/<OWNER>-dockdev/
```

`aws` コマンドは `dev` でも実行できる (IMDS はホスト上からは到達可能)。`.env` と `secrets/` は退避しない。

## 30. 週末後の再構築

1. 社内 PC で `expires_at` を更新し、IaC ZIP を再作成・アップロード → Runner で `iac-fetch`。
2. §18 の `init` → `plan` → `apply`。
3. 5〜10 分後、§23 の確認。
4. §22 の clone、Claude Code の再認証、`.env` と `secrets/` の再作成 ([Snowflake 接続](../../05_components/snowflake-connection.md))。

## 31. トラブルシューティング

| 症状 | 参照 |
| --- | --- |
| Session Manager で接続できない | [06 SSM](../../06_troubleshooting/README.md#session-manager-で接続できない) |
| `permission denied ... docker.sock` | [06 Docker](../../06_troubleshooting/README.md#docker-で-permission-denied) |
| イメージを pull できない | [06 pull](../../06_troubleshooting/README.md#イメージの-pull--パッケージの取得に失敗する) |
| 初期化スクリプトの失敗 | `/var/log/dev-bootstrap.log` の `ERROR` 行と直前のコマンド |

## 32. コスト

| 課金要素 | 備考 |
| --- | --- |
| EC2 `t3.medium` (Linux) | 起動中のみ |
| EBS 30 GB gp2 | 停止中も課金 |
| Public IPv4 | 0.005 USD/時 (案 A、関連付け中) |

## 33. 未確定事項

U-04、U-11、U-15、U-18、Q-02、Q-04 ([未確定事項台帳](../../01_constraints/unconfirmed-items.md))。

## 34. 更新履歴

| 日付 | 内容 |
| --- | --- |
| 2026-09-29 | 初版 |
