#!/bin/bash
# =============================================================================
# Amazon Linux 2023 Docker 開発ホストの初期化スクリプト
#
# 用途   : EC2 user data (初回起動時に root で実行) または手動再実行
# 手動実行: sudo BOOTSTRAP_DEV_USER=dev bash bootstrap-linux-docker.sh
# ログ   : /var/log/dev-bootstrap.log
# 結果   : /var/lib/dev-bootstrap/status (success / failed:<行番号>)
#
# 秘密情報をこのスクリプトへ記載しないこと。環境依存値は環境変数で受け取る。
# 何度実行しても同じ状態になるように記述している (冪等)。
# =============================================================================
set -Eeuo pipefail

# ---- 環境依存値 (user data の先頭で export される) -------------------------
DEV_USER="${BOOTSTRAP_DEV_USER:-dev}"
PROXY_URL="${BOOTSTRAP_PROXY_URL:-}"
NO_PROXY_LIST="${BOOTSTRAP_NO_PROXY:-localhost,127.0.0.1,169.254.169.254,.amazonaws.com}"
INSTALL_SNOWFLAKE_CLI="${BOOTSTRAP_INSTALL_SNOWFLAKE_CLI:-1}"

# ---- 固定バージョンと SHA256 (更新手順: 02_common-design/version-pinning.md) --
COMPOSE_VERSION="v5.5.1"
COMPOSE_SHA256="db1889184726840f75c4f9c001048430d4f25b3be3cb084d3ddd762bc0aed576"
BUILDX_VERSION="v0.37.1"
BUILDX_SHA256="9447199cdb435f25880548343c128a4b6650e8891ee598905d8d29d39a8e359b"
NODE_VERSION="v24.21.0"
NODE_SHA256="fd8e59d5a511510f6a298afb548f18c7d2b1be404d8b4a27d94fbe49f56cb2d6"
CLAUDE_CODE_VERSION="2.1.284"
SNOWFLAKE_CONNECTOR_VERSION="4.7.5"
SNOWFLAKE_CLI_VERSION="3.28.0"
PYTHON_PKG="python3.13"

LOG_FILE="/var/log/dev-bootstrap.log"
STATE_DIR="/var/lib/dev-bootstrap"
CLI_PLUGIN_DIR="/usr/local/lib/docker/cli-plugins"

mkdir -p "${STATE_DIR}"
exec > >(tee -a "${LOG_FILE}") 2>&1

log() { printf '%s [bootstrap] %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*"; }
on_error() {
  local line="$1"
  echo "failed:${line}" > "${STATE_DIR}/status"
  log "ERROR: line ${line} で失敗しました。${LOG_FILE} を確認してください。"
}
trap 'on_error ${LINENO}' ERR

if [[ "$(id -u)" -ne 0 ]]; then
  echo "root で実行してください (sudo bash $0)" >&2
  exit 1
fi
if ! [[ "${DEV_USER}" =~ ^[a-z][a-z0-9_-]{1,30}$ ]]; then
  echo "BOOTSTRAP_DEV_USER が不正です: ${DEV_USER}" >&2
  exit 1
fi

echo "running" > "${STATE_DIR}/status"
log "開始 dev_user=${DEV_USER} proxy=$([[ -n "${PROXY_URL}" ]] && echo enabled || echo disabled)"

# ---- 1. Proxy (Private Subnet + 承認済み Proxy 案の場合のみ) ---------------
if [[ -n "${PROXY_URL}" ]]; then
  log "Proxy 設定を書き込みます"
  export http_proxy="${PROXY_URL}" https_proxy="${PROXY_URL}" no_proxy="${NO_PROXY_LIST}"
  export HTTP_PROXY="${PROXY_URL}" HTTPS_PROXY="${PROXY_URL}" NO_PROXY="${NO_PROXY_LIST}"
  cat > /etc/profile.d/proxy.sh <<EOF
export http_proxy="${PROXY_URL}" https_proxy="${PROXY_URL}" no_proxy="${NO_PROXY_LIST}"
export HTTP_PROXY="${PROXY_URL}" HTTPS_PROXY="${PROXY_URL}" NO_PROXY="${NO_PROXY_LIST}"
EOF
  if ! grep -q '^proxy=' /etc/dnf/dnf.conf; then
    echo "proxy=${PROXY_URL}" >> /etc/dnf/dnf.conf
  fi
  mkdir -p /etc/systemd/system/docker.service.d
  cat > /etc/systemd/system/docker.service.d/http-proxy.conf <<EOF
[Service]
Environment="HTTP_PROXY=${PROXY_URL}" "HTTPS_PROXY=${PROXY_URL}" "NO_PROXY=${NO_PROXY_LIST}"
EOF
fi

# ---- 2. 外向き通信の事前確認 (失敗しても続行し、結果をログに残す) ---------
log "外向き HTTPS 到達性を確認します"
for url in \
  "https://github.com/" \
  "https://registry-1.docker.io/v2/" \
  "https://nodejs.org/" \
  "https://registry.npmjs.org/" \
  "https://pypi.org/simple/"; do
  code="$(curl -sS -o /dev/null -m 10 -w '%{http_code}' "${url}" 2>/dev/null)" || code="000"
  log "  reach ${url} -> HTTP ${code}"
done

# ---- 3. OS パッケージ ------------------------------------------------------
log "OS パッケージを導入します (AL2023 リポジトリへの到達性もここで確認される)"
dnf -y -q install docker git jq tar xz nano "${PYTHON_PKG}" "${PYTHON_PKG}-pip"

# ---- 4. Docker Engine 設定 (Unix ソケットのみ。TCP で待ち受けない) ---------
log "Docker daemon を設定します"
mkdir -p /etc/docker
cat > /etc/docker/daemon.json <<'EOF'
{
  "log-driver": "json-file",
  "log-opts": { "max-size": "10m", "max-file": "3" },
  "live-restore": true,
  "no-new-privileges": true
}
EOF
if grep -q '"hosts"' /etc/docker/daemon.json; then
  log "daemon.json に hosts 設定があります。Docker ソケットを TCP 公開しないでください。"
  exit 1
fi
systemctl daemon-reload
systemctl enable --now docker

# ---- 5. Docker Compose / Buildx プラグイン (SHA256 検証) -------------------
install_plugin() {
  local name="$1" url="$2" sha="$3" dest="${CLI_PLUGIN_DIR}/$1"
  if [[ -x "${dest}" ]] && echo "${sha}  ${dest}" | sha256sum -c --status; then
    log "  ${name} は導入済みです"
    return
  fi
  local tmp
  tmp="$(mktemp)"
  curl -fsSL --retry 3 -m 300 -o "${tmp}" "${url}"
  echo "${sha}  ${tmp}" | sha256sum -c -
  install -D -m 0755 "${tmp}" "${dest}"
  rm -f "${tmp}"
  log "  ${name} を導入しました"
}
log "Docker CLI プラグインを導入します"
install_plugin docker-compose \
  "https://github.com/docker/compose/releases/download/${COMPOSE_VERSION}/docker-compose-linux-x86_64" \
  "${COMPOSE_SHA256}"
install_plugin docker-buildx \
  "https://github.com/docker/buildx/releases/download/${BUILDX_VERSION}/buildx-${BUILDX_VERSION}.linux-amd64" \
  "${BUILDX_SHA256}"

# ---- 6. 作業ユーザー (sudo 権限なし、docker グループ所属) ------------------
if ! id "${DEV_USER}" >/dev/null 2>&1; then
  log "作業ユーザー ${DEV_USER} を作成します"
  useradd --create-home --shell /bin/bash "${DEV_USER}"
fi
usermod -aG docker "${DEV_USER}"
DEV_HOME="$(getent passwd "${DEV_USER}" | cut -d: -f6)"

# ---- 7. Node.js (公式 tarball、SHA256 検証) --------------------------------
NODE_DIR="/opt/node-${NODE_VERSION}"
if [[ ! -x "${NODE_DIR}/bin/node" ]]; then
  log "Node.js ${NODE_VERSION} を導入します"
  tmp="$(mktemp)"
  curl -fsSL --retry 3 -m 300 -o "${tmp}" \
    "https://nodejs.org/dist/${NODE_VERSION}/node-${NODE_VERSION}-linux-x64.tar.xz"
  echo "${NODE_SHA256}  ${tmp}" | sha256sum -c -
  mkdir -p "${NODE_DIR}"
  tar -xJf "${tmp}" -C "${NODE_DIR}" --strip-components=1
  rm -f "${tmp}"
fi
for bin in node npm npx; do
  ln -sfn "${NODE_DIR}/bin/${bin}" "/usr/local/bin/${bin}"
done

# ---- 8. Claude Code (作業ユーザーのホームへ固定バージョンを導入) ----------
log "Claude Code ${CLAUDE_CODE_VERSION} を導入します"
cat > /etc/profile.d/dev-tools.sh <<'EOF'
# 作業ユーザー用 PATH。Claude Code の自動更新を止め、固定バージョンを維持する。
export PATH="${HOME}/.npm-global/bin:${HOME}/.venvs/snowflake/bin:${PATH}"
export DISABLE_AUTOUPDATER=1
EOF
sudo -u "${DEV_USER}" -H bash -lc \
  "npm config set prefix '${DEV_HOME}/.npm-global' && npm install -g --no-fund --no-audit @anthropic-ai/claude-code@${CLAUDE_CODE_VERSION}"

# ---- 9. Snowflake 接続クライアント (作業ユーザーの venv) --------------------
if [[ "${INSTALL_SNOWFLAKE_CLI}" == "1" ]]; then
  log "Snowflake Connector ${SNOWFLAKE_CONNECTOR_VERSION} / CLI ${SNOWFLAKE_CLI_VERSION} を導入します"
  sudo -u "${DEV_USER}" -H bash -lc "
    set -euo pipefail
    ${PYTHON_PKG} -m venv '${DEV_HOME}/.venvs/snowflake'
    '${DEV_HOME}/.venvs/snowflake/bin/pip' install --quiet --disable-pip-version-check \
      'snowflake-connector-python==${SNOWFLAKE_CONNECTOR_VERSION}' 'snowflake-cli==${SNOWFLAKE_CLI_VERSION}'
  "
fi

# ---- 10. 結果記録 ----------------------------------------------------------
# 取得できない項目は unknown として記録する (記録の失敗で初期化全体を失敗扱いにしない)
ver() { "$@" 2>/dev/null | head -1 || true; }
{
  echo "docker=$(ver docker version --format '{{.Server.Version}}')"
  echo "compose=$(ver docker compose version --short)"
  echo "buildx=$(ver docker buildx version | awk '{print $2}')"
  echo "git=$(ver git --version | awk '{print $3}')"
  echo "python=$(ver "${PYTHON_PKG}" --version | awk '{print $2}')"
  echo "node=$(ver node --version)"
  echo "claude_code=$(ver sudo -u "${DEV_USER}" -H bash -lc 'claude --version')"
} > "${STATE_DIR}/versions"

if ss -lnt | grep -Eq ':(2375|2376)\b'; then
  log "Docker API ポートが待ち受けています。設定を確認してください。"
  exit 1
fi

echo "success" > "${STATE_DIR}/status"
log "完了。バージョン: $(tr '\n' ' ' < "${STATE_DIR}/versions")"
