#!/bin/bash
# =============================================================================
# Linux Docker 開発ホストの動作確認
#
# 実行: 作業ユーザーで実行する (SSM 接続後に sudo -iu dev)
#   bash check-devhost.sh
#   bash check-devhost.sh https://github.com/<GITHUB_USER>/<GITHUB_REPO>.git
#
# 各項目を PASS / FAIL で表示し、FAIL があれば終了コード 1 を返す。
# =============================================================================
set -uo pipefail

REPO_URL="${1:-}"
fail=0

report() {
  local name="$1" ok="$2" detail="${3:-}"
  if [[ "${ok}" == "yes" ]]; then
    printf 'PASS  %-34s %s\n' "${name}" "${detail}"
  else
    printf 'FAIL  %-34s %s\n' "${name}" "${detail}"
    fail=1
  fi
}

# expect <名前> <詳細> <コマンド...>      : コマンドが成功すれば PASS
expect() {
  local name="$1" detail="$2"; shift 2
  if "$@" >/dev/null 2>&1; then report "${name}" yes "${detail}"; else report "${name}" no "${detail}"; fi
}

# expect_not <名前> <詳細> <コマンド...>  : コマンドが失敗すれば PASS
expect_not() {
  local name="$1" detail="$2"; shift 2
  if "$@" >/dev/null 2>&1; then report "${name}" no "${detail}"; else report "${name}" yes "${detail}"; fi
}

# version <名前> <コマンド...>             : 1 行目を表示し、成功すれば PASS
version() {
  local name="$1"; shift
  local out
  if out="$("$@" 2>&1 | head -1)" && [[ -n "${out}" ]]; then report "${name}" yes "${out}"; else report "${name}" no "${out}"; fi
}

in_docker_group() { id -nG | grep -qw docker; }
docker_api_on_tcp() { ss -lnt 2>/dev/null | grep -Eq ':(2375|2376)\b'; }
socket_is_660() { [[ -S /var/run/docker.sock && "$(stat -c '%a' /var/run/docker.sock)" == "660" ]]; }
imds_token_from_host() {
  [[ -n "$(curl -sS -m 3 -X PUT 'http://169.254.169.254/latest/api/token' \
    -H 'X-aws-ec2-metadata-token-ttl-seconds: 60' 2>/dev/null)" ]]
}
imds_token_from_container() {
  docker run --rm --pull=missing curlimages/curl:8.22.0 -sS -f -m 3 -X PUT \
    'http://169.254.169.254/latest/api/token' -H 'X-aws-ec2-metadata-token-ttl-seconds: 60'
}
reachable() {
  local code
  code="$(curl -sS -o /dev/null -m 10 -w '%{http_code}' "$1" 2>/dev/null)" || code="000"
  [[ "${code}" != "000" ]]
}

status="$(cat /var/lib/dev-bootstrap/status 2>/dev/null || echo missing)"
expect "bootstrap status" "status=${status}" test "${status}" = "success"
expect_not "running as non-root" "user=$(id -un)" test "$(id -u)" -eq 0
expect "user in docker group" "" in_docker_group
expect_not "user has no passwordless sudo" "" sudo -n true

version "docker engine" docker version --format '{{.Server.Version}}'
version "docker compose plugin" docker compose version --short
version "docker buildx plugin" docker buildx version
version "git" git --version
version "python3.13" python3.13 --version
version "node" node --version
version "claude code" claude --version
version "snowflake cli" snow --version

expect "docker run hello-world" "" docker run --rm --pull=missing hello-world
expect_not "docker API not listening on TCP" "" docker_api_on_tcp
expect "docker.sock is 660 (root:docker)" "$(stat -c '%U:%G %a' /var/run/docker.sock 2>/dev/null)" socket_is_660
expect "IMDSv2 token from host" "" imds_token_from_host
# コンテナからは IMDS へ到達できないこと (hop limit = 1)
expect_not "IMDS unreachable from container" "" imds_token_from_container

for url in https://github.com https://registry-1.docker.io/v2/ https://pypi.org/simple/ https://registry.npmjs.org/; do
  expect "reach ${url}" "" reachable "${url}"
done

if [[ -n "${REPO_URL}" ]]; then
  if [[ "${REPO_URL}" =~ ^https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+(\.git)?$ ]]; then
    expect "github ls-remote" "${REPO_URL}" git ls-remote --heads "${REPO_URL}"
  else
    report "github ls-remote" no "URL must be https://github.com/<user>/<repo>(.git)"
  fi
fi

exit "${fail}"
