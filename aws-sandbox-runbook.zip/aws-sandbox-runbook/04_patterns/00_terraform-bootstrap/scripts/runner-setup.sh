#!/bin/bash
# =============================================================================
# Terraform Runner (Amazon Linux 2023) 初期化スクリプト
#
# 使い方 (どちらか):
#   A. EC2 起動時の「ユーザーデータ」へこのファイルの内容を貼り付ける (推奨)
#   B. SSM Session Manager で接続後、内容を貼り付けて sudo bash で実行する
#
# 実施内容:
#   1. 外向き HTTPS 到達性の確認 (HashiCorp / Terraform Registry / GitHub)
#   2. unzip / git / jq の導入
#   3. Terraform 固定版の導入 (HashiCorp PGP 署名 + 固定 SHA256 の二重検証)
#   4. /usr/local/bin/iac-fetch (非公開 IaC ZIP を S3 から取得・展開) の配置
#   5. Terraform プラグインキャッシュ設定
#
# ログ : /var/log/runner-setup.log
# 結果 : /var/lib/runner-setup/status (success / failed:<行番号>)
#
# このファイルに秘密情報・バケット名・アカウント ID を書かないこと。
# =============================================================================
set -Eeuo pipefail

TERRAFORM_VERSION="1.16.4"
TERRAFORM_ZIP_SHA256="dc94af0eef1147718ad7c8daea792ed199e3e0492eec180d0adafa2a65a879df"
# HashiCorp Security の PGP 鍵フィンガープリント (https://www.hashicorp.com/trust/security)
HASHICORP_PGP_FINGERPRINT="C874011F0AB405110D02105534365D9472D7468F"

LOG_FILE="/var/log/runner-setup.log"
STATE_DIR="/var/lib/runner-setup"
mkdir -p "${STATE_DIR}"
exec > >(tee -a "${LOG_FILE}") 2>&1

log() { printf '%s [runner-setup] %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*"; }
trap 'echo "failed:${LINENO}" > "${STATE_DIR}/status"; log "ERROR: line ${LINENO}"' ERR

if [[ "$(id -u)" -ne 0 ]]; then
  echo "root で実行してください (sudo bash $0)" >&2
  exit 1
fi
echo "running" > "${STATE_DIR}/status"
log "開始"

# ---- 1. 外向き HTTPS 到達性 -------------------------------------------------
reach_fail=0
for url in \
  "https://releases.hashicorp.com/" \
  "https://registry.terraform.io/.well-known/terraform.json" \
  "https://github.com/" \
  "https://s3.ap-northeast-1.amazonaws.com/"; do
  code="$(curl -sS -o /dev/null -m 10 -w '%{http_code}' "${url}" 2>/dev/null)" || code="000"
  log "reach ${url} -> HTTP ${code}"
  if [[ "${url}" == https://releases.hashicorp.com/ && "${code}" == "000" ]]; then
    reach_fail=1
  fi
done
if [[ "${reach_fail}" -ne 0 ]]; then
  log "releases.hashicorp.com へ到達できません。06_troubleshooting を参照してください。"
  exit 1
fi

# ---- 2. OS パッケージ -------------------------------------------------------
# gpg は AL2023 標準の gnupg2-minimal に含まれる (gnupg2 は競合するため導入しない)
dnf -y -q install unzip git jq

# ---- 3. Terraform (PGP 署名 + SHA256) ----------------------------------------
if command -v terraform >/dev/null 2>&1 && terraform version -json | jq -e --arg v "${TERRAFORM_VERSION}" '.terraform_version == $v' >/dev/null; then
  log "Terraform ${TERRAFORM_VERSION} は導入済みです"
else
  log "Terraform ${TERRAFORM_VERSION} を導入します"
  work="$(mktemp -d)"
  base="https://releases.hashicorp.com/terraform/${TERRAFORM_VERSION}"
  zip="terraform_${TERRAFORM_VERSION}_linux_amd64.zip"
  curl -fsSL --retry 3 -o "${work}/${zip}" "${base}/${zip}"
  curl -fsSL --retry 3 -o "${work}/SHA256SUMS" "${base}/terraform_${TERRAFORM_VERSION}_SHA256SUMS"
  curl -fsSL --retry 3 -o "${work}/SHA256SUMS.sig" "${base}/terraform_${TERRAFORM_VERSION}_SHA256SUMS.sig"
  curl -fsSL --retry 3 -o "${work}/hashicorp.asc" "https://www.hashicorp.com/.well-known/pgp-key.txt"

  # AL2023 標準の gnupg2-minimal には gpg-agent がないため、鍵をインポートせずに
  # 「フィンガープリント照合 → 専用キーリングへ変換 → そのキーリングだけで署名検証」を行う。
  export GNUPGHOME="${work}/gnupg"
  mkdir -m 700 "${GNUPGHOME}"
  actual_fpr="$(gpg --batch --show-keys --with-colons "${work}/hashicorp.asc" 2>/dev/null | awk -F: '/^fpr:/ {print $10; exit}')"
  if [[ "${actual_fpr}" != "${HASHICORP_PGP_FINGERPRINT}" ]]; then
    log "PGP 鍵のフィンガープリントが一致しません: ${actual_fpr}"
    exit 1
  fi
  gpg --batch --yes --dearmor -o "${work}/hashicorp.gpg" "${work}/hashicorp.asc"
  gpg --batch --no-autostart --no-default-keyring --keyring "${work}/hashicorp.gpg" \
    --verify "${work}/SHA256SUMS.sig" "${work}/SHA256SUMS"
  log "PGP 署名 OK"

  # 署名済み SHA256SUMS とスクリプト内の固定値の両方に一致することを確認する
  (cd "${work}" && grep " ${zip}\$" SHA256SUMS | sha256sum -c -)
  echo "${TERRAFORM_ZIP_SHA256}  ${work}/${zip}" | sha256sum -c -

  unzip -o -q "${work}/${zip}" terraform -d /usr/local/bin
  chmod 0755 /usr/local/bin/terraform
  unset GNUPGHOME
  rm -rf "${work}"
fi
terraform version

# ---- 4. iac-fetch ヘルパー ----------------------------------------------------
cat > /usr/local/bin/iac-fetch <<'EOF'
#!/bin/bash
# 非公開 IaC ZIP を S3 から取得し ~/iac/<日時> へ展開、~/iac/current を張り替える。
# 使い方: iac-fetch s3://<BOOTSTRAP_BUCKET_NAME>/iac/<ZIP名> [<期待する SHA256>]
set -euo pipefail
umask 077
src="${1:?usage: iac-fetch s3://bucket/iac/package.zip [sha256]}"
expected="${2:-}"
[[ "${src}" =~ ^s3://[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]/iac/[A-Za-z0-9._-]+\.zip$ ]] || {
  echo "S3 URI は s3://<bucket>/iac/<name>.zip の形式で指定してください" >&2; exit 1; }
dest="${HOME}/iac/$(date +%Y%m%d-%H%M%S)"
mkdir -p "${dest}"
aws s3 cp --only-show-errors "${src}" "${dest}/package.zip"
actual="$(sha256sum "${dest}/package.zip" | awk '{print $1}')"
echo "sha256=${actual}"
if [[ -n "${expected}" && "${expected,,}" != "${actual}" ]]; then
  echo "SHA256 が一致しません。展開を中止します。" >&2
  rm -rf "${dest}"; exit 1
fi
# ZIP 内に State / Plan / .terraform が含まれていないことを確認する
if unzip -Z1 "${dest}/package.zip" | grep -Eq '(^|/)\.terraform/|\.tfstate|\.tfplan$'; then
  echo "ZIP に State / Plan / .terraform が含まれています。パッケージを作り直してください。" >&2
  rm -rf "${dest}"; exit 1
fi
unzip -q "${dest}/package.zip" -d "${dest}/src"
rm -f "${dest}/package.zip"
# ZIP に記録されたパーミッションに関わらず、本人以外は読めないようにする (tfvars / backend.hcl を含むため)
chmod -R go-rwx "${dest}"
ln -sfn "${dest}/src" "${HOME}/iac/current"
echo "展開先: ${HOME}/iac/current -> ${dest}/src"
EOF
chmod 0755 /usr/local/bin/iac-fetch

# ---- 5. Terraform 実行環境 ---------------------------------------------------
cat > /etc/profile.d/terraform.sh <<'EOF'
export TF_PLUGIN_CACHE_DIR="${HOME}/.terraform.d/plugin-cache"
export AWS_REGION=ap-northeast-1
export AWS_DEFAULT_REGION=ap-northeast-1
mkdir -p "${TF_PLUGIN_CACHE_DIR}" 2>/dev/null || true
EOF

echo "success" > "${STATE_DIR}/status"
log "完了"
