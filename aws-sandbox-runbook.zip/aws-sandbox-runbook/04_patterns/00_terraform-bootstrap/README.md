# Pattern 00: Terraform Bootstrap

Terraform を実行するための土台 (Bootstrap S3、Runner 用 IAM、Runner 用 SG、Terraform Runner EC2) を **AWS コンソールで手動作成** し、Runner から S3 Backend を使って Terraform を実行できる状態にする。週末前には Runner を最後に手動削除する。

## 1. 用途

- CloudShell と社内 PC から Terraform / AWS CLI を実行できないため、Terraform の実行場所を EC2 上に用意する。
- 他のすべてのパターン (01、02) の前提となる。

## 2. 成功条件

- [ ] Runner に Session Manager で接続できる (キーペア・インバウンドなし)
- [ ] `terraform version` が `Terraform v1.16.4` を表示し、PGP 署名と SHA256 の検証ログが残っている
- [ ] 非公開 IaC ZIP を S3 から取得し、SHA256 が社内 PC で控えた値と一致する
- [ ] smoke-test で S3 Backend への State 書き込みとロック解放ができる
- [ ] smoke-test の `subnet_routes` で Public Subnet の経路が `igw` と表示される
- [ ] ガードレール (§24) が期待どおり拒否する
- [ ] 週末前に Runner / SG / S3 / IAM を手動削除できる

## 3. 非スコープ

- Runner、Runner 用 IAM / SG、Bootstrap S3 の Terraform 管理 (仕様により手動)
- VPC / Subnet の作成 (利用者は作成できない)
- CI/CD からの Terraform 実行
- Terraform Cloud / HCP Terraform の利用
- State の長期保存 (週末に削除される)

## 4. 前提条件

| 項目 | 状態 |
| --- | --- |
| スイッチロール | [共通 Runbook](../../03_common-runbook/README.md#共通の前提操作-スイッチロール) の手順でサンドボックスへ入れる |
| 値 | `<AWS_ACCOUNT_ID>` `<VPC_ID>` `<PUBLIC_SUBNET_ID>` `<PERMISSIONS_BOUNDARY_ARN>` `<OWNER>` を確認済み ([未確定事項](../../01_constraints/unconfirmed-items.md)) |
| 社内 PC | VS Code、Git、ブラウザー。IaC ZIP を作成できる ([コード管理 §4](../../02_common-design/code-management.md#4-非公開-iac-zip)) |
| 外向き通信 | Public Subnet から `releases.hashicorp.com` / `registry.terraform.io` へ到達できる (未確定事項 Q-02。§23 で実測) |

## 5. 設計判断

| 判断 | 内容 | 理由 |
| --- | --- | --- |
| Runner の配置 | Public Subnet + Public IPv4、インバウンドなし | Private Subnet からの外向き通信が未確認。SSM は既存 VPC Endpoint 経由で接続できる |
| 接続方式 | SSM Session Manager のみ | キーペアとインバウンドを不要にする |
| OS | Amazon Linux 2023 | SSM Agent、AWS CLI v2、gnupg が標準で入っている |
| インスタンスタイプ | `t3.micro` | Terraform の実行には十分。クォータ内 |
| Terraform 導入 | user data で固定版を取得し、PGP 署名 + 固定 SHA256 で検証 | 改ざん・取り違え防止 |
| IaC の搬送 | 社内 PC で ZIP → コンソールで S3 へアップロード → Runner が取得 | Public GitHub へ非公開 IaC を置かない |
| State | S3 Backend (SSE-S3、バージョニング、`use_lockfile`) | DynamoDB を使わずにロックできる (Terraform 1.10 以降) |
| Bootstrap の管理 | 手動作成・手動削除 | 仕様。Terraform で自分自身の土台を管理すると週末削除との整合が複雑になる |

## 6. 採用コンポーネント

| コンポーネント | 用途 |
| --- | --- |
| S3 (汎用バケット 1 つ) | `state/` (State とロック)、`iac/` (IaC ZIP)、`transfer/` (退避用) |
| IAM ロール + インスタンスプロファイル | Runner の一時認証情報 |
| カスタマー管理ポリシー × 3 + AWS 管理ポリシー × 1 | base / s3-prefix / workload + `AmazonSSMManagedInstanceCore` |
| Security Group | インバウンドなし、アウトバウンド 443 のみ |
| EC2 (AL2023, t3.micro, gp2) | Terraform Runner |
| SSM Session Manager (既存 VPC Endpoint) | 接続 |

## 7. 不採用コンポーネントと切替条件

| 不採用 | 理由 | 採用へ切り替える条件 |
| --- | --- | --- |
| AWS CloudShell | 利用不可 | 利用可能になった場合 (ただし週末削除後の再設定は同様に必要) |
| DynamoDB ロックテーブル | `use_lockfile` で代替でき、毎週の手動作成が増える | Terraform 1.10 未満を使わざるを得ない場合 |
| SSE-KMS (カスタマー管理キー) | 毎週の手動作成対象が増える | 監査要件でキーの管理が求められた場合 |
| Private Subnet 配置 | 外向き通信の経路が未確認 | [ネットワーク設計 §2](../../02_common-design/network.md#2-外向き通信の案と切替条件) の切替条件を満たした場合 |
| 踏み台 / SSH | SSM で代替できる | なし |
| GitHub から IaC を取得 | 非公開 IaC を Public に置けない | 非公開リポジトリの利用が許可され、Runner から到達できる場合 |

## 8. 制約、代替策、残存リスク

| 制約・リスク | 代替策・対策 |
| --- | --- |
| Runner のロールは Terraform が扱う全リソースを変更できる | タグ `Owner`、ロール名接頭辞、VPC、インスタンスタイプ、EBS 条件で範囲を限定 ([IAM 設計 §5](../../02_common-design/iam.md#5-ワイルドカードを使っている箇所と理由)) |
| Runner 上の IaC ZIP には tfvars (アカウント ID 等) が含まれる | Runner は週末に削除。`umask 077` で展開。Runner 上で IaC を編集しない |
| Boundary が Runner の操作を拒否する可能性 (Q-06) | 初回 apply で確認。拒否された場合は §31 |
| HashiCorp の PGP 鍵のローテーション | フィンガープリント不一致で停止する。公式サイトで新しい鍵を確認し [バージョン固定](../../02_common-design/version-pinning.md) を更新 |
| Public Subnet から Registry へ到達できない (Q-02) | [ネットワーク設計 §4](../../02_common-design/network.md#4-public-subnet-から外部へ接続できない場合) |

## 9. Mermaid 構成図

```mermaid
flowchart TB
  subgraph PC["社内 PC"]
    GIT["ローカル Git<br/>IaC + tfvars"]
    BR["ブラウザー<br/>AWS コンソール"]
  end
  subgraph AWS["サンドボックス (ap-northeast-1)"]
    subgraph S3B["Bootstrap S3 (手動)"]
      ST["state/*.tfstate<br/>*.tflock"]
      IAC["iac/*.zip"]
      TR["transfer/"]
    end
    subgraph Pub["Public Subnet"]
      RUN["Terraform Runner EC2 (手動)<br/>AL2023 / t3.micro<br/>SG: inbound なし"]
    end
    ROLE["IAM ロール (手動)<br/>+ Boundary"]
    VPCE["SSM VPC Endpoint (既存)"]
  end
  HC["releases.hashicorp.com<br/>registry.terraform.io"]
  GIT -- "ZIP 作成" --> BR
  BR -- "アップロード" --> IAC
  BR -- "Session Manager" --> VPCE --> RUN
  ROLE -. "インスタンスプロファイル" .- RUN
  RUN -- "HTTPS 443" --> HC
  RUN -- "HTTPS 443" --> ST
  RUN -- "HTTPS 443" --> IAC
```

## 10. 通信フロー

| # | 送信元 | 宛先 | ポート | 用途 |
| --- | --- | --- | --- | --- |
| 1 | 社内 PC ブラウザー | AWS コンソール | 443 | 手動作成、Session Manager |
| 2 | Runner (SSM Agent) | SSM VPC Endpoint | 443 | セッション |
| 3 | Runner | `releases.hashicorp.com`、`www.hashicorp.com` | 443 | Terraform CLI、PGP 鍵 |
| 4 | Runner | `registry.terraform.io` とその配布先 | 443 | AWS Provider |
| 5 | Runner | S3 (ap-northeast-1) | 443 | State、IaC ZIP |
| 6 | Runner | AL2023 パッケージリポジトリ | 443 | unzip / git / jq |
| 7 | Runner | EC2 / IAM API | 443 | Terraform の操作 |

インバウンドはない。

## 11. データフロー

| データ | 作成場所 | 経路 | 保存場所 | 寿命 |
| --- | --- | --- | --- | --- |
| IaC ZIP (tfvars 含む) | 社内 PC | コンソールでアップロード → `iac-fetch` | S3 `iac/`、Runner `~/iac/` | 週末まで |
| State | Runner | Terraform Backend | S3 `state/` | 週末まで (destroy で空にする) |
| Plan | Runner | ローカル | Runner の作業ディレクトリ | 適用後すぐ削除 |
| ログ | Runner | - | `/var/log/runner-setup.log` | 週末まで |

## 12. 作成する AWS リソース

| # | リソース | 名前 | 管理 |
| --- | --- | --- | --- |
| 1 | S3 バケット | `<BOOTSTRAP_BUCKET_NAME>` | 手動 |
| 2 | バケットポリシー | (TLS 強制) | 手動 |
| 3 | カスタマー管理ポリシー | `<owner>-tfrunner-base-policy-01` | 手動 |
| 4 | カスタマー管理ポリシー | `<owner>-tfrunner-s3-policy-01` | 手動 |
| 5 | カスタマー管理ポリシー | `<owner>-tfrunner-workload-policy-01` | 手動 |
| 6 | IAM ロール + インスタンスプロファイル | `<owner>-tfrunner-role-01` | 手動 |
| 7 | Security Group | `<owner>-tfrunner-sg-01` | 手動 |
| 8 | EC2 インスタンス + ルート EBS | `<owner>-tfrunner-ec2-01` | 手動 |

## 13. パラメーター

| 名前 | 値 | 使う場所 |
| --- | --- | --- |
| `<AWS_ACCOUNT_ID>` | 未確定 | IAM ポリシー JSON |
| `<BOOTSTRAP_BUCKET_NAME>` | 未確定 | S3、IAM ポリシー JSON、`backend.hcl` |
| `<OWNER>` | 未確定 | 名前、タグ、IAM ポリシー JSON |
| `<VPC_ID>` | 未確定 | SG、IAM ポリシー JSON |
| `<PUBLIC_SUBNET_ID>` | 未確定 | Runner EC2 |
| `<PERMISSIONS_BOUNDARY_ARN>` | 未確定 | IAM ポリシー JSON (workload) |
| Terraform | 1.16.4 | `runner-setup.sh` |
| インスタンスタイプ | `t3.micro` | Runner EC2 |
| ルート EBS | 16 GiB、`gp2`、暗号化 | Runner EC2 |

## 14. 命名とタグ

[命名とタグ](../../02_common-design/naming-and-tagging.md) に従う。手動作成のため、各リソースに次のタグを付ける。

| キー | 値 |
| --- | --- |
| `Name` | 各リソース名 |
| `Owner` | `<OWNER>` |
| `Purpose` | `tfrunner` |
| `Environment` | `sandbox` |
| `ManagedBy` | `manual-bootstrap` |
| `ExpiresAt` | `<EXPIRES_AT_YYYY_MM_DD>` |

## 15. IAM 設計

| ファイル | コンソールでの扱い |
| --- | --- |
| [iam/runner-trust-policy.json](iam/runner-trust-policy.json) | ロール作成時の「カスタム信頼ポリシー」 |
| [iam/runner-base-policy.json](iam/runner-base-policy.json) | カスタマー管理ポリシー `<owner>-tfrunner-base-policy-01` |
| [iam/runner-s3-prefix-policy.json](iam/runner-s3-prefix-policy.json) | カスタマー管理ポリシー `<owner>-tfrunner-s3-policy-01` |
| [iam/runner-workload-policy.json](iam/runner-workload-policy.json) | カスタマー管理ポリシー `<owner>-tfrunner-workload-policy-01` |
| [iam/bootstrap-bucket-policy.json](iam/bootstrap-bucket-policy.json) | S3 のバケットポリシー |
| `AmazonSSMManagedInstanceCore` | AWS 管理ポリシー (そのままアタッチ) |

各ポリシーの目的、ワイルドカードの理由と縮小方法は [IAM 設計](../../02_common-design/iam.md) を参照。

**プレースホルダーの置き換え**: JSON はリポジトリ内で書き換えない。VS Code で新しい無題ファイルへ貼り付けて置き換え、コンソールへ貼り付けたら保存せずに閉じる。保存が必要な場合はファイル名を `*.local.json` にする (`.gitignore` 対象)。貼り付け前に `<` が残っていないことを検索で確認する。

カスタマー管理ポリシーを作成できない場合 (未確定事項 Q-05) は、ロール作成後に「アクセス許可を追加」→「インラインポリシーを作成」で同じ JSON を 3 つのインラインポリシーとして登録する。

## 16. Permissions Boundary

| 対象 | 設定 |
| --- | --- |
| Runner ロール | 作成画面で `ChildAccountRoleBoundary` を設定 (§19-C) |
| Runner が作成するロール | workload ポリシーの条件 `iam:PermissionsBoundary = <PERMISSIONS_BOUNDARY_ARN>` により、Boundary なしでは作成できない |

## 17. Security Group 設計

| 方向 | プロトコル | ポート | 相手 | 説明 |
| --- | --- | --- | --- | --- |
| インバウンド | - | - | - | **ルールなし** |
| アウトバウンド | TCP | 443 | `0.0.0.0/0` | HTTPS (SSM、S3、HashiCorp、AWS API) |

既定の「すべてのトラフィック」アウトバウンドは削除する。

## 18. Terraform 構成

Bootstrap リソース自体は Terraform 管理外。Runner で使う Terraform 側の構成:

| パス | 役割 |
| --- | --- |
| [08_iac/bootstrap/backend.hcl.example](../../08_iac/bootstrap/backend.hcl.example) | 全 Root Module 共通の Backend 設定 (bucket のみ)。コピーして `backend.hcl` を作る |
| [08_iac/bootstrap/smoke-test/](../../08_iac/bootstrap/smoke-test/main.tf) | 疎通確認用 Root Module (AWS リソースを作らない) |
| [scripts/runner-setup.sh](scripts/runner-setup.sh) | Runner の user data |

## 19. 手動例外手順

> [!NOTE]
> 画面文言は変わることがある。文言が異なっても、表の **設定値** が一致していればよい。

### A. Bootstrap S3 バケット

S3 → 「バケットを作成」。

| 設定 | 値 |
| --- | --- |
| バケットタイプ | 汎用 |
| リージョン | `ap-northeast-1` |
| バケット名 | `<BOOTSTRAP_BUCKET_NAME>` |
| オブジェクト所有者 | ACL 無効 (バケット所有者の強制) |
| パブリックアクセスをすべてブロック | **オン** (4 項目すべて) |
| バケットのバージョニング | **有効にする** |
| タグ | §14 の 6 項目 (`Name` はバケット名) |
| デフォルトの暗号化 | SSE-S3 (Amazon S3 マネージドキー) |
| オブジェクトロック | 無効 |

作成後:

1. バケット →「アクセス許可」→「バケットポリシー」→「編集」→ [bootstrap-bucket-policy.json](iam/bootstrap-bucket-policy.json) の `<BOOTSTRAP_BUCKET_NAME>` を置き換えて貼り付け →「変更の保存」。
2. 確認:

   | タブ | 確認する値 |
   | --- | --- |
   | プロパティ | バケットのバージョニング = 有効、デフォルトの暗号化 = SSE-S3 |
   | アクセス許可 | パブリックアクセスをすべてブロック = オン、オブジェクト所有者 = バケット所有者の強制 |
   | アクセス許可 → バケットポリシー | `DenyInsecureTransport` がある |

### B. IAM ポリシー (3 件)

IAM →「ポリシー」→「ポリシーの作成」→「JSON」。

| ポリシー名 | JSON | 置き換えるプレースホルダー |
| --- | --- | --- |
| `<owner>-tfrunner-base-policy-01` | [runner-base-policy.json](iam/runner-base-policy.json) | `<AWS_ACCOUNT_ID>` |
| `<owner>-tfrunner-s3-policy-01` | [runner-s3-prefix-policy.json](iam/runner-s3-prefix-policy.json) | `<BOOTSTRAP_BUCKET_NAME>` |
| `<owner>-tfrunner-workload-policy-01` | [runner-workload-policy.json](iam/runner-workload-policy.json) | `<AWS_ACCOUNT_ID>` `<OWNER>` `<VPC_ID>` `<PERMISSIONS_BOUNDARY_ARN>` |

- ポリシーエディターの「セキュリティ警告 / エラー」が 0 件であること (警告が出た場合は内容を確認し、[IAM 設計 §5](../../02_common-design/iam.md#5-ワイルドカードを使っている箇所と理由) の想定内か判断する)。
- タグ: §14 の 6 項目。

### C. Runner 用 IAM ロール

IAM →「ロール」→「ロールを作成」。

| 設定 | 値 |
| --- | --- |
| 信頼されたエンティティタイプ | カスタム信頼ポリシー → [runner-trust-policy.json](iam/runner-trust-policy.json) を貼り付け (置き換え不要) |
| 許可ポリシー | `AmazonSSMManagedInstanceCore`、手順 B の 3 件 (合計 4 件) |
| アクセス許可の境界を設定 | **アクセス許可の境界を使用してロールのアクセス許可の上限を設定** → `ChildAccountRoleBoundary` |
| ロール名 | `<owner>-tfrunner-role-01` |
| 説明 | `Terraform runner (manual bootstrap)` |
| タグ | §14 の 6 項目 |

確認: ロール詳細 →「アクセス許可」タブで「アクセス許可の境界」に `ChildAccountRoleBoundary`、許可ポリシーが 4 件。「信頼関係」タブで `ec2.amazonaws.com`。

### D. Runner 用 Security Group

EC2 →「セキュリティグループ」→「セキュリティグループを作成」。

| 設定 | 値 |
| --- | --- |
| セキュリティグループ名 | `<owner>-tfrunner-sg-01` |
| 説明 | `Terraform runner - no inbound, HTTPS outbound only` |
| VPC | `<VPC_ID>` |
| インバウンドルール | **なし** (追加しない) |
| アウトバウンドルール | 既定の「すべてのトラフィック」を **削除** し、タイプ HTTPS / TCP / 443 / 送信先 `0.0.0.0/0` / 説明 `HTTPS outbound` を追加 |
| タグ | §14 の 6 項目 |

### E. Terraform Runner EC2

EC2 →「インスタンスを起動」。

| 設定 | 値 |
| --- | --- |
| 名前とタグ | 名前 `<owner>-tfrunner-ec2-01`。「追加のタグ」で §14 の残り 5 項目を追加し、リソースタイプに **インスタンスとボリューム** を指定 |
| AMI | Amazon Linux 2023 AMI (カーネル 6.x)、アーキテクチャ **64 ビット (x86)**、所有者 amazon (クイックスタートの「検証済みプロバイダー」) |
| インスタンスタイプ | `t3.micro` |
| キーペア | **キーペアなしで続行** |
| VPC | `<VPC_ID>` |
| サブネット | `<PUBLIC_SUBNET_ID>` |
| パブリック IP の自動割り当て | **有効化** |
| ファイアウォール | 既存のセキュリティグループを選択 → `<owner>-tfrunner-sg-01` のみ |
| ストレージ | 16 GiB、ボリュームタイプ **gp2** (既定の gp3 から変更)、暗号化 = 暗号化済み、終了時に削除 = はい |
| 高度な詳細 → IAM インスタンスプロファイル | `<owner>-tfrunner-role-01` |
| 高度な詳細 → メタデータバージョン | **V2 のみ (トークンは必須)** |
| 高度な詳細 → メタデータのレスポンスホップの制限 | `1` |
| 高度な詳細 → 終了保護 | 無効 (毎週削除するため) |
| 高度な詳細 → ユーザーデータ | [scripts/runner-setup.sh](scripts/runner-setup.sh) の全文を貼り付け |

「インスタンスを起動」後、ステータスチェックが合格するまで待つ (5 分程度)。user data の完了はさらに 1〜3 分かかる。

### F. IaC ZIP のアップロード

1. 社内 PC で ZIP を作成し、ファイル名と SHA256 を控える ([コード管理 §4](../../02_common-design/code-management.md#4-非公開-iac-zip))。
2. S3 → `<BOOTSTRAP_BUCKET_NAME>` →「アップロード」→ ZIP を追加 →「送信先」を `s3://<BOOTSTRAP_BUCKET_NAME>/iac/` にする (フォルダー `iac` を作成して中へアップロード) →「アップロード」。
3. オブジェクトのキーが `iac/iac-<日時>.zip` であることを確認する。

## 20. OS とミドルウェア初期設定

`runner-setup.sh` (user data) が次を行う。手動で再実行する場合は Session Manager で接続し、スクリプト全文を `~/runner-setup.sh` に貼り付けて `sudo bash ~/runner-setup.sh`。

| 項目 | 内容 |
| --- | --- |
| 到達性確認 | HashiCorp、Registry、GitHub、S3 への HTTPS をログに記録。HashiCorp に届かなければ停止 |
| パッケージ | `unzip`、`git`、`jq` (`gpg` は標準の `gnupg2-minimal` を使う) |
| Terraform | 1.16.4 を `/usr/local/bin/terraform` へ。PGP 鍵フィンガープリント照合 → 署名検証 → SHA256SUMS 照合 → 固定 SHA256 照合 |
| `iac-fetch` | S3 から ZIP を取得し、SHA256 照合、State / Plan 混入検査、`~/iac/current` へ展開 |
| 環境変数 | `TF_PLUGIN_CACHE_DIR`、`AWS_REGION=ap-northeast-1` (`/etc/profile.d/terraform.sh`) |

## 21. Docker 構成

該当なし (Runner では Docker を使わない)。

## 22. アプリケーション配置

Runner の「アプリケーション」は IaC 一式。

```bash
# Session Manager 接続後 (ssm-user)
iac-fetch s3://<BOOTSTRAP_BUCKET_NAME>/iac/<IAC_ZIP_NAME> <IAC_ZIP_SHA256>
ls ~/iac/current
```

- Runner 上で IaC を編集しない (正本は社内 PC)。修正が必要な場合は社内 PC で修正 → ZIP 再作成 → アップロード → `iac-fetch` し直す。
- `iac-fetch` は実行ごとに新しいディレクトリへ展開し、`~/iac/current` を張り替える。`.terraform/` は再作成されるため `terraform init` からやり直す。

## 23. 正常系確認

### 1. 接続と初期化結果

EC2 → `<owner>-tfrunner-ec2-01` →「接続」→「Session Manager」→「接続」。

```bash
cat /var/lib/runner-setup/status          # success
terraform version                         # Terraform v1.16.4 on linux_amd64
sudo grep -E 'reach|PGP|OK' /var/log/runner-setup.log
aws sts get-caller-identity --query Arn --output text | sed -E 's/[0-9]{12}/<AWS_ACCOUNT_ID>/'
```

最後の出力が `arn:aws:sts::<AWS_ACCOUNT_ID>:assumed-role/<owner>-tfrunner-role-01/i-...` であること。

### 2. IaC 取得

```bash
iac-fetch s3://<BOOTSTRAP_BUCKET_NAME>/iac/<IAC_ZIP_NAME> <IAC_ZIP_SHA256>
test -f ~/iac/current/08_iac/bootstrap/backend.hcl && echo backend.hcl OK
```

### 3. smoke-test (Backend とロック、Subnet 経路)

```bash
cd ~/iac/current/08_iac/bootstrap/smoke-test
terraform init -input=false -backend-config=../backend.hcl
terraform plan -out=smoke.tfplan
terraform apply smoke.tfplan && rm -f smoke.tfplan
terraform output subnet_routes
aws s3 ls "s3://$(awk -F'"' '/^bucket/ {print $2}' ../backend.hcl)/state/00_smoke-test/"
```

期待値:

| 確認 | 期待値 |
| --- | --- |
| `terraform init` | `Successfully configured the backend "s3"!`、Provider 6.66.0 がロックファイルのハッシュで検証される |
| `apply` | `1 added` (`terraform_data.smoke` のみ) |
| `subnet_routes` | `<PUBLIC_SUBNET_ID>` の `default_route_via = "igw"` |
| `aws s3 ls` | `terraform.tfstate` がある。`.tflock` が **残っていない** (ロックが解放された) |

## 24. 異常系確認

ガードレールが働くことを確認する。いずれも **拒否されることが正しい結果**。

```bash
BUCKET=$(awk -F'"' '/^bucket/ {print $2}' ~/iac/current/08_iac/bootstrap/backend.hcl)
# 1. 許可プレフィックス外の一覧 → AccessDenied
aws s3 ls "s3://${BUCKET}/"
# 2. バケット設定の変更 → AccessDenied (Enabled の再設定なので、万一許可されても状態は変わらない)
aws s3api put-bucket-versioning --bucket "${BUCKET}" --versioning-configuration Status=Enabled
# 3. 東京以外のリージョン → UnauthorizedOperation / AccessDenied
aws ec2 describe-instances --region us-east-1 --max-items 1
# 4. アクセスキーの作成 → AccessDenied
aws iam create-access-key
```

| 状況 | 期待される挙動 | 確認場所 |
| --- | --- | --- |
| user data 失敗 | `/var/lib/runner-setup/status` が `failed:<行番号>` | `/var/log/runner-setup.log` |
| PGP / SHA256 不一致 | Terraform を導入せず停止 | 同上 |
| ZIP の SHA256 不一致 | `iac-fetch` が展開せず終了 | ターミナル |
| ZIP に State / Plan が混入 | `iac-fetch` が展開せず終了 | ターミナル |

## 25. ログと監視

| ログ | 場所 |
| --- | --- |
| user data | `/var/log/runner-setup.log`、`/var/log/cloud-init-output.log` |
| Terraform の詳細 | 必要時のみ `TF_LOG=DEBUG terraform plan 2> ~/tf-debug.log`。**トークン等を含みうるため共有せず、確認後に削除** |
| AWS API | CloudTrail (利用可能な場合) |

監視は行わない (検証用・短命のため)。

## 26. 停止手順

EC2 → `<owner>-tfrunner-ec2-01` →「インスタンスの状態」→「インスタンスを停止」。State は S3 にあるため停止してよい。

## 27. 個別削除

| 対象 | 方法 | 注意 |
| --- | --- | --- |
| Runner だけを作り直す | Runner を終了 → §19-E で再作成 | State・IaC ZIP は S3 に残るので影響なし |
| IaC ZIP の古い版 | S3 → `iac/` → 対象を削除 | 使用中の版を消さない |
| smoke-test の State | `terraform destroy` (smoke-test ディレクトリで) | AWS リソースはない |

## 28. 全体削除

[週末前の破棄 §5](../../03_common-runbook/pre-weekend-teardown.md#5-手動-bootstrap-リソースの削除) の順序 (Runner → SG → S3 → IAM ロール → ポリシー) で削除する。

> [!CAUTION]
> Bootstrap S3 を削除すると全パターンの State が消える。必ずすべてのパターンを destroy し、State が空であることを確認してから削除する。

## 29. 週末前の退避

Runner 上に退避すべきデータはない。Runner 上で IaC を編集していないこと (正本は社内 PC) を確認する。

## 30. 週末後の再構築

§19 の A〜F → §23 を順に実施する。バケット名を変えた場合は `backend.hcl`、tfvars、IAM ポリシー JSON の 3 か所を更新してから ZIP を作る ([週末後の再構築 §2](../../03_common-runbook/post-weekend-rebuild.md#2-社内-pc-設定更新と-iac-zip))。

## 31. トラブルシューティング

| 症状 | 参照 |
| --- | --- |
| Session Manager で接続できない | [06 SSM](../../06_troubleshooting/README.md#session-manager-で接続できない) |
| user data が失敗した | [06 Runner](../../06_troubleshooting/README.md#runner-の初期化が失敗した) |
| `terraform init` が失敗する | [06 init](../../06_troubleshooting/README.md#terraform-init-が失敗する) |
| AccessDenied | [06 AccessDenied](../../06_troubleshooting/README.md#terraform-apply-で-accessdenied--unauthorizedoperation) |
| ロックが残る | [06 lock](../../06_troubleshooting/README.md#state-のロックが残っている) |

## 32. コスト

| 課金要素 | 備考 |
| --- | --- |
| EC2 `t3.micro` (Linux) | 起動中のみ。使わない日は停止 |
| EBS 16 GiB gp2 | 停止中も課金。週末に削除 |
| Public IPv4 | 0.005 USD/時 (インスタンスに関連付いている間) |
| S3 | State と ZIP は数 MB。リクエスト料金もわずか |

単価は AWS 料金ページで確認し、確認日を記録する。

## 33. 未確定事項

U-01、U-02、U-03、U-06、U-07、U-08、Q-02、Q-05、Q-06 ([未確定事項台帳](../../01_constraints/unconfirmed-items.md))。

## 34. 更新履歴

| 日付 | 内容 |
| --- | --- |
| 2026-09-29 | 初版 |
