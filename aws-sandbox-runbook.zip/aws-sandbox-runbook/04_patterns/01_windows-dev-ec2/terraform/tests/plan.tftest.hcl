# terraform test (モック Provider)。AWS へ接続せず、命名・SG・EBS・IMDS・入力検証を確認する。
#   terraform init -backend=false && terraform test

mock_provider "aws" {
  mock_data "aws_ami" {
    defaults = {
      id   = "ami-0123456789abcdef0"
      name = "Windows_Server-2022-Japanese-Full-Base-2026.09.10"
    }
  }
  mock_data "aws_partition" {
    defaults = { partition = "aws" }
  }
  mock_data "aws_iam_policy_document" {
    defaults = { json = "{\"Version\":\"2012-10-17\",\"Statement\":[]}" }
  }
}

variables {
  aws_account_id           = "000000000000"
  owner                    = "tester"
  expires_at               = "2026-10-04"
  vpc_id                   = "vpc-0123456789abcdef0"
  public_subnet_id         = "subnet-0123456789abcdef0"
  permissions_boundary_arn = "arn:aws:iam::000000000000:policy/example-boundary"
  gateway_allowed_cidrs    = ["192.0.2.10/32", "198.51.100.20/32", "203.0.113.30/32"]
  key_pair_public_key      = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDexample tester"
  transfer_bucket_name     = "example-bootstrap-bucket"

  # 作業ツリーの terraform.tfvars に影響されないよう、テストが前提とする値をすべて明示する
  purpose                 = "windev"
  sequence                = "01"
  key_pair_name           = null
  instance_type           = "t3.medium"
  root_volume_size_gb     = 50
  run_init_script_on_boot = true
}

run "default_plan" {
  command = plan

  assert {
    condition     = module.windows.ami_name == "Windows_Server-2022-Japanese-Full-Base-2026.09.10"
    error_message = "AMI はデータソース検索結果を使うこと。"
  }
  assert {
    condition     = module.instance_role.role_name == "tester-windev-role-01"
    error_message = "ロール名が命名規則 <owner>-<purpose>-<resource>-<sequence> に従っていない。"
  }
  assert {
    condition     = output.key_pair_name == "tester-windev-key-01"
    error_message = "キーペア名が命名規則に従っていない。"
  }
  assert {
    condition     = output.transfer_s3_uri == "s3://example-bootstrap-bucket/transfer/tester-windev/"
    error_message = "退避先 URI が想定と異なる。"
  }
  assert {
    condition = alltrue([
      for kind in ["rdp", "ssh", "icmp"] :
      module.windows.gateway_ingress_cidrs[kind] == tolist(["192.0.2.10/32", "198.51.100.20/32", "203.0.113.30/32"])
    ])
    error_message = "gateway_allowed_cidrs の 3 件それぞれに RDP / SSH / ICMP のルールを作成すること。"
  }
}

run "gateway_cidr_added" {
  # 送信元 IP の追加は terraform.tfvars の配列変更だけで反映される (コード変更不要)
  command = plan

  variables {
    gateway_allowed_cidrs = ["192.0.2.10/32", "198.51.100.20/32", "203.0.113.30/32", "203.0.113.40/32"]
  }

  assert {
    condition = alltrue([
      for kind in ["rdp", "ssh", "icmp"] :
      contains(module.windows.gateway_ingress_cidrs[kind], "203.0.113.40/32") && length(module.windows.gateway_ingress_cidrs[kind]) == 4
    ])
    error_message = "追加した CIDR に RDP / SSH / ICMP のルールが作成されること。"
  }
}

run "invalid_instance_type_rejected" {
  command = plan

  variables {
    instance_type = "m5.large"
  }

  expect_failures = [var.instance_type]
}

run "reserved_like_owner_rejected" {
  command = plan

  variables {
    owner = "cp"
  }

  expect_failures = [var.owner]
}

