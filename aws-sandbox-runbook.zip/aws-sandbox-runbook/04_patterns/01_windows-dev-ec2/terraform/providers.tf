provider "aws" {
  region              = var.aws_region
  allowed_account_ids = [var.aws_account_id]

  default_tags {
    tags = {
      Owner       = var.owner
      Purpose     = var.purpose
      Environment = "sandbox"
      ManagedBy   = "terraform"
      ExpiresAt   = var.expires_at
    }
  }
}
