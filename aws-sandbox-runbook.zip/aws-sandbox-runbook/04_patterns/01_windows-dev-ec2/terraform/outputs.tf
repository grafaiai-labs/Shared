output "instance_id" {
  description = "Windows EC2 のインスタンス ID。"
  value       = module.windows.instance_id
}

output "public_ip" {
  description = "RDP 接続先 Public IPv4。停止・起動で変わるため、接続前にコンソールでも確認する。"
  value       = module.windows.public_ip
}

output "security_group_id" {
  description = "Windows 用 SG。Pattern 02 の app_ingress_source_security_group_ids に指定できる。"
  value       = module.windows.security_group_id
}

output "ami_name" {
  description = "使用した公式 AMI 名。"
  value       = module.windows.ami_name
}

output "key_pair_name" {
  description = "パスワード復号に使うキーペア名。"
  value       = local.key_name
}

output "transfer_s3_uri" {
  description = "退避用 S3 URI (transfer_bucket_name 指定時のみ)。"
  value       = var.transfer_bucket_name == null ? null : "s3://${var.transfer_bucket_name}/transfer/${local.base_name}/"
}
