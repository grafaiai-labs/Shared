locals {
  base_name = "${var.owner}-${var.purpose}"
  key_name  = coalesce(var.key_pair_name, "${local.base_name}-key-${var.sequence}")

  init_script = file("${path.module}/../scripts/Initialize-WindowsDev.ps1")
  user_data   = var.run_init_script_on_boot ? "<powershell>\n${local.init_script}\n</powershell>\n<persist>false</persist>\n" : null
}

module "instance_role" {
  source = "../../../08_iac/modules/ssm-instance-role"

  name                     = "${local.base_name}-role-${var.sequence}"
  permissions_boundary_arn = var.permissions_boundary_arn
  transfer_bucket_name     = var.transfer_bucket_name
  transfer_prefix          = "transfer/${local.base_name}"
}

module "windows" {
  source = "../../../08_iac/modules/windows-dev-ec2"

  name                      = "${local.base_name}-ec2-${var.sequence}"
  vpc_id                    = var.vpc_id
  subnet_id                 = var.public_subnet_id
  instance_type             = var.instance_type
  root_volume_size_gb       = var.root_volume_size_gb
  rdp_allowed_cidrs         = var.rdp_allowed_cidrs
  key_name                  = local.key_name
  public_key_openssh        = var.key_pair_public_key
  iam_instance_profile_name = module.instance_role.instance_profile_name
  user_data                 = local.user_data
}
