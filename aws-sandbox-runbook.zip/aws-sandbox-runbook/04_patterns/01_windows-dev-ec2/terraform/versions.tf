terraform {
  # Terraform / AWS Provider は完全一致で固定する。更新手順は 02_common-design/version-pinning.md を参照。
  required_version = "= 1.16.4"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "= 6.66.0"
    }
  }
}
