variable "aws_account_id" {
  description = "操作対象の AWS アカウント ID。誤アカウントへの適用を防ぐため allowed_account_ids に使う。"
  type        = string

  validation {
    condition     = can(regex("^[0-9]{12}$", var.aws_account_id))
    error_message = "aws_account_id は 12 桁の数字で指定してください。"
  }
}

variable "aws_region" {
  description = "利用リージョン。"
  type        = string
  default     = "ap-northeast-1"

  validation {
    condition     = var.aws_region == "ap-northeast-1"
    error_message = "このランブックは ap-northeast-1 のみを対象とします。"
  }
}

variable "owner" {
  description = "命名の先頭要素とタグ Owner に使う利用者識別子。小文字英字で始まる 3〜16 文字 (ハイフン不可)。"
  type        = string

  validation {
    condition     = can(regex("^[a-z][a-z0-9]{2,15}$", var.owner))
    error_message = "owner は小文字英字で始まる英数字 3〜16 文字で指定してください (ハイフン不可)。"
  }
}

variable "purpose" {
  description = "命名の 2 番目の要素とタグ Purpose。"
  type        = string
  default     = "windev"

  validation {
    condition     = can(regex("^[a-z][a-z0-9]{1,15}$", var.purpose))
    error_message = "purpose は小文字英字で始まる英数字 2〜16 文字で指定してください (ハイフン不可)。"
  }
}

variable "sequence" {
  description = "命名の末尾に付ける 2 桁の連番。"
  type        = string
  default     = "01"

  validation {
    condition     = can(regex("^[0-9]{2}$", var.sequence))
    error_message = "sequence は 2 桁の数字で指定してください。"
  }
}

variable "expires_at" {
  description = "タグ ExpiresAt。通常は直近の定期削除日 (YYYY-MM-DD)。"
  type        = string

  validation {
    condition     = can(regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}$", var.expires_at))
    error_message = "expires_at は YYYY-MM-DD 形式で指定してください。"
  }
}

variable "vpc_id" {
  description = "既存 VPC の ID。"
  type        = string
}

variable "public_subnet_id" {
  description = "既存 Public Subnet の ID。"
  type        = string
}

variable "permissions_boundary_arn" {
  description = "IAM ロール作成時に必ず適用する Permissions Boundary の ARN。"
  type        = string
}

variable "gateway_allowed_cidrs" {
  description = "接続ゲートウェイの送信元 CIDR の配列。各 CIDR から RDP (TCP 3389)、SSH (TCP 22)、ICMP を許可する。CIDR の追加・削除はこの配列の変更だけで行う。"
  type        = list(string)
}

variable "instance_type" {
  description = "インスタンスタイプ。"
  type        = string
  default     = "t3.medium"

  validation {
    condition     = contains(["t3.nano", "t3.micro", "t3.small", "t3.medium", "t2.nano", "t2.micro", "t2.small", "t2.medium"], var.instance_type)
    error_message = "利用可能なインスタンスタイプ (t3/t2 の nano〜medium) から指定してください。"
  }
}

variable "root_volume_size_gb" {
  description = "ルート EBS のサイズ (GB)。"
  type        = number
  default     = 50
}

variable "key_pair_public_key" {
  description = "Administrator パスワード復号用 RSA 公開鍵 (ssh-rsa ...)。null の場合はコンソールで作成済みのキーペア名を key_pair_name で参照する。"
  type        = string
  default     = null
}

variable "key_pair_name" {
  description = "キーペア名。null の場合は <owner>-<purpose>-key-<sequence>。"
  type        = string
  default     = null
}

variable "transfer_bucket_name" {
  description = "週末前の退避に使う S3 バケット名。null の場合は S3 権限を付与しない。"
  type        = string
  default     = null
}

variable "run_init_script_on_boot" {
  description = "初回起動時に Initialize-WindowsDev.ps1 を user data として実行する。"
  type        = bool
  default     = true
}
