# Pattern 01: Windows 開発用 EC2

SMART Gateway 経由の RDP で使う GUI 中心のリモート開発端末 (Windows Server 2022 Japanese) を Terraform で構築し、VS Code / Git / Node.js / Python / AWS CLI / Claude Code / Snowflake CLI を PowerShell で初期化する。Docker は対象外。

## 1. 用途

- ブラウザー、VS Code、Claude Code を使う GUI 作業端末。
- 個人 Public GitHub への push、Snowflake CLI での確認。
- Linux Docker 開発用 EC2 (Pattern 02) 上のアプリをブラウザーで確認する端末 (任意)。

## 2. 成功条件

- [ ] `terraform plan` で RDP の許可元が `<RDP_ALLOWED_CIDR>` のみ、ルート EBS が `gp2`、IMDSv2 必須になっている
- [ ] 公式 AMI (`Windows_Server-2022-Japanese-Full-Base-*`) が検索で選ばれる (AMI ID を固定していない)
- [ ] Administrator パスワードを取得し、SMART Gateway 経由で RDP 接続できる
- [ ] `C:\ProgramData\DevBootstrap\status.txt` が `success`
- [ ] [Test-WindowsDev.ps1](scripts/Test-WindowsDev.ps1) がすべて PASS
- [ ] 個人 Public GitHub のリポジトリを clone / push できる
- [ ] 週末前に `terraform destroy` で全リソースが削除される

## 3. 非スコープ

- Docker Desktop / WSL2 (Linux EC2 で代替)
- Active Directory 参加、複数ユーザー運用
- 業務ソフトウェアの導入、社内システムへの接続
- パスワードの長期保管 (毎週作り直す)

## 4. 前提条件

- [Pattern 00](../00_terraform-bootstrap/README.md) が完了し、Runner で smoke-test が成功している。
- `<RDP_ALLOWED_CIDR>` が確定している (U-05)。**未確定のまま広い範囲を入れない。**
- RSA キーを用意している (§19-A)。

## 5. 設計判断

| 判断 | 内容 | 理由 |
| --- | --- | --- |
| 配置 | Public Subnet + Public IPv4 | 仕様。SMART Gateway から RDP するため |
| RDP 許可元 | SMART Gateway の送信元 CIDR のみ。`/16` より広い範囲と `0.0.0.0/0` を変数検証で拒否 | 公開範囲の最小化 |
| AMI | `aws_ami` データソースで Amazon 所有の最新版を検索。`ignore_changes = [ami]` | 仕様 (ID 固定しない)。週の途中で新 AMI が出ても作業中の EC2 を再作成しない |
| キーペア | RSA。公開鍵を Terraform へ渡す方式を推奨 | パスワード復号に RSA が必要。秘密鍵を AWS・State に置かない |
| 初期化 | user data で PowerShell スクリプトを 1 回実行 | 手作業を減らす。失敗時は手動再実行できる (冪等) |
| インストーラー検証 | 固定バージョン + SHA256 + Authenticode | 改ざん・取り違え防止 |
| SSM | インスタンスロールに `AmazonSSMManagedInstanceCore` | RDP できない時の調査 (Fleet Manager、Run Command) |
| アウトバウンド | 443 と 80 | 80 は証明書失効確認 (CRL / OCSP) |
| スクリプトの文字 | PowerShell スクリプトは ASCII のみ | Windows PowerShell 5.1 は BOM なし UTF-8 を ANSI として読むため |

## 6. 採用コンポーネント

| コンポーネント | 内容 |
| --- | --- |
| EC2 | Windows Server 2022 Japanese Full Base、`t3.medium`、gp2 50 GB (暗号化) |
| Security Group | RDP 3389 ← SMART Gateway CIDR、443 / 80 → any |
| キーペア | RSA (公開鍵のみ AWS へ登録) |
| IAM ロール | SSM Core + 退避用 S3 プレフィックス (Boundary 適用) |
| ツール | VS Code 1.139.1、Git 2.56.0、Node.js 24.21.0、Python 3.13.15、AWS CLI 2.37.5、Claude Code 2.1.284、Snowflake CLI 3.28.0 |

## 7. 不採用コンポーネントと切替条件

| 不採用 | 理由 | 切替条件 |
| --- | --- | --- |
| Docker Desktop | 仕様で不採用。Windows Server での利用はライセンス・サポート面の制約が大きい | なし (Pattern 02 を使う) |
| Fleet Manager のリモートデスクトップ | SMART Gateway 経由の RDP が標準 | SMART Gateway が使えない場合の一時的な代替 (Fleet Manager が利用可能なら) |
| Elastic IP | 停止・起動で IP が変わるが、週次で作り直すため固定の価値が低い | SMART Gateway 側で接続先の事前登録が必要になった場合 |
| winget / Chocolatey | Windows Server 2022 に winget が標準搭載されていない。外部リポジトリへの依存が増える | 社内で承認されたパッケージ管理が提供された場合 |
| t3.small 以下 | VS Code + ブラウザー + Claude Code でメモリ不足になりやすい | コスト優先で軽い作業だけを行う場合 |

## 8. 制約、代替策、残存リスク

| 項目 | 内容 |
| --- | --- |
| RDP をインターネットへ開けている | 許可元は SMART Gateway の CIDR のみ。Administrator のパスワードは AWS 生成の強固なもの |
| Public IP が停止・起動で変わる | 接続前に毎回コンソールで確認 |
| Claude Code の Windows Server 上での動作 | Git for Windows の bash を利用する設定を入れている。未検証環境のため、不具合時は Linux EC2 (Pattern 02) で使う |
| user data の実行時間 | 15〜30 分。完了前に RDP するとツールが揃っていない |
| AWS CLI MSI の SHA256 | 公式公開値がないため、取得時に Authenticode (Amazon) を確認して算出した値を固定している |

## 9. Mermaid 構成図

```mermaid
flowchart LR
  PC["社内 PC"] --> SGW["SMART Gateway"]
  SGW -- "RDP 3389" --> WIN
  subgraph Pub["Public Subnet"]
    WIN["Windows 開発用 EC2<br/>t3.medium / gp2 50GB<br/>SG: 3389 ← SGW CIDR"]
  end
  ROLE["IAM ロール<br/>SSM Core + transfer/"] -.-> WIN
  WIN -- "HTTPS" --> GH["GitHub"]
  WIN -- "HTTPS" --> SF["Snowflake"]
  WIN -- "HTTPS" --> DL["配布元<br/>VS Code / Git / Node / Python / npm / PyPI"]
  WIN -- "HTTPS" --> S3["S3 transfer/"]
  WIN -. "任意 8080" .-> LNX["Linux Docker EC2"]
```

## 10. 通信フロー

| # | 送信元 | 宛先 | ポート | 用途 |
| --- | --- | --- | --- | --- |
| 1 | SMART Gateway | Windows EC2 (Public IPv4) | TCP 3389 | RDP |
| 2 | Windows EC2 | 配布元、npm、PyPI | 443 | 初期化 |
| 3 | Windows EC2 | 各種 CRL / OCSP | 80 | 署名検証 |
| 4 | Windows EC2 | GitHub | 443 | clone / push |
| 5 | Windows EC2 | Snowflake | 443 | Snowflake CLI |
| 6 | Windows EC2 (SSM Agent) | SSM VPC Endpoint | 443 | 調査用 |
| 7 | Windows EC2 | Linux EC2 private IP | 8080 | アプリ確認 (Pattern 02 で許可した場合) |

## 11. データフロー

| データ | 保存場所 | 退避先 | 寿命 |
| --- | --- | --- | --- |
| ソースコード (Public 可) | `C:\Users\Administrator\work\` | 個人 Public GitHub | 週末まで |
| 非公開のメモ・成果物 | 同上 | S3 `transfer/` → 社内 PC ローカル Git | 週末まで |
| Administrator パスワード | 利用者の手元 (リポジトリ外) | なし (毎週変わる) | 週末まで |
| GitHub 認証 | Windows 資格情報マネージャー (GCM) | なし | 週末まで |
| Claude Code 認証 | ユーザープロファイル | なし | 週末まで |

## 12. 作成する AWS リソース

| リソース | 名前 | 定義 |
| --- | --- | --- |
| IAM ロール / インスタンスプロファイル | `<owner>-windev-role-01` | [ssm-instance-role](../../08_iac/modules/ssm-instance-role/main.tf) |
| IAM ポリシーアタッチ / インラインポリシー | SSM Core / `transfer-prefix-access` | 同上 |
| キーペア (方式 A のみ) | `<owner>-windev-key-01` | [windows-dev-ec2](../../08_iac/modules/windows-dev-ec2/main.tf) |
| Security Group + ルール | `<owner>-windev-ec2-01-sg` | 同上 |
| EC2 + ルート EBS | `<owner>-windev-ec2-01` | 同上 |

## 13. パラメーター

[terraform.tfvars.example](terraform/terraform.tfvars.example) を `terraform.tfvars` にコピーして記入する (Git 管理外)。

| 変数 | 必須 | 既定 | 説明 |
| --- | --- | --- | --- |
| `aws_account_id` | 必須 | - | `<AWS_ACCOUNT_ID>` |
| `owner` / `purpose` / `sequence` | owner のみ必須 | `windev` / `01` | 命名 |
| `expires_at` | 必須 | - | 直近の日曜日 |
| `vpc_id` / `public_subnet_id` | 必須 | - | `<VPC_ID>` / `<PUBLIC_SUBNET_ID>` |
| `permissions_boundary_arn` | 必須 | - | `<PERMISSIONS_BOUNDARY_ARN>` |
| `rdp_allowed_cidrs` | 必須 | - | `["<RDP_ALLOWED_CIDR>"]` |
| `instance_type` | - | `t3.medium` | クォータ内の値のみ |
| `root_volume_size_gb` | - | `50` | 30〜100 |
| `key_pair_public_key` / `key_pair_name` | どちらか | `null` | §19-A |
| `transfer_bucket_name` | - | `null` | 退避用。通常は `<BOOTSTRAP_BUCKET_NAME>` |
| `run_init_script_on_boot` | - | `true` | 初期化スクリプトの自動実行 |

## 14. 命名とタグ

共通規則に従う ([命名とタグ](../../02_common-design/naming-and-tagging.md))。`Purpose = windev`。タグは Provider の `default_tags` と Module の `Name` で自動付与される。

## 15. IAM 設計

- インスタンスロール: `AmazonSSMManagedInstanceCore` + `s3://<BOOTSTRAP_BUCKET_NAME>/transfer/<owner>-windev/` の読み書きのみ。
- Runner 側で必要な権限は [runner-workload-policy.json](../00_terraform-bootstrap/iam/runner-workload-policy.json) (キーペアの Import / Delete を含む)。

## 16. Permissions Boundary

`permissions_boundary_arn` を Module が `aws_iam_role.permissions_boundary` へ必ず設定する (変数は必須、形式を検証)。`terraform plan` で `permissions_boundary = "<PERMISSIONS_BOUNDARY_ARN>"` を確認する。

## 17. Security Group 設計

| 方向 | プロトコル | ポート | 相手 | 説明 |
| --- | --- | --- | --- | --- |
| インバウンド | TCP | 3389 | `<RDP_ALLOWED_CIDR>` (CIDR ごとに 1 ルール) | RDP |
| アウトバウンド | TCP | 443 | `0.0.0.0/0` | HTTPS |
| アウトバウンド | TCP | 80 | `0.0.0.0/0` | CRL / OCSP (`allow_http_egress = false` で削除可) |

## 18. Terraform 構成

| ファイル | 内容 |
| --- | --- |
| [terraform/versions.tf](terraform/versions.tf) | Terraform 1.16.4 / AWS Provider 6.66.0 |
| [terraform/backend.tf](terraform/backend.tf) | `state/01_windows-dev-ec2/terraform.tfstate` |
| [terraform/providers.tf](terraform/providers.tf) | `allowed_account_ids`、`default_tags` |
| [terraform/main.tf](terraform/main.tf) | Module 呼び出し、user data の組み立て |
| [terraform/tests/plan.tftest.hcl](terraform/tests/plan.tftest.hcl) | モック Provider のテスト |

Runner での実行:

```bash
cd ~/iac/current/04_patterns/01_windows-dev-ec2/terraform
terraform init -input=false -backend-config=../../../08_iac/bootstrap/backend.hcl
terraform validate
terraform plan -out=run.tfplan
# Plan を確認 (§2 の成功条件、Terraform と State §4 の観点)
terraform apply run.tfplan
rm -f run.tfplan
terraform output
```

## 19. 手動例外手順

### A. RSA キーの用意

**方式 A (推奨): 公開鍵を Terraform へ渡す。** 秘密鍵は社内 PC のリポジトリ外にだけ置く。

```powershell
# 社内 PC (Windows 標準の OpenSSH クライアント)。出力先はリポジトリの外にする
New-Item -ItemType Directory -Force "$HOME\.ssh\sandbox" | Out-Null
ssh-keygen -t rsa -b 4096 -m PEM -C "<OWNER>-windev" -f "$HOME\.ssh\sandbox\<OWNER>-windev-key.pem"
# パスフレーズを 2 回聞かれたら、何も入力せず Enter を 2 回押す (EC2 のパスワード復号はパスフレーズ付きの鍵を扱えない)
Get-Content "$HOME\.ssh\sandbox\<OWNER>-windev-key.pem.pub"
```

表示された `ssh-rsa ...` の 1 行を `terraform.tfvars` の `key_pair_public_key` に記入する。毎週同じ鍵を使ってよい。

- `-m PEM` は必須 (EC2 コンソールのパスワード復号は PEM 形式の RSA 秘密鍵を要求する)。
- 秘密鍵ファイルを Box の共有フォルダー、リポジトリ、S3 に置かない。

**方式 B: コンソールでキーペアを作成する** (社内 PC で `ssh-keygen` を使えない場合)。

| 設定 | 値 |
| --- | --- |
| 場所 | EC2 → キーペア →「キーペアを作成」 |
| 名前 | `<owner>-windev-key-01` |
| キーペアのタイプ | **RSA** |
| プライベートキーファイル形式 | **.pem** |
| タグ | 共通 6 項目 (`ManagedBy = manual-bootstrap`) |

ダウンロードされた `.pem` をリポジトリ外へ移動し、`terraform.tfvars` で `key_pair_public_key = null`、`key_pair_name = "<owner>-windev-key-01"` とする。週末前にコンソールで削除する。

### B. Administrator パスワードの取得

`terraform apply` 後、**4 分以上** 待ってから行う (パスワード生成に時間がかかる)。

1. EC2 → `<owner>-windev-ec2-01` →「接続」→「RDP クライアント」タブ。
2. 「パスワードを取得」→「プライベートキーファイルをアップロード」で §A の秘密鍵を選択 →「パスワードを復号化」。
   - 復号はブラウザー内で行われ、秘密鍵はアップロード先に保存されない。
3. 表示された値を確認する。

   | 項目 | 値 |
   | --- | --- |
   | ユーザー名 | `Administrator` |
   | パブリック IP | 毎回コンソールで確認 |
   | パスワード | リポジトリ外 (パスワードマネージャー等) に一時保管。画面を撮影しない |

### C. SMART Gateway 経由の RDP 接続

SMART Gateway の利用手順は社内資料 (`<INTERNAL_SMART_GATEWAY_GUIDE>`、[参照管理](../../99_references/README.md)) に従う。接続先として次を指定する。

| 項目 | 値 |
| --- | --- |
| 接続先 | §B で確認した Public IPv4 (ポート 3389) |
| ユーザー名 | `Administrator` |
| 画面の解像度 | 任意 |
| ドライブ / クリップボードのリダイレクト | 社内ルールに従う。秘密鍵・社内ファイルを持ち込まない |

## 20. OS とミドルウェア初期設定

[Initialize-WindowsDev.ps1](scripts/Initialize-WindowsDev.ps1) が初回起動時に SYSTEM で実行される (user data、1 回のみ)。

| 処理 | 内容 |
| --- | --- |
| タイムゾーン | Tokyo Standard Time |
| 到達性 | 配布元への 443 をログに記録 |
| インストール | Git → VS Code → Node.js → Python → AWS CLI (SHA256 + Authenticode) |
| Git | `credential.helper manager`、`init.defaultBranch main`、`core.autocrlf true` |
| Claude Code | `C:\DevTools\npm-global` へ固定版。`DISABLE_AUTOUPDATER=1`、`CLAUDE_CODE_GIT_BASH_PATH` |
| Snowflake | `C:\DevTools\venvs\snowflake` に Connector と CLI |
| 結果 | `C:\ProgramData\DevBootstrap\status.txt` / `versions.txt` / `init.log` |

手動で再実行する場合 (RDP 接続後、管理者 PowerShell):

```powershell
Get-Content C:\ProgramData\DevBootstrap\status.txt
# スクリプトを C:\Temp へ置いてから (GitHub から取得、またはクリップボード経由で貼り付け)
powershell -NoProfile -ExecutionPolicy Bypass -File C:\Temp\Initialize-WindowsDev.ps1
```

## 21. Docker 構成

対象外。Docker は [Pattern 02](../02_linux-docker-dev/README.md) の Linux EC2 で実行する。

## 22. アプリケーション配置

```powershell
# 新しい PowerShell ウィンドウ (PATH の更新を読み込むため)
git config --global user.name "<GIT_USER_NAME>"
git config --global user.email "<GIT_USER_EMAIL>"
New-Item -ItemType Directory -Force $HOME\work | Out-Null
cd $HOME\work
git clone https://github.com/<GITHUB_USER>/<GITHUB_REPO>.git
cd <GITHUB_REPO>
code .
```

- 初回の `git push` で Git Credential Manager がブラウザーを開き、GitHub へのサインインを求める。
- Claude Code の初回認証は [Claude Code](../../05_components/claude-code.md) を参照。
- Snowflake CLI の接続設定は [Snowflake 接続](../../05_components/snowflake-connection.md) を参照。
- `<GIT_USER_NAME>` / `<GIT_USER_EMAIL>` は Public GitHub に公開される。GitHub の `noreply` アドレスの利用を推奨。

## 23. 正常系確認

1. `terraform output` で `ami_name` が `Windows_Server-2022-Japanese-Full-Base-...` であること。
2. EC2 のステータスチェックが合格し、§19-B / C で RDP 接続できること。
3. 初期化の完了を待つ (`status.txt` が `success`)。
4. 新しい PowerShell ウィンドウで確認スクリプトを実行する。

```powershell
Get-Content C:\ProgramData\DevBootstrap\status.txt
Get-Content C:\ProgramData\DevBootstrap\versions.txt
cd $HOME\work\<GITHUB_REPO>
powershell -NoProfile -ExecutionPolicy Bypass -File .\04_patterns\01_windows-dev-ec2\scripts\Test-WindowsDev.ps1 -GitHubRepoUrl https://github.com/<GITHUB_USER>/<GITHUB_REPO>.git
```

期待値: すべての行が `PASS`、終了コード 0。

## 24. 異常系確認

| 確認 | 手順 | 期待値 |
| --- | --- | --- |
| RDP 許可元の検証 | `rdp_allowed_cidrs = ["0.0.0.0/0"]` で `terraform plan` | 変数検証エラーで停止 |
| 許可外インスタンスタイプ | `instance_type = "m5.large"` で `terraform plan` | 変数検証エラー |
| 誤った秘密鍵 | 別の鍵でパスワード復号 | コンソールが復号エラーを表示 |
| 初期化の失敗 | `init.log` の `ERROR:` 行 | `status.txt` が `failed`。原因解消後に手動再実行 |

## 25. ログと監視

| ログ | 場所 |
| --- | --- |
| 初期化スクリプト | `C:\ProgramData\DevBootstrap\init.log` |
| EC2Launch v2 | `C:\ProgramData\Amazon\EC2Launch\log\agent.log` |
| 起動時の画面・コンソール出力 | EC2 →「アクション」→「モニタリングとトラブルシューティング」→「インスタンスのスクリーンショットを取得」/「システムログを取得」 (画面にパスワードは表示されないが、保存しない) |

## 26. 停止手順

1. 作業内容を保存・push する。
2. EC2 → `<owner>-windev-ec2-01` →「インスタンスの状態」→「インスタンスを停止」。
3. 次回起動後は Public IPv4 が変わる。パスワードは変わらない。

## 27. 個別削除

| 目的 | 方法 |
| --- | --- |
| EC2 だけを作り直す (環境が壊れた場合) | `terraform plan -replace=module.windows.aws_instance.this -out=run.tfplan` → 確認 → `terraform apply run.tfplan` |
| 最新 AMI へ更新する | 同上 (`ignore_changes` のため通常の apply では更新されない) |

> [!WARNING]
> EC2 の再作成で C ドライブの内容はすべて失われる。先に §29 の退避を行う。

`-target` による部分削除は State と実体の不整合を招きやすいため使わない。

## 28. 全体削除

> [!CAUTION]
> Windows 開発用 EC2 (C ドライブを含む)、キーペア、SG、IAM ロール を完全に削除する。復元できない。先に §29 の退避を行う。

```bash
cd ~/iac/current/04_patterns/01_windows-dev-ec2/terraform
terraform plan -destroy -out=destroy.tfplan
terraform apply destroy.tfplan
rm -f destroy.tfplan
terraform state list   # 空であること
```

方式 B のキーペアはコンソールで削除する。Pattern 02 が Windows の SG を参照している場合は、先に Pattern 02 を destroy する。

## 29. 週末前の退避

1. Public 可のコードを push する。

   ```powershell
   cd $HOME\work\<GITHUB_REPO>
   git status --short
   git add -A; git commit -m "<COMMIT_MESSAGE>"; git push
   ```

2. 非公開のファイルを S3 経由で社内 PC へ移す ([S3 による搬送](../../05_components/s3-transfer.md))。

   ```powershell
   aws s3 cp C:\Users\Administrator\work\private-notes.zip s3://<BOOTSTRAP_BUCKET_NAME>/transfer/<OWNER>-windev/
   ```

3. `.env`、秘密鍵、パスワードは退避しない (退避先を作らない)。

## 30. 週末後の再構築

1. 社内 PC で `terraform.tfvars` の `expires_at` を更新し、IaC ZIP を再作成・アップロード (Runner 側で `iac-fetch`)。
2. §18 の `init` → `plan` → `apply`。
3. 4 分以上待ってから §19-B でパスワード取得 → §19-C で RDP。
4. `status.txt` が `success` になるまで待つ (15〜30 分)。
5. §22 の clone → §23 の確認 → Claude Code / GitHub / Snowflake の再認証。

## 31. トラブルシューティング

| 症状 | 参照 |
| --- | --- |
| RDP で接続できない | [06 RDP](../../06_troubleshooting/README.md#rdp-で接続できない) |
| パスワードを取得できない | [06 Windows パスワード](../../06_troubleshooting/README.md#windows-のパスワードを取得できない) |
| 初期化が終わらない / 失敗する | [06 Windows 初期化](../../06_troubleshooting/README.md#windows-の初期化スクリプトが失敗した) |
| `claude` が見つからない | 新しい PowerShell ウィンドウを開く (PATH の再読み込み) |

## 32. コスト

| 課金要素 | 備考 |
| --- | --- |
| EC2 `t3.medium` (Windows ライセンス込み) | 起動中のみ。Linux より高い |
| EBS 50 GB gp2 | 停止中も課金 |
| Public IPv4 | 0.005 USD/時 (関連付け中) |

単価は AWS 料金ページで確認し、確認日を記録する。使わない日は停止する。

## 33. 未確定事項

U-05 (SMART Gateway CIDR)、U-10 (RSA キー方式)、Q-07 (Claude Code 認証場所)、`<INTERNAL_SMART_GATEWAY_GUIDE>`。

## 34. 更新履歴

| 日付 | 内容 |
| --- | --- |
| 2026-09-29 | 初版 |
