#Requires -Version 5.1
<#
.SYNOPSIS
  Initialize a Windows Server 2022 development EC2 instance.
  Installs VS Code, Git, Node.js, Python, AWS CLI, Claude Code and Snowflake CLI.

.DESCRIPTION
  - Runs as EC2 user data (SYSTEM, first boot only) or manually from an elevated PowerShell.
  - Every installer is a pinned version and is verified by SHA256 and Authenticode before execution.
  - Idempotent: already installed components are skipped.
  - Never put secrets in this file.
  - Docker Desktop is intentionally NOT installed (Docker runs on the Linux dev host).
  - This file is ASCII only on purpose: Windows PowerShell 5.1 reads BOM-less files
    with the system ANSI code page, which breaks non-ASCII string literals.

.NOTES
  Log    : C:\ProgramData\DevBootstrap\init.log
  Status : C:\ProgramData\DevBootstrap\status.txt (running / success / failed)
  Manual : powershell -NoProfile -ExecutionPolicy Bypass -File .\Initialize-WindowsDev.ps1
#>
[CmdletBinding()]
param(
  [string]$ToolsRoot = 'C:\DevTools',
  [switch]$SkipSnowflakeCli
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$StateDir = 'C:\ProgramData\DevBootstrap'
New-Item -ItemType Directory -Force -Path $StateDir, $ToolsRoot | Out-Null
Start-Transcript -Path (Join-Path $StateDir 'init.log') -Append | Out-Null
Set-Content -Path (Join-Path $StateDir 'status.txt') -Value 'running'

# ---- Pinned versions and SHA256 (update procedure: 02_common-design/version-pinning.md) ----
$Installers = @(
  @{ Name = 'Git'; Check = 'C:\Program Files\Git\cmd\git.exe'
     Url = 'https://github.com/git-for-windows/git/releases/download/v2.56.0.windows.1/Git-2.56.0-64-bit.exe'
     Sha256 = 'bfe94e7b419b16eee9fecbd1253a98e3d4f49ba8f029630549052278ffe286a6'
     Args = @('/VERYSILENT', '/NORESTART', '/NOCANCEL', '/SP-', '/SUPPRESSMSGBOXES') },
  @{ Name = 'VSCode'; Check = 'C:\Program Files\Microsoft VS Code\Code.exe'
     Url = 'https://update.code.visualstudio.com/1.139.1/win32-x64/stable'
     Sha256 = '1547b6d1d5b5f3e51b684dd30a209ac7ddf43e6ae420441fba28bea1cbca41ed'
     Args = @('/VERYSILENT', '/NORESTART', '/MERGETASKS=!runcode,addtopath') },
  @{ Name = 'NodeJS'; Check = 'C:\Program Files\nodejs\node.exe'; Msi = $true
     Url = 'https://nodejs.org/dist/v24.21.0/node-v24.21.0-x64.msi'
     Sha256 = 'bb0eaee134f9357f22aea915ee793343e627aefc1e66488164bac6915bce2cac' },
  @{ Name = 'Python'; Check = 'C:\Program Files\Python313\python.exe'
     Url = 'https://www.python.org/ftp/python/3.13.15/python-3.13.15-amd64.exe'
     Sha256 = 'edec09c4853aeae9ac36efb8c9f95b6b8e2fee65eee56d9767a8b7c69c574403'
     Args = @('/quiet', 'InstallAllUsers=1', 'PrependPath=1', 'Include_test=0', 'Include_launcher=1') },
  @{ Name = 'AwsCli'; Check = 'C:\Program Files\Amazon\AWSCLIV2\aws.exe'; Msi = $true
     Url = 'https://awscli.amazonaws.com/AWSCLIV2-2.37.5.msi'
     Sha256 = '20c3764b3d67462a219cf31505195e5e38bbf87f7ec6ae48b67aed6b78e57e51' }
)
$ClaudeCodeVersion = '2.1.284'
$SnowflakeConnectorVersion = '4.7.5'
$SnowflakeCliVersion = '3.28.0'

function Write-Step([string]$Message) {
  Write-Output ('{0} [init] {1}' -f (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'), $Message)
}

function Update-SessionPath {
  $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' +
              [Environment]::GetEnvironmentVariable('Path', 'User')
}

function Add-MachinePath([string]$Dir) {
  $current = [Environment]::GetEnvironmentVariable('Path', 'Machine')
  if (($current -split ';') -notcontains $Dir) {
    [Environment]::SetEnvironmentVariable('Path', "$current;$Dir", 'Machine')
  }
  Update-SessionPath
}

function Install-Verified([hashtable]$Item) {
  if (Test-Path $Item.Check) {
    Write-Step "$($Item.Name): already installed, skipped"
    return
  }
  $ext = if ($Item.Msi) { '.msi' } else { '.exe' }
  $file = Join-Path $env:TEMP ('dev-init-{0}{1}' -f $Item.Name, $ext)
  Write-Step "$($Item.Name): downloading"
  Invoke-WebRequest -Uri $Item.Url -OutFile $file -UseBasicParsing -TimeoutSec 600

  $actual = (Get-FileHash -Path $file -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actual -ne $Item.Sha256) {
    Remove-Item $file -Force
    throw "$($Item.Name): SHA256 mismatch expected=$($Item.Sha256) actual=$actual"
  }
  $sig = Get-AuthenticodeSignature -FilePath $file
  if ($sig.Status -ne 'Valid') {
    Remove-Item $file -Force
    throw "$($Item.Name): invalid Authenticode signature ($($sig.Status))"
  }
  Write-Step "$($Item.Name): verified (signer: $($sig.SignerCertificate.Subject))"

  if ($Item.Msi) {
    $p = Start-Process -FilePath 'msiexec.exe' -ArgumentList @('/i', "`"$file`"", '/qn', '/norestart') -Wait -PassThru
  } else {
    $p = Start-Process -FilePath $file -ArgumentList $Item.Args -Wait -PassThru
  }
  Remove-Item $file -Force
  if ($p.ExitCode -notin 0, 3010) {
    throw "$($Item.Name): installer exit code $($p.ExitCode)"
  }
  Write-Step "$($Item.Name): installed"
}

try {
  Write-Step 'start'

  # ---- 1. OS settings ----
  Set-TimeZone -Id 'Tokyo Standard Time'

  # ---- 2. Outbound HTTPS reachability (logged only, does not stop the script) ----
  foreach ($h in 'github.com', 'update.code.visualstudio.com', 'nodejs.org', 'www.python.org', 'registry.npmjs.org', 'pypi.org') {
    $ok = Test-NetConnection -ComputerName $h -Port 443 -InformationLevel Quiet -WarningAction SilentlyContinue
    Write-Step "reach ${h}:443 -> $ok"
  }

  # ---- 3. Installers (SHA256 + Authenticode) ----
  foreach ($item in $Installers) { Install-Verified $item }
  Update-SessionPath

  # ---- 4. Git system settings (credentials are stored by Git Credential Manager in Windows Credential Manager) ----
  $git = 'C:\Program Files\Git\cmd\git.exe'
  & $git config --system credential.helper manager
  & $git config --system init.defaultBranch main
  & $git config --system core.autocrlf true

  # ---- 5. Claude Code (pinned, shared prefix, auto update disabled) ----
  $npmPrefix = Join-Path $ToolsRoot 'npm-global'
  New-Item -ItemType Directory -Force -Path $npmPrefix | Out-Null
  if (-not (Test-Path (Join-Path $npmPrefix 'claude.cmd'))) {
    Write-Step "installing Claude Code $ClaudeCodeVersion"
    & 'C:\Program Files\nodejs\npm.cmd' install -g --prefix $npmPrefix --no-fund --no-audit "@anthropic-ai/claude-code@$ClaudeCodeVersion"
    if ($LASTEXITCODE -ne 0) { throw "npm install failed ($LASTEXITCODE)" }
  }
  Add-MachinePath $npmPrefix
  [Environment]::SetEnvironmentVariable('DISABLE_AUTOUPDATER', '1', 'Machine')
  [Environment]::SetEnvironmentVariable('CLAUDE_CODE_GIT_BASH_PATH', 'C:\Program Files\Git\bin\bash.exe', 'Machine')

  # ---- 6. Snowflake client (dedicated venv) ----
  if (-not $SkipSnowflakeCli) {
    $venv = Join-Path $ToolsRoot 'venvs\snowflake'
    if (-not (Test-Path (Join-Path $venv 'Scripts\snow.exe'))) {
      Write-Step "installing Snowflake Connector $SnowflakeConnectorVersion / CLI $SnowflakeCliVersion"
      & 'C:\Program Files\Python313\python.exe' -m venv $venv
      & (Join-Path $venv 'Scripts\python.exe') -m pip install --quiet --disable-pip-version-check `
        "snowflake-connector-python==$SnowflakeConnectorVersion" "snowflake-cli==$SnowflakeCliVersion"
      if ($LASTEXITCODE -ne 0) { throw "pip install failed ($LASTEXITCODE)" }
    }
    Add-MachinePath (Join-Path $venv 'Scripts')
  }

  # ---- 7. Record result ----
  $versions = [ordered]@{
    git    = (& $git --version)
    node   = (& 'C:\Program Files\nodejs\node.exe' --version)
    python = (& 'C:\Program Files\Python313\python.exe' --version)
    aws    = (& 'C:\Program Files\Amazon\AWSCLIV2\aws.exe' --version)
  }
  $versions.GetEnumerator() | ForEach-Object { '{0}={1}' -f $_.Key, $_.Value } |
    Set-Content -Path (Join-Path $StateDir 'versions.txt')
  Set-Content -Path (Join-Path $StateDir 'status.txt') -Value 'success'
  Write-Step 'done'
}
catch {
  Set-Content -Path (Join-Path $StateDir 'status.txt') -Value 'failed'
  Write-Step "ERROR: $($_.Exception.Message)"
  throw
}
finally {
  Stop-Transcript | Out-Null
}
