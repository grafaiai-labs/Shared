#Requires -Version 5.1
<#
.SYNOPSIS
  Verify the Windows development EC2 after Initialize-WindowsDev.ps1.

.DESCRIPTION
  Prints PASS / FAIL for each check and exits with code 1 if any check fails.
  Run from a NEW PowerShell window (so that the updated PATH is loaded).
  The output contains no secrets, but do not paste IP addresses or account names into public places.

.EXAMPLE
  powershell -NoProfile -ExecutionPolicy Bypass -File .\Test-WindowsDev.ps1
  powershell -NoProfile -ExecutionPolicy Bypass -File .\Test-WindowsDev.ps1 -GitHubRepoUrl https://github.com/<GITHUB_USER>/<GITHUB_REPO>.git
#>
[CmdletBinding()]
param(
  [string]$GitHubRepoUrl
)

$ErrorActionPreference = 'Continue'
$results = New-Object System.Collections.Generic.List[object]

function Add-Result([string]$Name, [bool]$Ok, [string]$Detail) {
  $results.Add([pscustomobject]@{ Check = $Name; Result = $(if ($Ok) { 'PASS' } else { 'FAIL' }); Detail = $Detail })
}

function Test-Command([string]$Name, [string]$Exe, [string[]]$VersionArgs) {
  $cmd = Get-Command $Exe -ErrorAction SilentlyContinue
  if (-not $cmd) { Add-Result $Name $false 'not found in PATH'; return }
  $out = (& $cmd.Source @VersionArgs 2>&1 | Select-Object -First 1) -as [string]
  Add-Result $Name ($LASTEXITCODE -eq 0) $out.Trim()
}

$status = Get-Content 'C:\ProgramData\DevBootstrap\status.txt' -ErrorAction SilentlyContinue
Add-Result 'init script status' ($status -eq 'success') "status=$status"

Test-Command 'git' 'git' @('--version')
Test-Command 'VS Code' 'code' @('--version')
Test-Command 'node' 'node' @('--version')
Test-Command 'npm' 'npm' @('--version')
Test-Command 'python' 'python' @('--version')
Test-Command 'aws cli' 'aws' @('--version')
Test-Command 'claude code' 'claude' @('--version')
Test-Command 'snowflake cli' 'snow' @('--version')

Add-Result 'DISABLE_AUTOUPDATER' ([Environment]::GetEnvironmentVariable('DISABLE_AUTOUPDATER', 'Machine') -eq '1') 'machine env'
Add-Result 'git credential helper' ((git config --system credential.helper) -eq 'manager') 'system config'

$dockerDesktop = Test-Path 'C:\Program Files\Docker\Docker\Docker Desktop.exe'
Add-Result 'Docker Desktop not installed' (-not $dockerDesktop) 'policy: Docker runs on Linux host only'

foreach ($h in 'github.com', 'api.github.com') {
  $ok = Test-NetConnection -ComputerName $h -Port 443 -InformationLevel Quiet -WarningAction SilentlyContinue
  Add-Result "reach ${h}:443" $ok ''
}

$imdsToken = $null
try {
  $imdsToken = Invoke-RestMethod -Method Put -Uri 'http://169.254.169.254/latest/api/token' `
    -Headers @{ 'X-aws-ec2-metadata-token-ttl-seconds' = '60' } -TimeoutSec 3
} catch { }
Add-Result 'IMDSv2 token' ($null -ne $imdsToken) 'IMDSv2 required'

if ($GitHubRepoUrl) {
  if ($GitHubRepoUrl -notmatch '^https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+(\.git)?$') {
    Add-Result 'github ls-remote' $false 'GitHubRepoUrl must be https://github.com/<user>/<repo>(.git)'
  } else {
    $null = git ls-remote --heads $GitHubRepoUrl 2>&1
    Add-Result 'github ls-remote' ($LASTEXITCODE -eq 0) $GitHubRepoUrl
  }
}

$results | Format-Table -AutoSize | Out-String -Width 200 | Write-Output
if ($results.Result -contains 'FAIL') { exit 1 }
exit 0
