# Pattern 05: Web 公開構成の基本パターン

アプリケーションを Private Subnet に置き、ALB または API Gateway だけを公開する構成の設計パターン。TLS、アクセスログ、必要時の WAF、公開範囲の最小化を扱う。

> [!IMPORTANT]
> **このパターンは設計のみで、Terraform は未実装。** 理由・影響・確認方法・差し替え箇所は §18 を参照。

## 1. 用途

- Pattern 03 のようなアプリを、ブラウザーから HTTPS でアクセスできる形で検証する。
- ALB / API Gateway / WAF / TLS 自体の挙動を試験する。

## 2. 成功条件

- [ ] 公開されるのは ALB (または API Gateway) の HTTPS 443 だけで、アプリケーションには直接到達できない
- [ ] HTTP 80 は HTTPS へリダイレクトされる (または開けない)
- [ ] 許可した送信元以外からは接続できない (公開範囲の最小化)
- [ ] アクセスログが出力され、相関 ID (`X-Request-ID` / `X-Amzn-Trace-Id`) でアプリのログと突き合わせられる
- [ ] WAF を採用した場合、テスト用の不正リクエストがブロックされる
- [ ] 週末前に全リソースを destroy できる

## 3. 非スコープ

- 独自ドメインの取得・DNS 運用 (既存ドメインがある場合のみ対象)
- CDN によるキャッシュ最適化
- 本番レベルの可用性 (Multi-AZ のアプリ冗長化、Auto Scaling)
- 利用者認証 (Cognito、OIDC)

## 4. 前提条件

以下が確認できるまで構築しない (すべて [未確定事項](../../01_constraints/unconfirmed-items.md))。

| 前提 | 未確定事項 |
| --- | --- |
| ALB / API Gateway / WAF / ACM がサンドボックスで利用可能 | Q-03、Q-09 |
| Private Subnet が 1 つ以上、ALB 用 Public Subnet が **異なる AZ に 2 つ以上** | U-03、U-04 |
| Private Subnet のアプリが外向き通信できる (NAT / Proxy / VPC Endpoint)、または外向き不要なアプリにできる | Q-04 |
| HTTPS 用の証明書を発行できるドメイン (`<PUBLIC_DOMAIN_NAME>`) と DNS 検証の手段 | Q-09 |
| 公開してよい送信元範囲 (`<ALLOWED_CLIENT_CIDR>`) | 新規 |

## 5. 設計判断

| 判断 | 内容 | 理由 |
| --- | --- | --- |
| 公開点 | ALB (HTTP アプリ全般) を第一候補。API だけなら API Gateway HTTP API | ALB は静的ファイルと API を同時に扱える。API Gateway はサーバーレス / 従量課金に向く |
| アプリの配置 | Private Subnet、SG は ALB の SG からのみ受信 | 直接公開しない |
| TLS | ALB の HTTPS リスナー + ACM 証明書、TLS 1.2 以上のポリシー | 通信の暗号化 |
| 公開範囲 | ALB の SG で `<ALLOWED_CLIENT_CIDR>` のみ許可。`0.0.0.0/0` は試験目的上必要な場合だけ | 露出の最小化 |
| WAF | `0.0.0.0/0` へ公開する場合は必須。範囲を限定する場合は任意 | 不特定からのアクセスに対する防御 |
| アクセスログ | ALB → S3 (Bootstrap とは別のログ用バケット)、API Gateway → CloudWatch Logs | 週末に消えるため、必要な分析はその週に行う |

## 6. 採用コンポーネント (案 1: ALB)

| コンポーネント | 設定 |
| --- | --- |
| ALB (internet-facing) | Public Subnet × 2 AZ、HTTPS 443 (ACM)、HTTP 80 → 443 リダイレクト |
| ALB 用 SG | 443 / 80 ← `<ALLOWED_CLIENT_CIDR>`、アウトバウンドはアプリ SG の 8080 のみ |
| ターゲットグループ | アプリ EC2:8080、ヘルスチェック `/api/healthz` |
| アプリ EC2 | Private Subnet、SG は ALB SG からの 8080 のみ。SSM で管理 |
| ACM 証明書 | `<PUBLIC_DOMAIN_NAME>`、DNS 検証 |
| ログ用 S3 | ALB アクセスログ (SSE-S3、Public Access Block) |
| WAF (条件付き) | AWS マネージドルール (Common Rule Set、Known Bad Inputs) + レートベースルール |

## 7. 不採用コンポーネントと切替条件

| 不採用 (初期) | 理由 | 切替条件 |
| --- | --- | --- |
| API Gateway HTTP API + VPC リンク | 静的ファイル配信を含むアプリには ALB が単純 | API のみを公開し、リクエスト単位課金・スロットリングを試験する場合 |
| CloudFront | キャッシュ最適化は非スコープ | 独自ドメインがなく、`*.cloudfront.net` の HTTPS で公開したい場合 (利用可否の確認が前提) |
| NAT Gateway | 利用者が作成できるか未確認、常時課金 | Private Subnet のアプリに外向き通信が必要で、既存の経路がない場合 (作成可否を管理者へ確認) |
| Multi-AZ のアプリ冗長化 | 可用性は試験対象外 | 可用性・フェイルオーバー自体を試験する場合 |
| WAF (範囲限定時) | 送信元を SG で限定していれば露出が小さい | `0.0.0.0/0` へ公開する、または WAF 自体を試験する場合 |
| アプリを Public Subnet に置く | 直接到達できる経路ができる | 採用しない。Private Subnet の外向き通信が解決するまで本パターンは構築しない |

## 8. 制約、代替策、残存リスク

| 項目 | 内容 |
| --- | --- |
| ALB は 2 AZ の Subnet が必須 | Public Subnet が 1 つしかない場合は ALB を作れない → API Gateway 案、または構築見送り |
| ドメインがないと ACM 証明書を発行できない | HTTP のみで `<ALLOWED_CLIENT_CIDR>` に限定した検証に留める (公開はしない) |
| Private Subnet のアプリのセットアップ | 外向き通信がない場合、イメージ取得・パッケージ導入ができない → Q-04 解決まで保留 |
| 週末削除 | ALB、WAF、ACM、ログも削除される。DNS レコード (外部 DNS の場合) は手動で削除 |
| 公開による攻撃 | 範囲限定、WAF、アプリの入力検証 (Pattern 03 の実装) |

## 9. Mermaid 構成図

```mermaid
flowchart LR
  CL["許可された送信元<br/>&lt;ALLOWED_CLIENT_CIDR&gt;"] -- "HTTPS 443" --> WAF["AWS WAF<br/>(条件付き)"]
  WAF --> ALB
  subgraph VPC["サンドボックス VPC"]
    subgraph PubA["Public Subnet (AZ-a)"]
      ALB["ALB (internet-facing)<br/>ACM 証明書"]
    end
    subgraph PubC["Public Subnet (AZ-c)"]
      ALBc["ALB ノード"]
    end
    subgraph Priv["Private Subnet"]
      APP["アプリ EC2<br/>Docker Compose (Pattern 03)<br/>SG: 8080 ← ALB SG"]
    end
  end
  ALB -- "HTTP 8080" --> APP
  ALB -- "アクセスログ" --> LOG[("S3 ログ用バケット")]
  APP -- "HTTPS 443<br/>(NAT / Proxy / Endpoint)" --> SF["Snowflake"]
```

## 10. 通信フロー

| # | 送信元 | 宛先 | ポート | 備考 |
| --- | --- | --- | --- | --- |
| 1 | クライアント | ALB | 443 (80 はリダイレクト) | SG で送信元を限定。WAF を通過 |
| 2 | ALB | アプリ EC2 | 8080 | SG 参照で ALB からのみ |
| 3 | ALB | ログ用 S3 | - | AWS 内部の配信 |
| 4 | アプリ EC2 | Snowflake 等 | 443 | Private Subnet の外向き経路が必要 |
| 5 | 管理者 | アプリ EC2 | - | SSM Session Manager |

## 11. データフロー

| データ | 保存場所 | 寿命 |
| --- | --- | --- |
| アクセスログ | ログ用 S3 (5 分ごとに gzip) | 週末まで |
| アプリログ | EC2 の Docker ログ | 週末まで |
| 業務データ | Snowflake | Snowflake 側の方針 |

## 12. 作成する AWS リソース (予定)

ALB、リスナー × 2、ターゲットグループ、SG × 2、アプリ EC2 + IAM ロール、ACM 証明書、ログ用 S3 + バケットポリシー、(条件付き) WAF Web ACL + 関連付け。

## 13. パラメーター (予定)

| 名前 | 内容 |
| --- | --- |
| `<PUBLIC_SUBNET_ID_AZ_A>` / `<PUBLIC_SUBNET_ID_AZ_C>` | ALB 用 (2 AZ) |
| `<PRIVATE_SUBNET_ID>` | アプリ用 |
| `<ALLOWED_CLIENT_CIDR>` | 公開範囲 |
| `<PUBLIC_DOMAIN_NAME>` | 証明書・DNS |
| `enable_waf` | `0.0.0.0/0` 公開時は `true` 必須 (変数検証で強制する) |

## 14. 命名とタグ

共通規則。`Purpose = pubweb`。例: `<owner>-pubweb-alb-01`、`<owner>-pubweb-sg-01`。

## 15. IAM 設計

Runner の workload ポリシーに次の追加が必要 (実装時に最小化して追記する):

- `elasticloadbalancing:*` のうち LB / リスナー / ターゲットグループの作成・変更・削除・タグ付け (タグ `Owner` 条件)
- `acm:RequestCertificate`、`acm:DescribeCertificate`、`acm:DeleteCertificate`、`acm:AddTagsToCertificate`
- `wafv2:*` のうち Web ACL の作成・関連付け・削除 (WAF 採用時)
- ログ用 S3 の作成・ポリシー設定 (Bootstrap バケットの Deny と衝突しない別バケット)

アプリ EC2 のロールは Pattern 02 と同じ (SSM Core のみ)。

## 16. Permissions Boundary

アプリ EC2 のロールに適用 (Pattern 02 と同じ Module)。ALB / WAF はロールを作成しない。

## 17. Security Group 設計

| SG | 方向 | ポート | 相手 |
| --- | --- | --- | --- |
| ALB SG | インバウンド | 443、80 | `<ALLOWED_CLIENT_CIDR>` |
| ALB SG | アウトバウンド | 8080 | アプリ SG |
| アプリ SG | インバウンド | 8080 | ALB SG |
| アプリ SG | アウトバウンド | 443 | 外向き経路 (NAT / Proxy / Endpoint) |

## 18. Terraform 構成

**未実装。**

| 観点 | 内容 |
| --- | --- |
| 理由 | ALB / WAF / ACM の利用可否 (Q-03、Q-09)、2 AZ の Public Subnet の有無、Private Subnet の外向き経路 (Q-04)、ドメインの有無がすべて未確定で、どの構成案になるか決まらない |
| 影響 | Web 公開構成の検証を開始できない。他パターンへの影響はない |
| 確認方法 | smoke-test の `subnet_routes` に候補 Subnet を追加して AZ と経路を確認。管理者へサービス利用可否とドメインの有無を確認 |
| 差し替え箇所 | `04_patterns/05_public-web/terraform/` (Root Module を新設。Pattern 02 の構成を複製して開始)、`08_iac/modules/` に `public-alb` Module を追加、Runner の workload ポリシーに §15 の権限を追加、[08_iac/patterns](../../08_iac/patterns/README.md) に State キーと破棄順序を追記 |

## 19. 手動例外手順

外部 DNS を使う場合の ACM の DNS 検証レコード登録、および週末前の DNS レコード削除は手動。

## 20. OS とミドルウェア初期設定

アプリ EC2 は Pattern 02 の初期化スクリプトを使う (Private Subnet の場合は `subnet_mode = "private"`)。

## 21. Docker 構成

Pattern 03 と同じ。ALB からの受信のため `FRONTEND_BIND_ADDRESS=0.0.0.0` とし、SG で ALB 以外を遮断する。

## 22. アプリケーション配置

Pattern 03 §22 と同じ。

## 23. 正常系確認 (予定)

```bash
curl -sS -o /dev/null -w '%{http_code} %{ssl_verify_result}\n' https://<PUBLIC_DOMAIN_NAME>/api/healthz   # 200 0
curl -sS -o /dev/null -w '%{http_code} %{redirect_url}\n' http://<PUBLIC_DOMAIN_NAME>/                   # 301 https://...
```

## 24. 異常系確認 (予定)

| 確認 | 期待値 |
| --- | --- |
| 許可外の送信元から接続 | タイムアウト (SG で遮断) |
| アプリ EC2 の Private IP へ直接 | 到達不可 |
| WAF: `/?q=<script>` 等 | 403 |
| ターゲット停止 | ALB が 503、ターゲットが unhealthy |

## 25. ログと監視

- ALB アクセスログ: `trace_id` (`X-Amzn-Trace-Id`) を含む。アプリ側では `X-Request-ID` を相関 ID として記録しているため、ALB で `X-Request-ID` を付与しない場合は nginx のログに `X-Amzn-Trace-Id` を追加して突き合わせる。
- ターゲットのヘルス: EC2 → ターゲットグループ → ターゲット。
- WAF: サンプリングされたリクエスト (コンソール)。

## 26. 停止手順

ALB は停止できない (存在するだけで課金)。検証しない日は destroy を推奨。アプリ EC2 は停止可能。

## 27. 個別削除

WAF の関連付け解除 → Web ACL 削除 → リスナー → ALB → ターゲットグループ の順 (Terraform では依存関係に従い自動)。

## 28. 全体削除

`terraform destroy`。ログ用 S3 は `force_destroy` を使わず、ログを確認してから空にする。外部 DNS のレコードを手動で削除する。

## 29. 週末前の退避

必要なアクセスログを分析し、結果 (集計値のみ、IP などを除く) を社内 PC へ記録する。

## 30. 週末後の再構築

Pattern 02 → 本パターンの apply → ACM 証明書の発行待ち (DNS 検証) → §23。

## 31. トラブルシューティング

| 症状 | 確認 |
| --- | --- |
| ALB が 502 | ターゲットのヘルスチェック (`/api/healthz`)、アプリ SG の 8080 |
| ALB が 503 | 登録ターゲットが 0 / 全 unhealthy |
| 証明書が「検証保留中」 | DNS 検証レコード |

## 32. コスト

ALB は起動時間 + LCU で常時課金、WAF は Web ACL・ルール・リクエスト数で課金、Public IPv4 は ALB ノードごとに課金される。単価は AWS 料金ページで確認する。**使わない日は destroy する。**

## 33. 未確定事項

Q-03、Q-04、Q-09、U-03、U-04、`<PUBLIC_DOMAIN_NAME>`、`<ALLOWED_CLIENT_CIDR>`、`<PUBLIC_SUBNET_ID_AZ_A>`、`<PUBLIC_SUBNET_ID_AZ_C>`。

## 34. 更新履歴

| 日付 | 内容 |
| --- | --- |
| 2026-09-29 | 初版 (設計のみ) |
