# Pattern 04: 定期 ETL・バッチの基本パターン

外部データを取得 → 検証・変換 → Snowflake へ冪等にロードし、実行結果を構造化ログと実行履歴テーブルで確認できるバッチの最小サンプル。サンドボックスでは Linux Docker 開発用 EC2 (Pattern 02) 上で `docker compose run` と systemd timer により実行する。

## 1. 用途

- 定期バッチの設計要素 (冪等性、再試行、タイムアウト、構造化ログ、実行結果確認) を小さなコードで検証する。
- 将来 AWS マネージドサービス (EventBridge Scheduler + ECS / Lambda) へ移す前の動作確認。

## 2. 成功条件

- [ ] `ETL_DRY_RUN=true` で Snowflake なしに取得・変換まで成功し、終了コード 0
- [ ] Snowflake 設定後、1 回目の実行で `inserted > 0`、同じ入力での 2 回目は `inserted = 0, updated = 0` (冪等)
- [ ] 失敗時に終了コード 1、`ETL_RUN_LOG` に `FAILED` とエラーコードが記録される (Snowflake へ到達できる場合)
- [ ] 一時的な失敗 (HTTP 5xx / 429、接続エラー) が指数バックオフで再試行される
- [ ] ユニットテスト 16 件が成功する

## 3. 非スコープ

- 大量データ (数百万行以上) のロード最適化 (`PUT` + `COPY INTO`、Snowpipe)
- ワークフローエンジン (Airflow、Step Functions)
- 認証が必要な外部 API
- 本番の監視・アラート

## 4. 前提条件

- Pattern 02 の Linux EC2 で `check-devhost.sh` が PASS。
- Snowflake へロードする場合: 対象 DB / スキーマへの `CREATE TABLE`、`INSERT`、`UPDATE`、`MERGE` 権限を持つロール ([Snowflake 接続](../../05_components/snowflake-connection.md))。

## 5. 設計判断

| 要素 | 実装 | 理由 |
| --- | --- | --- |
| 冪等性 | 一時テーブルへステージ → `MERGE` (キー一致かつ値が変わった行だけ更新) | 同じ入力の再実行で結果が変わらない。部分失敗後の再実行が安全 |
| 重複・順序 | 変換で ID ごとに最新 (`occurred_at` 最大) を採用し、ID 順に整列 | 入力順に依存しない決定的な結果 |
| トランザクション | DDL を `BEGIN` 前に実行し、ステージ + MERGE + 実行履歴を 1 トランザクションで `COMMIT` | Snowflake は DDL を暗黙コミットするため |
| 再試行 | HTTP 5xx / 429 / 接続エラーと Snowflake の `OperationalError` だけを、指数バックオフ + ジッターで再試行 | 恒久的なエラー (4xx、検証エラー) を再試行しても成功しない |
| タイムアウト | HTTP (20 秒)、Snowflake ログイン (15 秒)、ステートメント (300 秒)、ジョブ全体 (900 秒、SIGALRM) | ハングしたジョブが次回実行と重ならないように |
| 取得元 | `https://` のみ。応答サイズ上限 10 MB | 平文通信と過大な応答の防止 |
| 不正レコード | 除外して件数を記録。ログにはフィールド名だけを出す | 値に個人情報が含まれる可能性を考慮 |
| 識別子 | テーブル名は `DB.SCHEMA.TABLE` 形式を正規表現で検証 | 識別子はバインドできないため |
| 実行結果 | 最終行に `event = etl_run_completed` の JSON ログ + `ETL_RUN_LOG` テーブル + 終了コード | 機械的に判定できる |

## 6. 採用コンポーネント

| コンポーネント | 内容 |
| --- | --- |
| 実行基盤 | Pattern 02 の Linux EC2、Docker Compose (`docker compose run --rm etl`) |
| スケジューラー | systemd timer ([sample-etl.timer](systemd/sample-etl.timer)) |
| コード | Python 3.13、Pydantic 2.13.5、snowflake-connector-python 4.7.5 ([etl/](etl/etl_job/main.py)) |
| ロード先 | Snowflake (`<SNOWFLAKE_DATABASE>.<SNOWFLAKE_SCHEMA>.ORDERS`、`ETL_RUN_LOG`) |

## 7. 不採用コンポーネントと切替条件

| 不採用 | 理由 | 切替条件 |
| --- | --- | --- |
| EventBridge Scheduler + ECS Fargate | サービスの利用可否が未確認 (Q-03)。1 名・小規模では EC2 上で十分 | 利用可能と確認でき、EC2 を常時起動せずに定期実行したい場合。コンテナイメージはそのまま使える |
| EventBridge Scheduler + Lambda | 同上。Snowflake Connector を含むパッケージが大きい | 実行時間 15 分以内かつコンテナイメージ Lambda が使える場合 |
| Snowflake Tasks + 外部アクセス統合 | Snowflake 側の権限設定が必要。AWS 側の検証にならない | 処理を Snowflake 内で完結させたい場合 |
| Airflow / Step Functions | 依存関係のあるジョブが 1 つだけのため過剰 | 複数ジョブの依存関係・再実行管理が必要になった場合 |
| `PUT` + `COPY INTO` | 小規模データでは `executemany` で十分 | 1 回あたり数十万行を超える場合 |
| cron | systemd timer の方がログ (journald) と失敗時の状態確認が容易 | なし |

## 8. 制約、代替策、残存リスク

| 項目 | 内容 |
| --- | --- |
| 週末に EC2 ごと削除される | timer も消える。週明けに §30 で再設定。データの正本は Snowflake |
| EC2 停止中は実行されない | `Persistent=false` のため停止中の分は後から実行しない (重複実行の防止) |
| 実行時刻 | EC2 を起動している時間帯に合わせる |
| Snowflake 接続前の失敗 | `ETL_RUN_LOG` には残らない。ログ (journald) で確認する |

## 9. Mermaid 構成図

```mermaid
flowchart LR
  TM["systemd timer<br/>平日 07:00 JST"] --> SV["sample-etl.service<br/>docker compose run --rm etl"]
  subgraph Host["Linux Docker EC2"]
    SV --> ETL["etl コンテナ (UID 10001)<br/>extract → transform → load"]
  end
  SRC["外部データ<br/>HTTPS JSON"] -- "GET (再試行)" --> ETL
  ETL -- "MERGE (1 トランザクション)" --> SF[("Snowflake<br/>ORDERS / ETL_RUN_LOG")]
  ETL -- "JSON ログ" --> JR["journald / docker logs"]
```

## 10. 通信フロー

| # | 送信元 | 宛先 | ポート | 内容 |
| --- | --- | --- | --- | --- |
| 1 | etl コンテナ | 取得元 (`ETL_SOURCE_URL`) | 443 | データ取得 |
| 2 | etl コンテナ | Snowflake | 443 | ステージ・MERGE・実行履歴 |

## 11. データフロー

```mermaid
sequenceDiagram
  participant E as etl
  participant S as Snowflake
  E->>E: extract (最大 10 MB、JSON 配列)
  E->>E: transform (検証・正規化・ID ごとに最新を採用)
  E->>S: CREATE TABLE IF NOT EXISTS ORDERS / ETL_RUN_LOG
  E->>S: CREATE OR REPLACE TEMPORARY TABLE ETL_STAGE_ORDERS
  E->>S: BEGIN
  E->>S: INSERT INTO ETL_STAGE_ORDERS (1000 行ずつ)
  E->>S: MERGE INTO ORDERS USING stage
  E->>S: INSERT INTO ETL_RUN_LOG (SUCCEEDED)
  E->>S: COMMIT
  Note over E,S: 失敗時は ROLLBACK → ETL_RUN_LOG に FAILED (可能な場合)
```

## 12. 作成する AWS リソース

なし (Pattern 02 の EC2 上で実行)。Snowflake 側に `ORDERS`、`ETL_RUN_LOG` テーブルが自動作成される。

## 13. パラメーター

[.env.example](.env.example) を `.env` にコピーして記入する。

| 変数 | 既定 | 説明 |
| --- | --- | --- |
| `ETL_JOB_NAME` | `orders_daily` | 実行履歴・クエリタグに使う |
| `ETL_DRY_RUN` | `false` (`.env.example` では `true`) | 取得と変換のみ |
| `ETL_SOURCE_FILE` / `ETL_SOURCE_URL` | サンプルファイル / なし | どちらか一方 |
| `ETL_HTTP_TIMEOUT_SECONDS` | `20` | |
| `ETL_MAX_ATTEMPTS` / `ETL_RETRY_BASE_DELAY_SECONDS` / `ETL_RETRY_MAX_DELAY_SECONDS` | `4` / `2` / `30` | 再試行 |
| `ETL_JOB_TIMEOUT_SECONDS` | `900` | ジョブ全体 |
| `ETL_TARGET_TABLE` / `ETL_RUN_LOG_TABLE` | `ETL_SAMPLE.PUBLIC.ORDERS` / `...ETL_RUN_LOG` | ロード先 |
| `SNOWFLAKE_*` | - | Pattern 03 と同じ変数名 (`keypair` / `pat`) |

入力データの形式 ([sample_data/orders.json](etl/sample_data/orders.json)):

```json
[{"id": "ORD-0001", "occurred_at": "2026-09-28T09:00:00+09:00", "category": "books", "amount": "1200.00"}]
```

## 14. 命名とタグ

AWS リソースなし。Snowflake のクエリタグ `sample-etl:<ETL_JOB_NAME>` で実行を識別できる。

## 15. IAM 設計

AWS の IAM は使わない。Snowflake のロールには対象スキーマへの書き込み権限だけを与える。

## 16. Permissions Boundary

該当なし。

## 17. Security Group 設計

Pattern 02 の SG (アウトバウンド 443) で足りる。インバウンド不要。

## 18. Terraform 構成

なし。

## 19. 手動例外手順

### systemd timer の設定

```bash
# ssm-user (sudo 可能なユーザー) で実行
APP_DIR=/home/dev/work/<GITHUB_REPO>/04_patterns/04_scheduled-etl
sudo sed "s#<APP_DIR>#${APP_DIR}#" "${APP_DIR}/systemd/sample-etl.service" | sudo tee /etc/systemd/system/sample-etl.service >/dev/null
sudo cp "${APP_DIR}/systemd/sample-etl.timer" /etc/systemd/system/sample-etl.timer
sudo systemctl daemon-reload
sudo systemctl enable --now sample-etl.timer
systemctl list-timers sample-etl.timer
```

## 20. OS とミドルウェア初期設定

Pattern 02 で完了している。

## 21. Docker 構成

| 項目 | 内容 |
| --- | --- |
| イメージ | [etl/Dockerfile](etl/Dockerfile): `deps` → `test` (ruff + pytest) → `runtime` (UID 10001) |
| 実行 | `docker compose run --rm etl` (1 回実行して終了。`restart: "no"`) |
| 制限 | read-only、cap_drop ALL、no-new-privileges、512 MB |
| 資格情報 | `./secrets/` を `/run/secrets/app` へ読み取り専用マウント |

HEALTHCHECK は持たない (常駐しないため)。成否は終了コードとログで判定する。

## 22. アプリケーション配置

```bash
sudo -iu dev
cd ~/work/<GITHUB_REPO>/04_patterns/04_scheduled-etl
cp .env.example .env && chmod 600 .env
docker compose build
docker compose run --rm etl         # dry run (既定)
```

Snowflake へロードする場合は `.env` の `ETL_DRY_RUN=false` と `SNOWFLAKE_*` を設定し、[Pattern 03 §19](../03_docker-react-fastapi-snowflake/README.md#19-手動例外手順) と同じ方法で `secrets/` に鍵を置く。

## 23. 正常系確認

```bash
docker compose run --rm etl; echo "exit=$?"
docker compose run --rm etl; echo "exit=$?"     # 2 回目 (冪等性)
```

| 確認 | 期待値 |
| --- | --- |
| 終了コード | `0` |
| 最終ログ行 | `"event": "etl_run_completed", "status": "SUCCEEDED"` (dry run は `DRY_RUN`) |
| サンプルデータの件数 | `extracted: 6, valid: 2, rejected: 3` |
| 1 回目 / 2 回目 | `inserted: 2, updated: 0` / `inserted: 0, updated: 0` |

Snowflake 側:

```sql
SELECT RUN_ID, STATUS, ROWS_EXTRACTED, ROWS_REJECTED, ROWS_INSERTED, ROWS_UPDATED, ERROR_CODE, STARTED_AT, FINISHED_AT
FROM <SNOWFLAKE_DATABASE>.<SNOWFLAKE_SCHEMA>.ETL_RUN_LOG
ORDER BY STARTED_AT DESC
LIMIT 10;
```

テスト:

```bash
docker build --target test ./etl
```

## 24. 異常系確認

| 状況 | 期待値 |
| --- | --- |
| 設定値の形式エラー (例: テーブル名に `;`) | 終了コード 2、`event = config_error`、`fields` に項目名のみ |
| `ETL_DRY_RUN=false` で Snowflake 未設定 | 終了コード 1、`error_code = CONFIG_ERROR`、`missing_settings` に項目名 |
| `ETL_SOURCE_URL` が `http://` | 終了コード 2 (https のみ) |
| 取得元が 503 を返し続ける | `event = retry` が `ETL_MAX_ATTEMPTS - 1` 回 → `EXTRACT_RETRY_EXHAUSTED` |
| MERGE で失敗 | `ROLLBACK`、`ETL_RUN_LOG` に `FAILED` |
| ジョブ全体のタイムアウト | `JOB_TIMEOUT` |

## 25. ログと監視

```bash
journalctl -u sample-etl.service --since today -o cat | grep etl_run_completed
systemctl status sample-etl.service --no-pager
```

主なイベント: `etl_run_started`、`extract`、`reject`、`transform`、`load`、`retry`、`retry_exhausted`、`etl_run_completed`。すべてに `run_id` が付き、`ETL_RUN_LOG.RUN_ID` と突き合わせられる。

## 26. 停止手順

```bash
sudo systemctl stop sample-etl.timer        # 定期実行を一時停止
sudo systemctl start sample-etl.timer       # 再開
```

実行中のジョブを止める場合: `docker ps` で `scheduled-etl-etl-run-*` を確認し `docker stop <CONTAINER>`。

## 27. 個別削除

```bash
sudo systemctl disable --now sample-etl.timer
sudo rm -f /etc/systemd/system/sample-etl.{service,timer}
sudo systemctl daemon-reload
```

Snowflake のテーブルを消す場合 (**データが失われる**):

```sql
DROP TABLE IF EXISTS <SNOWFLAKE_DATABASE>.<SNOWFLAKE_SCHEMA>.ORDERS;
DROP TABLE IF EXISTS <SNOWFLAKE_DATABASE>.<SNOWFLAKE_SCHEMA>.ETL_RUN_LOG;
```

## 28. 全体削除

§27 の後に `docker compose down --rmi local`、`rm -f .env`、`sudo rm -rf secrets`。

## 29. 週末前の退避

コードは Git へ push。データは Snowflake が正本のため退避不要。`.env` / `secrets/` は退避しない。

## 30. 週末後の再構築

Pattern 02 の再構築 → §22 → §19 の timer 設定 → §23。

## 31. トラブルシューティング

| 症状 | 確認 |
| --- | --- |
| timer が動かない | `systemctl list-timers`、EC2 が起動しているか、タイムゾーン指定 (`Asia/Tokyo`) |
| `permission denied` (docker) | service の `User=dev`、`Group=docker` |
| Snowflake の失敗 | [06 Snowflake](../../06_troubleshooting/README.md#snowflake-へ接続できない) |

## 32. コスト

AWS 追加費用なし (EC2 起動中のみ実行)。Snowflake はウェアハウスの稼働時間分のクレジット。

## 33. 未確定事項

U-12〜U-14、U-16、U-17、Q-03 ([未確定事項台帳](../../01_constraints/unconfirmed-items.md))。

## 34. 更新履歴

| 日付 | 内容 |
| --- | --- |
| 2026-09-29 | 初版 |
