"""Run one ETL execution and report the result as a structured log line and exit code.

Exit codes: 0 = succeeded (or dry run), 1 = failed, 2 = configuration error.
"""

from __future__ import annotations

import logging
import signal
import uuid
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from types import FrameType
from typing import Any

from snowflake.connector import errors as sf_errors

from .config import EtlSettings
from .extract import ExtractError, TransientExtractError, extract
from .load import Connection, connect_snowflake, insert_run_log, load
from .logging_config import run_id_var
from .transform import transform

logger = logging.getLogger("etl_job")


class JobTimeoutError(Exception):
    pass


class ConfigError(Exception):
    pass


@contextmanager
def deadline(seconds: int) -> Iterator[None]:
    """Abort the whole run after ``seconds`` (SIGALRM, main thread on Linux/macOS)."""

    def _raise(_signum: int, _frame: FrameType | None) -> None:
        raise JobTimeoutError

    previous = signal.signal(signal.SIGALRM, _raise)
    signal.alarm(seconds)
    try:
        yield
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, previous)


def _error_code(exc: BaseException) -> str:
    match exc:
        case JobTimeoutError():
            return "JOB_TIMEOUT"
        case ConfigError():
            return "CONFIG_ERROR"
        case TransientExtractError():
            return "EXTRACT_RETRY_EXHAUSTED"
        case ExtractError() | OSError() if not isinstance(exc, sf_errors.Error):
            return "EXTRACT_FAILED"
        case sf_errors.Error():
            return "SNOWFLAKE_ERROR"
        case _:
            return "UNEXPECTED_ERROR"


def run(settings: EtlSettings, connect: Callable[[EtlSettings], Connection] = connect_snowflake) -> int:
    run_id = uuid.uuid4().hex
    run_id_var.set(run_id)
    started = datetime.now(UTC)
    summary: dict[str, Any] = {"job_name": settings.job_name, "dry_run": settings.dry_run}
    logger.info("etl run started", extra={"event": "etl_run_started", **summary})
    conn: Connection | None = None
    run_log: dict[str, Any] = {
        "run_id": run_id,
        "job_name": settings.job_name,
        "extracted": 0,
        "rejected": 0,
        "started_at": started.isoformat(),
    }
    try:
        with deadline(settings.job_timeout_seconds):
            raw = extract(settings)
            result = transform(raw)
            run_log.update(extracted=len(raw), rejected=result.rejected)
            summary.update(extracted=len(raw), valid=len(result.records), rejected=result.rejected)
            if settings.dry_run:
                status = "DRY_RUN"
            else:
                missing = settings.snowflake_missing_settings()
                if missing:
                    summary["missing_settings"] = missing
                    raise ConfigError
                conn = connect(settings)
                loaded = load(conn, settings, result.records, run_id, run_log, datetime.now(UTC))
                summary.update(inserted=loaded.inserted, updated=loaded.updated)
                status = "SUCCEEDED"
    except Exception as exc:
        code = _error_code(exc)
        _record_failure(conn, settings, run_log, code)
        logger.error(
            "etl run completed",
            extra={
                "event": "etl_run_completed",
                "status": "FAILED",
                "error_code": code,
                "exception_type": type(exc).__name__,
                "duration_ms": _elapsed_ms(started),
                **summary,
            },
        )
        return 1
    finally:
        if conn is not None:
            conn.close()
    logger.info(
        "etl run completed",
        extra={"event": "etl_run_completed", "status": status, "duration_ms": _elapsed_ms(started), **summary},
    )
    return 0


def _record_failure(conn: Connection | None, settings: EtlSettings, run_log: dict[str, Any], code: str) -> None:
    """Best effort: a failed run is also visible in the run-log table when Snowflake is reachable."""
    if conn is None:
        return
    try:
        cur = conn.cursor()
        try:
            insert_run_log(
                cur,
                settings,
                {
                    **run_log,
                    "status": "FAILED",
                    "inserted": 0,
                    "updated": 0,
                    "error_code": code,
                    "finished_at": datetime.now(UTC).isoformat(),
                },
            )
        finally:
            cur.close()
    except Exception:  # never mask the original failure
        logger.warning("could not write failure to run log", extra={"event": "run_log_write_failed"})


def _elapsed_ms(started: datetime) -> float:
    return round((datetime.now(UTC) - started).total_seconds() * 1000, 1)
