"""Extract: fetch JSON records from an HTTPS endpoint or a local file."""

from __future__ import annotations

import json
import logging
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from .config import EtlSettings
from .retry import retry

logger = logging.getLogger(__name__)


class ExtractError(Exception):
    """Non-retryable extract failure (bad payload, size limit, 4xx)."""


class TransientExtractError(Exception):
    """Retryable extract failure (timeout, connection error, 5xx, 429)."""


def _read_limited(stream: Any, limit: int) -> bytes:  # noqa: ANN401 - file-like object
    data = stream.read(limit + 1)
    if len(data) > limit:
        raise ExtractError(f"payload exceeds {limit} bytes")
    return data


def _fetch_url(url: str, timeout: float, limit: int) -> bytes:
    request = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": "sample-etl/0.1"})  # noqa: S310
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310 - https enforced in settings
            return _read_limited(response, limit)
    except urllib.error.HTTPError as exc:
        if exc.code == 429 or exc.code >= 500:
            raise TransientExtractError(f"HTTP {exc.code}") from None
        raise ExtractError(f"HTTP {exc.code}") from None
    except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
        raise TransientExtractError(type(exc).__name__) from None


def _parse(payload: bytes) -> list[dict[str, Any]]:
    try:
        data = json.loads(payload)
    except json.JSONDecodeError:
        raise ExtractError("payload is not valid JSON") from None
    if not isinstance(data, list) or not all(isinstance(item, dict) for item in data):
        raise ExtractError("payload must be a JSON array of objects")
    return data


def extract(settings: EtlSettings) -> list[dict[str, Any]]:
    if settings.source_file is not None:
        path = Path(settings.source_file)
        with path.open("rb") as fh:
            payload = _read_limited(fh, settings.max_response_bytes)
        source = "file"
    else:
        url = settings.source_url or ""
        payload = retry(
            lambda: _fetch_url(url, settings.http_timeout_seconds, settings.max_response_bytes),
            operation="extract_http",
            attempts=settings.max_attempts,
            base_delay=settings.retry_base_delay_seconds,
            max_delay=settings.retry_max_delay_seconds,
            retry_on=(TransientExtractError,),
        )
        source = "https"
    records = _parse(payload)
    logger.info("extracted", extra={"event": "extract", "source_type": source, "record_count": len(records)})
    return records
