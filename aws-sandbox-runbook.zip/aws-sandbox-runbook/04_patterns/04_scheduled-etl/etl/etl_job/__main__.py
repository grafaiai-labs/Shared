"""Entry point: python -m etl_job"""

from __future__ import annotations

import logging
import sys

from pydantic import ValidationError

from .config import EtlSettings
from .logging_config import configure_logging
from .main import run


def main() -> int:
    configure_logging("INFO")
    try:
        settings = EtlSettings()
    except ValidationError as exc:
        # Report which settings are invalid, never their values.
        fields = sorted({".".join(str(p) for p in e["loc"]) or "settings" for e in exc.errors()})
        logging.getLogger("etl_job").error(
            "invalid configuration", extra={"event": "config_error", "fields": fields, "error_code": "CONFIG_ERROR"}
        )
        return 2
    configure_logging(settings.log_level)
    return run(settings)


if __name__ == "__main__":
    sys.exit(main())
