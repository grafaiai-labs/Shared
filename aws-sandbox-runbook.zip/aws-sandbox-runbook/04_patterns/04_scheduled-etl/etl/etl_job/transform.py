"""Transform: validate, normalise and de-duplicate records."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

logger = logging.getLogger(__name__)


class OrderRecord(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    id: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_-]+$")
    occurred_at: datetime
    category: str = Field(min_length=1, max_length=32)
    amount: Decimal = Field(ge=0, max_digits=18, decimal_places=2)

    @field_validator("occurred_at")
    @classmethod
    def _aware(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("timestamp must include a timezone offset")
        return value

    @field_validator("category")
    @classmethod
    def _normalise_category(cls, value: str) -> str:
        return value.strip().upper()


@dataclass(frozen=True)
class TransformResult:
    records: list[OrderRecord]
    rejected: int
    duplicates: int


def transform(raw: list[dict[str, Any]]) -> TransformResult:
    valid: list[OrderRecord] = []
    rejected = 0
    for index, item in enumerate(raw):
        try:
            valid.append(OrderRecord.model_validate(item))
        except ValidationError as exc:
            rejected += 1
            # Log field names only, never the rejected values.
            fields = sorted({".".join(str(p) for p in e["loc"]) for e in exc.errors()})
            logger.warning("record rejected", extra={"event": "reject", "index": index, "fields": fields})

    # Keep the latest version of each id so that re-runs and overlapping windows converge.
    latest: dict[str, OrderRecord] = {}
    for record in valid:
        current = latest.get(record.id)
        if current is None or record.occurred_at >= current.occurred_at:
            latest[record.id] = record
    duplicates = len(valid) - len(latest)
    records = sorted(latest.values(), key=lambda r: r.id)
    logger.info(
        "transformed",
        extra={"event": "transform", "valid": len(records), "rejected": rejected, "duplicates": duplicates},
    )
    return TransformResult(records=records, rejected=rejected, duplicates=duplicates)
