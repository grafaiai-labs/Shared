"""Scheduled ETL sample."""

__version__ = "0.1.0"
