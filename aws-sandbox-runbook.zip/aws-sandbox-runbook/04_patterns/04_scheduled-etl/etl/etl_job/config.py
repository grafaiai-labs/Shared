"""ETL settings. Secrets are read from files, never from environment variable values."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Unquoted identifier, optionally qualified (DB.SCHEMA.TABLE). Identifiers cannot be bound, so they are validated.
_PLACEHOLDER = re.compile(r"<[A-Z0-9_]+>")
QUALIFIED_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*(\.[A-Za-z_][A-Za-z0-9_$]*){0,2}$")


class EtlSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="ETL_", extra="ignore", frozen=True)

    job_name: str = Field(default="orders_daily", pattern=r"^[a-z][a-z0-9_]{2,63}$")
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    dry_run: bool = False

    # Extract: exactly one of source_url / source_file
    source_url: str | None = None
    source_file: Path | None = None
    http_timeout_seconds: float = Field(default=20, gt=0, le=120)
    max_response_bytes: int = Field(default=10_000_000, ge=1_000, le=100_000_000)

    # Retry
    max_attempts: int = Field(default=4, ge=1, le=10)
    retry_base_delay_seconds: float = Field(default=2.0, ge=0, le=60)
    retry_max_delay_seconds: float = Field(default=30.0, ge=0, le=300)

    # Overall deadline for one run
    job_timeout_seconds: int = Field(default=900, ge=10, le=3600)

    # Load
    target_table: str = "ETL_SAMPLE.PUBLIC.ORDERS"
    run_log_table: str = "ETL_SAMPLE.PUBLIC.ETL_RUN_LOG"

    # Snowflake (same variable names as the API sample, without the ETL_ prefix)
    snowflake_account: str | None = Field(default=None, validation_alias="SNOWFLAKE_ACCOUNT")
    snowflake_user: str | None = Field(default=None, validation_alias="SNOWFLAKE_USER")
    snowflake_role: str | None = Field(default=None, validation_alias="SNOWFLAKE_ROLE")
    snowflake_warehouse: str | None = Field(default=None, validation_alias="SNOWFLAKE_WAREHOUSE")
    snowflake_auth_method: Literal["keypair", "pat"] = Field(
        default="keypair", validation_alias="SNOWFLAKE_AUTH_METHOD"
    )
    snowflake_private_key_file: Path | None = Field(default=None, validation_alias="SNOWFLAKE_PRIVATE_KEY_FILE")
    snowflake_secret_file: Path | None = Field(default=None, validation_alias="SNOWFLAKE_SECRET_FILE")
    snowflake_login_timeout_seconds: int = Field(
        default=15, ge=1, le=120, validation_alias="SNOWFLAKE_LOGIN_TIMEOUT_SECONDS"
    )
    snowflake_statement_timeout_seconds: int = Field(
        default=300, ge=1, le=3600, validation_alias="SNOWFLAKE_STATEMENT_TIMEOUT_SECONDS"
    )

    @field_validator("target_table", "run_log_table")
    @classmethod
    def _identifier(cls, value: str) -> str:
        if not QUALIFIED_IDENTIFIER.fullmatch(value):
            raise ValueError("must be an unquoted identifier such as DB.SCHEMA.TABLE")
        return value.upper()

    @field_validator("source_url")
    @classmethod
    def _https_only(cls, value: str | None) -> str | None:
        if value is not None and not value.startswith("https://"):
            raise ValueError("source_url must use https://")
        return value

    @model_validator(mode="after")
    def _one_source(self) -> EtlSettings:
        if (self.source_url is None) == (self.source_file is None):
            raise ValueError("set exactly one of ETL_SOURCE_URL or ETL_SOURCE_FILE")
        return self

    def snowflake_missing_settings(self) -> list[str]:
        """Return the names (never the values) of missing Snowflake settings."""
        if self.snowflake_auth_method == "keypair":
            credential = ("SNOWFLAKE_PRIVATE_KEY_FILE", self.snowflake_private_key_file)
        else:
            credential = ("SNOWFLAKE_SECRET_FILE", self.snowflake_secret_file)
        required: dict[str, str | Path | None] = {
            "SNOWFLAKE_ACCOUNT": self.snowflake_account,
            "SNOWFLAKE_USER": self.snowflake_user,
            "SNOWFLAKE_WAREHOUSE": self.snowflake_warehouse,
            credential[0]: credential[1],
        }
        return [name for name, value in required.items() if not _is_set(value)]


def _is_set(value: str | Path | None) -> bool:
    return value is not None and bool(str(value).strip()) and not _PLACEHOLDER.fullmatch(str(value).strip())
