"""Exponential backoff with full jitter for transient failures only."""

from __future__ import annotations

import logging
import random
import time
from collections.abc import Callable

logger = logging.getLogger(__name__)


def retry[T](
    func: Callable[[], T],
    *,
    operation: str,
    attempts: int,
    base_delay: float,
    max_delay: float,
    retry_on: tuple[type[BaseException], ...],
    sleep: Callable[[float], None] = time.sleep,
) -> T:
    for attempt in range(1, attempts + 1):
        try:
            return func()
        except retry_on as exc:
            if attempt == attempts:
                logger.error(
                    "giving up",
                    extra={
                        "event": "retry_exhausted",
                        "operation": operation,
                        "attempt": attempt,
                        "exception_type": type(exc).__name__,
                    },
                )
                raise
            delay = random.uniform(0, min(max_delay, base_delay * 2 ** (attempt - 1)))  # noqa: S311 - jitter only
            logger.warning(
                "transient failure, retrying",
                extra={
                    "event": "retry",
                    "operation": operation,
                    "attempt": attempt,
                    "delay_seconds": round(delay, 2),
                    "exception_type": type(exc).__name__,
                },
            )
            sleep(delay)
    raise AssertionError("unreachable")
