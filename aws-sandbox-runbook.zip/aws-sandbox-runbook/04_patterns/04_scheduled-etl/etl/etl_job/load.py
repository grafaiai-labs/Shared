"""Load: idempotent MERGE into Snowflake plus a run-log row.

Re-running the same input converges to the same table state:
  - records are staged in a session-scoped temporary table,
  - MERGE inserts new ids and updates only rows whose values changed,
  - stage + MERGE + run log commit in one transaction (DDL runs before BEGIN, because
    Snowflake commits DDL implicitly).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Protocol

from cryptography.hazmat.primitives import serialization
from snowflake.connector import connect
from snowflake.connector import errors as sf_errors

from .config import EtlSettings
from .retry import retry
from .transform import OrderRecord

logger = logging.getLogger(__name__)

STAGE_TABLE = "ETL_STAGE_ORDERS"
BATCH_SIZE = 1000


class Cursor(Protocol):
    def execute(self, sql: str, params: Any = None) -> Any: ...  # noqa: ANN401
    def executemany(self, sql: str, seq: list[Any]) -> Any: ...  # noqa: ANN401
    def fetchone(self) -> Any: ...  # noqa: ANN401
    def close(self) -> Any: ...  # noqa: ANN401


class Connection(Protocol):
    def cursor(self) -> Cursor: ...
    def close(self) -> Any: ...  # noqa: ANN401


@dataclass(frozen=True)
class LoadResult:
    staged: int
    inserted: int
    updated: int


def connect_snowflake(settings: EtlSettings) -> Connection:
    kwargs: dict[str, Any] = {
        "account": settings.snowflake_account,
        "user": settings.snowflake_user,
        "warehouse": settings.snowflake_warehouse,
        "login_timeout": settings.snowflake_login_timeout_seconds,
        "network_timeout": 60,
        "client_session_keep_alive": False,
        "session_parameters": {
            "STATEMENT_TIMEOUT_IN_SECONDS": settings.snowflake_statement_timeout_seconds,
            "QUERY_TAG": f"sample-etl:{settings.job_name}",
        },
    }
    if settings.snowflake_role:
        kwargs["role"] = settings.snowflake_role
    if settings.snowflake_auth_method == "keypair" and settings.snowflake_private_key_file:
        key = serialization.load_pem_private_key(settings.snowflake_private_key_file.read_bytes(), password=None)
        kwargs["authenticator"] = "SNOWFLAKE_JWT"
        kwargs["private_key"] = key.private_bytes(
            serialization.Encoding.DER, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()
        )
    elif settings.snowflake_secret_file:
        kwargs["password"] = settings.snowflake_secret_file.read_text().strip()

    return retry(
        lambda: connect(**kwargs),
        operation="snowflake_connect",
        attempts=settings.max_attempts,
        base_delay=settings.retry_base_delay_seconds,
        max_delay=settings.retry_max_delay_seconds,
        retry_on=(sf_errors.OperationalError,),
    )


def ensure_tables(cur: Cursor, settings: EtlSettings) -> None:
    cur.execute(
        f"CREATE TABLE IF NOT EXISTS {settings.target_table} ("
        "ID VARCHAR(64) NOT NULL PRIMARY KEY, OCCURRED_AT TIMESTAMP_TZ NOT NULL, CATEGORY VARCHAR(32) NOT NULL, "
        "AMOUNT NUMBER(18,2) NOT NULL, SOURCE_RUN_ID VARCHAR(64) NOT NULL, LOADED_AT TIMESTAMP_TZ NOT NULL)"
    )
    cur.execute(
        f"CREATE TABLE IF NOT EXISTS {settings.run_log_table} ("
        "RUN_ID VARCHAR(64) NOT NULL, JOB_NAME VARCHAR(64) NOT NULL, STATUS VARCHAR(16) NOT NULL, "
        "ROWS_EXTRACTED NUMBER, ROWS_REJECTED NUMBER, ROWS_INSERTED NUMBER, ROWS_UPDATED NUMBER, "
        "ERROR_CODE VARCHAR(64), STARTED_AT TIMESTAMP_TZ NOT NULL, FINISHED_AT TIMESTAMP_TZ NOT NULL)"
    )
    cur.execute(
        f"CREATE OR REPLACE TEMPORARY TABLE {STAGE_TABLE} "
        "(ID VARCHAR(64), OCCURRED_AT VARCHAR(40), CATEGORY VARCHAR(32), AMOUNT VARCHAR(40))"
    )


def insert_run_log(cur: Cursor, settings: EtlSettings, row: dict[str, Any]) -> None:
    cur.execute(
        f"INSERT INTO {settings.run_log_table} (RUN_ID, JOB_NAME, STATUS, ROWS_EXTRACTED, ROWS_REJECTED, "
        "ROWS_INSERTED, ROWS_UPDATED, ERROR_CODE, STARTED_AT, FINISHED_AT) VALUES (%(run_id)s, %(job_name)s, "
        "%(status)s, %(extracted)s, %(rejected)s, %(inserted)s, %(updated)s, %(error_code)s, "
        "TO_TIMESTAMP_TZ(%(started_at)s), TO_TIMESTAMP_TZ(%(finished_at)s))",
        row,
    )


def load(
    conn: Connection,
    settings: EtlSettings,
    records: list[OrderRecord],
    run_id: str,
    run_log: dict[str, Any],
    now: datetime,
) -> LoadResult:
    cur = conn.cursor()
    try:
        ensure_tables(cur, settings)
        cur.execute("BEGIN")
        try:
            rows = [(r.id, r.occurred_at.isoformat(), r.category, str(r.amount)) for r in records]
            for start in range(0, len(rows), BATCH_SIZE):
                cur.executemany(
                    f"INSERT INTO {STAGE_TABLE} (ID, OCCURRED_AT, CATEGORY, AMOUNT) VALUES (%s, %s, %s, %s)",
                    rows[start : start + BATCH_SIZE],
                )
            cur.execute(
                f"MERGE INTO {settings.target_table} t USING ("
                "SELECT ID, TO_TIMESTAMP_TZ(OCCURRED_AT) AS OCCURRED_AT, CATEGORY, "
                f"TO_NUMBER(AMOUNT, 18, 2) AS AMOUNT FROM {STAGE_TABLE}) s ON t.ID = s.ID "
                "WHEN MATCHED AND (t.OCCURRED_AT <> s.OCCURRED_AT OR t.CATEGORY <> s.CATEGORY OR t.AMOUNT <> s.AMOUNT) "
                "THEN UPDATE SET OCCURRED_AT = s.OCCURRED_AT, CATEGORY = s.CATEGORY, AMOUNT = s.AMOUNT, "
                "SOURCE_RUN_ID = %(run_id)s, LOADED_AT = CURRENT_TIMESTAMP() "
                "WHEN NOT MATCHED THEN INSERT (ID, OCCURRED_AT, CATEGORY, AMOUNT, SOURCE_RUN_ID, LOADED_AT) "
                "VALUES (s.ID, s.OCCURRED_AT, s.CATEGORY, s.AMOUNT, %(run_id)s, CURRENT_TIMESTAMP())",
                {"run_id": run_id},
            )
            merged = cur.fetchone() or (0, 0)
            inserted = int(merged[0] or 0)
            updated = int(merged[1] or 0) if len(merged) > 1 else 0
            insert_run_log(
                cur,
                settings,
                {
                    **run_log,
                    "status": "SUCCEEDED",
                    "inserted": inserted,
                    "updated": updated,
                    "error_code": None,
                    "finished_at": now.isoformat(),
                },
            )
            cur.execute("COMMIT")
        except Exception:
            cur.execute("ROLLBACK")
            raise
    finally:
        cur.close()
    result = LoadResult(staged=len(records), inserted=inserted, updated=updated)
    logger.info("loaded", extra={"event": "load", "staged": result.staged, "inserted": inserted, "updated": updated})
    return result
