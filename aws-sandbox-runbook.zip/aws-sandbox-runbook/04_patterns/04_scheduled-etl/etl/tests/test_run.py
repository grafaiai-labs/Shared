from __future__ import annotations

from etl_job.config import EtlSettings
from etl_job.main import run
from tests.conftest import SAMPLE, FakeConnection


def _sqls(conn: FakeConnection) -> list[str]:
    return [sql for sql, _ in conn.log]


def test_dry_run_needs_no_snowflake():
    settings = EtlSettings(_env_file=None, source_file=SAMPLE, dry_run=True)

    def must_not_connect(_: EtlSettings) -> FakeConnection:
        raise AssertionError("dry run must not connect")

    assert run(settings, connect=must_not_connect) == 0


def test_missing_snowflake_settings_is_config_error():
    settings = EtlSettings(_env_file=None, source_file=SAMPLE, SNOWFLAKE_ACCOUNT="<SNOWFLAKE_ACCOUNT_IDENTIFIER>")
    assert run(settings, connect=lambda _: FakeConnection()) == 1


def test_successful_load_is_transactional_and_idempotent(settings):
    conn = FakeConnection(merge_result=(2, 0))
    assert run(settings, connect=lambda _: conn) == 0
    sqls = _sqls(conn)
    begin = sqls.index("BEGIN")
    # DDL before BEGIN (Snowflake commits DDL implicitly)
    assert all(s.startswith("CREATE") for s in sqls[:begin])
    assert sqls[-1] == "COMMIT"
    merge = next(s for s in sqls if s.startswith("MERGE INTO ETL_SAMPLE.PUBLIC.ORDERS"))
    assert "WHEN MATCHED AND" in merge and "WHEN NOT MATCHED" in merge
    staged = next(p for s, p in conn.log if s.startswith("INSERT INTO ETL_STAGE_ORDERS"))
    assert [row[0] for row in staged] == ["ORD-0001", "ORD-0002"]
    run_log = next(p for s, p in conn.log if s.startswith("INSERT INTO ETL_SAMPLE.PUBLIC.ETL_RUN_LOG"))
    assert run_log["status"] == "SUCCEEDED" and run_log["rejected"] == 3 and run_log["inserted"] == 2
    assert conn.closed


def test_failure_rolls_back_and_records_failed_run(settings):
    conn = FakeConnection(fail_on="MERGE")
    assert run(settings, connect=lambda _: conn) == 1
    sqls = _sqls(conn)
    assert "ROLLBACK" in sqls and "COMMIT" not in sqls
    failed = [p for s, p in conn.log if s.startswith("INSERT INTO ETL_SAMPLE.PUBLIC.ETL_RUN_LOG")]
    assert failed[-1]["status"] == "FAILED" and failed[-1]["error_code"] == "UNEXPECTED_ERROR"
    assert conn.closed


def test_job_timeout(settings, monkeypatch):
    import etl_job.main as main_mod

    def slow_extract(_):
        raise main_mod.JobTimeoutError

    monkeypatch.setattr(main_mod, "extract", slow_extract)
    assert run(settings, connect=lambda _: FakeConnection()) == 1
