from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from etl_job.config import EtlSettings

SAMPLE = Path(__file__).resolve().parents[1] / "sample_data" / "orders.json"


class FakeCursor:
    def __init__(self, log: list[tuple[str, Any]], merge_result: tuple[int, int], fail_on: str | None) -> None:
        self.log = log
        self.merge_result = merge_result
        self.fail_on = fail_on
        self._last = ""

    def execute(self, sql: str, params: Any = None) -> None:
        self.log.append((sql, params))
        self._last = sql
        if self.fail_on and sql.startswith(self.fail_on):
            raise RuntimeError("injected failure")

    def executemany(self, sql: str, seq: list[Any]) -> None:
        self.log.append((sql, list(seq)))

    def fetchone(self) -> tuple[int, int] | None:
        return self.merge_result if self._last.startswith("MERGE") else None

    def close(self) -> None:
        pass


class FakeConnection:
    def __init__(self, merge_result: tuple[int, int] = (2, 0), fail_on: str | None = None) -> None:
        self.log: list[tuple[str, Any]] = []
        self.merge_result = merge_result
        self.fail_on = fail_on
        self.closed = False

    def cursor(self) -> FakeCursor:
        return FakeCursor(self.log, self.merge_result, self.fail_on)

    def close(self) -> None:
        self.closed = True


@pytest.fixture
def settings(tmp_path: Path) -> EtlSettings:
    key = tmp_path / "rsa_key.p8"
    key.write_text("dummy")
    return EtlSettings(
        _env_file=None,  # type: ignore[call-arg]
        source_file=SAMPLE,
        SNOWFLAKE_ACCOUNT="dummy-account",
        SNOWFLAKE_USER="DUMMY_USER",
        SNOWFLAKE_WAREHOUSE="DUMMY_WH",
        SNOWFLAKE_PRIVATE_KEY_FILE=key,
        retry_base_delay_seconds=0,
    )
