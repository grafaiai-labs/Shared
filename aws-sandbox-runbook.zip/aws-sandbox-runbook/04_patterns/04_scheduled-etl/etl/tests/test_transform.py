from __future__ import annotations

import json
from decimal import Decimal

from etl_job.transform import transform
from tests.conftest import SAMPLE


def test_rejects_invalid_and_keeps_latest_duplicate():
    result = transform(json.loads(SAMPLE.read_text()))
    ids = [r.id for r in result.records]
    assert ids == ["ORD-0001", "ORD-0002"]
    assert result.rejected == 3  # bad date, empty id, negative amount
    assert result.duplicates == 1
    ord2 = next(r for r in result.records if r.id == "ORD-0002")
    assert ord2.amount == Decimal("4980")
    assert ord2.category == "GAMES"


def test_naive_timestamp_rejected():
    result = transform([{"id": "A1", "occurred_at": "2026-09-28T09:00:00", "category": "x", "amount": "1"}])
    assert result.records == [] and result.rejected == 1


def test_transform_is_deterministic():
    raw = json.loads(SAMPLE.read_text())
    assert transform(raw).records == transform(list(reversed(raw))).records
