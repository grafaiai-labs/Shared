from __future__ import annotations

import pytest

from etl_job import extract as extract_mod
from etl_job.config import EtlSettings
from etl_job.extract import ExtractError, TransientExtractError, extract
from etl_job.retry import retry


def test_retry_succeeds_after_transient_failures():
    calls = {"n": 0}
    sleeps: list[float] = []

    def flaky() -> str:
        calls["n"] += 1
        if calls["n"] < 3:
            raise TransientExtractError("503")
        return "ok"

    out = retry(
        flaky,
        operation="t",
        attempts=4,
        base_delay=1,
        max_delay=10,
        retry_on=(TransientExtractError,),
        sleep=sleeps.append,
    )
    assert out == "ok" and calls["n"] == 3 and len(sleeps) == 2
    assert all(0 <= s <= 10 for s in sleeps)


def test_retry_does_not_retry_permanent_errors():
    calls = {"n": 0}

    def bad() -> None:
        calls["n"] += 1
        raise ExtractError("400")

    with pytest.raises(ExtractError):
        retry(bad, operation="t", attempts=4, base_delay=0, max_delay=0, retry_on=(TransientExtractError,))
    assert calls["n"] == 1


def test_retry_gives_up():
    with pytest.raises(TransientExtractError):
        retry(
            lambda: (_ for _ in ()).throw(TransientExtractError("x")),
            operation="t",
            attempts=2,
            base_delay=0,
            max_delay=0,
            retry_on=(TransientExtractError,),
            sleep=lambda _: None,
        )


def test_extract_size_limit(tmp_path):
    big = tmp_path / "big.json"
    big.write_text("[" + ",".join(["{}"] * 2000) + "]")
    settings = EtlSettings(_env_file=None, source_file=big, max_response_bytes=1000)
    with pytest.raises(ExtractError):
        extract(settings)


def test_extract_rejects_non_array(tmp_path):
    f = tmp_path / "obj.json"
    f.write_text('{"id": 1}')
    with pytest.raises(ExtractError):
        extract(EtlSettings(_env_file=None, source_file=f))


def test_https_source_is_retried(monkeypatch):
    calls = {"n": 0}

    def fake_fetch(url: str, timeout: float, limit: int) -> bytes:
        calls["n"] += 1
        if calls["n"] == 1:
            raise TransientExtractError("timeout")
        return b'[{"id": "A1"}]'

    monkeypatch.setattr(extract_mod, "_fetch_url", fake_fetch)
    settings = EtlSettings(_env_file=None, source_url="https://example.invalid/orders.json", retry_base_delay_seconds=0)
    assert extract(settings) == [{"id": "A1"}]
    assert calls["n"] == 2


def test_http_source_must_be_https():
    with pytest.raises(ValueError, match="https"):
        EtlSettings(_env_file=None, source_url="http://example.invalid/data.json")


def test_identifier_validation():
    with pytest.raises(ValueError, match="identifier"):
        EtlSettings(_env_file=None, source_file="x.json", target_table="DB.S.T; DROP TABLE X")
