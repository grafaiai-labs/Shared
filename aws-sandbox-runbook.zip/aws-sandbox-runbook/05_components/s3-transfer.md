# S3 による搬送

社内 PC と EC2 の間でファイルを受け渡す唯一の経路。すべて Bootstrap バケット (`<BOOTSTRAP_BUCKET_NAME>`) を使う。

| プレフィックス | 用途 | 書き込み | 読み取り |
| --- | --- | --- | --- |
| `iac/` | 非公開 IaC ZIP | 社内 PC (コンソール) | Runner |
| `state/` | Terraform State | Runner | Runner |
| `transfer/<owner>-<purpose>/` | 退避・受け渡し | 各開発用 EC2、社内 PC (コンソール) | 各開発用 EC2、社内 PC (コンソール) |

> [!WARNING]
> S3 も週末に削除される。ここは「通り道」であり、保管場所ではない。
> `.env`、秘密鍵、パスワード、State を `transfer/` に置かない。

## 1. 社内 PC → Runner (IaC ZIP)

1. 社内 PC で ZIP を作成する ([コード管理 §4](../02_common-design/code-management.md#4-非公開-iac-zip))。出力された SHA256 を控える。
2. S3 → `<BOOTSTRAP_BUCKET_NAME>` →「アップロード」→ ZIP を追加 →「送信先」で `iac/` を指定 →「アップロード」。

   | 確認する値 | 期待値 |
   | --- | --- |
   | キー | `iac/iac-YYYYMMDD-HHMMSS.zip` |
   | サーバー側の暗号化 | SSE-S3 (バケットの既定) |

3. Runner で取得する。

   ```bash
   iac-fetch s3://<BOOTSTRAP_BUCKET_NAME>/iac/<IAC_ZIP_NAME> <IAC_ZIP_SHA256>
   ```

## 2. EC2 → 社内 PC (退避)

```bash
# Linux (dev)。ディレクトリはまとめてから送る
tar -czf /tmp/private-notes.tar.gz -C ~/work private-notes
aws s3 cp /tmp/private-notes.tar.gz s3://<BOOTSTRAP_BUCKET_NAME>/transfer/<OWNER>-dockdev/
rm -f /tmp/private-notes.tar.gz
```

```powershell
# Windows
Compress-Archive -Path $HOME\work\private-notes -DestinationPath $env:TEMP\private-notes.zip -Force
aws s3 cp $env:TEMP\private-notes.zip s3://<BOOTSTRAP_BUCKET_NAME>/transfer/<OWNER>-windev/
Remove-Item $env:TEMP\private-notes.zip
```

社内 PC: S3 → `<BOOTSTRAP_BUCKET_NAME>` → `transfer/<owner>-<purpose>/` → 対象を選択 →「ダウンロード」。
ダウンロード後、S3 上のオブジェクトを削除する (「削除」→ 確認文字列を入力)。

## 3. 社内 PC → EC2

1. コンソールで `transfer/<owner>-<purpose>/` へアップロード。
2. EC2 で取得する。

   ```bash
   aws s3 cp s3://<BOOTSTRAP_BUCKET_NAME>/transfer/<OWNER>-dockdev/<FILE_NAME> ~/work/
   ```

## 4. 権限の範囲

| 主体 | 許可 |
| --- | --- |
| Runner ロール | `state/*` 読み書き、`iac/*` 読み取り |
| Windows ロール | `transfer/<owner>-windev/*` 読み書き |
| Linux ロール | `transfer/<owner>-dockdev/*` 読み書き |
| コンテナ | なし (IMDS へ到達できない) |
