# SSM Session Manager

## 1. 接続

1. EC2 →「インスタンス」→ 対象を選択 →「接続」。
2. 「Session Manager」タブ →「接続」。

| 確認する値 | 期待値 |
| --- | --- |
| インスタンスの状態 | 実行中、ステータスチェック合格 |
| IAM ロール (インスタンス詳細 → セキュリティ) | `AmazonSSMManagedInstanceCore` を含むロール |
| 「Session Manager」タブ | 「接続」ボタンが有効 (無効な場合は [トラブルシューティング](../06_troubleshooting/README.md#session-manager-で接続できない)) |

接続直後のユーザーは `ssm-user` (sudo 可能)。

| 用途 | ユーザー |
| --- | --- |
| Runner での Terraform | `ssm-user` のまま |
| Linux 開発作業 | `sudo -iu dev` で作業ユーザーへ切り替える |
| パッケージ導入などの管理作業 | `ssm-user` + `sudo` |

## 2. 使い方の注意

- セッションは無操作で一定時間後に切断される (アカウントの Session Manager 設定による)。長時間の処理は `nohup` または `tmux` を使う。

  ```bash
  sudo dnf -y install tmux     # 必要な場合
  tmux new -s work             # 再接続後は tmux attach -t work
  ```

- ブラウザーのターミナルへの貼り付けは、改行を含む長い文字列で崩れることがある。長いスクリプトはファイルとして S3 経由で渡すか、`cat > file <<'EOF'` で少しずつ貼り付ける。
- 画面に秘密情報を表示しない (`cat .env` をしない)。Session Manager の設定によってはセッションログが記録される。
- Session Manager の「設定」(Run As、ログ出力先など) はアカウント全体に影響するため変更しない。

## 3. 使わないもの

| 機能 | 理由 |
| --- | --- |
| SSH over Session Manager | SSH キーを使わない方針 |
| ポートフォワード | 社内 PC に AWS CLI と Session Manager Plugin を導入できない |
