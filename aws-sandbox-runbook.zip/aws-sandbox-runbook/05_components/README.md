# 共通コンポーネント手順

複数のパターンで使う操作をまとめたもの。

| 文書 | 使う場面 |
| --- | --- |
| [SSM Session Manager](ssm-session-manager.md) | Runner / Linux EC2 への接続、ファイルの受け渡し不可時の代替 |
| [S3 による搬送](s3-transfer.md) | 社内 PC ⇔ EC2 のファイル受け渡し (IaC ZIP、退避) |
| [Snowflake 接続](snowflake-connection.md) | 認証方式の選択、キーペアの作成、CLI / アプリの設定 |
| [個人 Public GitHub](github-public.md) | clone / push、認証、公開前の確認 |
| [Claude Code](claude-code.md) | 導入確認、認証、秘密情報を読ませない設定 |
