# 個人 Public GitHub

## 1. 何を置くか

[Public / 非公開の境界](../01_constraints/security-boundary.md) の「Public 可」だけ。ランブックのリポジトリそのものは置かない。抽出は [export-public.sh](../09_scripts/export-public.sh) で行う ([コード管理 §5](../02_common-design/code-management.md#5-public-github-への抽出))。

## 2. 接続確認

```bash
# 認証不要の到達確認
git ls-remote --heads https://github.com/<GITHUB_USER>/<GITHUB_REPO>.git
```

## 3. 認証

| 端末 | 方式 | 保存先 |
| --- | --- | --- |
| Windows 開発用 EC2 | HTTPS + Git Credential Manager (初回 push 時にブラウザーで GitHub にサインイン) | Windows 資格情報マネージャー。週末に EC2 ごと消える |
| Linux 開発用 EC2 | HTTPS + fine-grained personal access token (対象リポジトリのみ、Contents: Read and write、有効期限 7 日) | メモリ上のみ (`credential.helper 'cache --timeout=28800'`) |

Linux の設定:

```bash
git config --global credential.helper 'cache --timeout=28800'
git push     # Username: <GITHUB_USER> / Password: トークンを貼り付け (画面に表示されない)
```

- トークンをファイル、`.env`、シェル履歴、Claude Code への入力に残さない。
- SSH (22 番) は外向き SG で許可していないため使わない。

## 4. push 前の確認

```bash
git diff --cached --stat
git diff --cached | grep -nE '[0-9]{12}|vpc-|subnet-|sg-[0-9a-f]|arn:aws:iam::[0-9]|BEGIN .*PRIVATE KEY' || echo "no suspicious values"
```

- コミットの作者メールアドレスは GitHub の `noreply` アドレスを推奨 (Settings → Emails)。
- 誤って秘密情報を push した場合: その秘密情報を **即時に無効化** (鍵の再発行、トークン削除) してから履歴を修正する。履歴の修正だけでは不十分。
