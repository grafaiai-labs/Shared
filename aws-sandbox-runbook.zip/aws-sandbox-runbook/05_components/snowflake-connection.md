# Snowflake 接続

Snowflake のアカウント識別子と認証方式は未確定 (U-12、U-14)。本書の値はすべてプレースホルダー。

## 1. 原則

- Snowflake へはサーバーサイド (FastAPI、バッチ、CLI) からだけ接続する。React などブラウザー側へ資格情報を渡さない。
- 資格情報はファイルで渡し、環境変数・`.env`・Dockerfile・イメージ・ログに入れない。
- 資格情報は EC2 と一緒に週末に消えてよい設計にする (長期保管しない)。

## 2. 認証方式の選択

| 方式 | 推奨度 | 週次運用 | 注意 |
| --- | --- | --- | --- |
| キーペア (`keypair`) | **推奨** | 毎週 EC2 上で鍵を作り直し、公開鍵を Snowflake へ登録し直す | 公開鍵の登録権限が必要 (自分で登録できない場合は管理者へ依頼) |
| プログラムによるアクセストークン (`pat`) | 可 | 有効期限を 7 日以内で発行 | 既定でユーザーへのネットワークポリシー適用が必須 (SERVICE ユーザーは発行・利用とも、人のユーザーは利用時)。EC2 の Public IP は再構築ごとに変わるため、毎週ポリシーの更新が必要 |
| パスワード (`password`) | 非推奨 | - | Snowflake は人のユーザーの単一要素パスワード認証を段階的に廃止している。サービス用途には使わない |

## 3. キーペアの作成と登録

Linux EC2 (作業ユーザー `dev`) で作成する。秘密鍵はこの EC2 の外へ出さない。

```bash
install -d -m 700 ~/.snowflake-keys
cd ~/.snowflake-keys
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out rsa_key.p8
openssl pkey -in rsa_key.p8 -pubout -out rsa_key.pub
chmod 400 rsa_key.p8
# 登録用: ヘッダー行を除いた公開鍵本文 (公開鍵は秘密情報ではない)
grep -v -- '-----' rsa_key.pub | tr -d '\n'; echo
```

Snowsight (Windows 開発用 EC2 のブラウザー等) で、表示された公開鍵本文を登録する。

```sql
-- 既存の鍵を残したまま入れ替える場合は RSA_PUBLIC_KEY_2 を使い、確認後に古い方を UNSET する
ALTER USER <SNOWFLAKE_USER> SET RSA_PUBLIC_KEY = '<RSA_PUBLIC_KEY_BODY>';
DESC USER <SNOWFLAKE_USER>;   -- RSA_PUBLIC_KEY_FP が設定されたことを確認
```

アプリへ渡す (Pattern 03 / 04):

```bash
cd ~/work/<GITHUB_REPO>/04_patterns/03_docker-react-fastapi-snowflake
install -d -m 711 secrets
sudo install -o 10001 -g 10001 -m 400 ~/.snowflake-keys/rsa_key.p8 secrets/snowflake_rsa_key.p8
```

## 4. Snowflake CLI

```bash
# Linux (dev)。Windows は PowerShell で同じコマンド (パスは %USERPROFILE% 配下)
snow connection add \
  --connection-name sandbox \
  --account <SNOWFLAKE_ACCOUNT_IDENTIFIER> \
  --user <SNOWFLAKE_USER> \
  --role <SNOWFLAKE_ROLE> \
  --warehouse <SNOWFLAKE_WAREHOUSE> \
  --authenticator SNOWFLAKE_JWT \
  --private-key ~/.snowflake-keys/rsa_key.p8 \
  --no-interactive
snow connection test -c sandbox
snow sql -c sandbox -q "SELECT CURRENT_VERSION(), CURRENT_ROLE(), CURRENT_WAREHOUSE()"
```

設定は `~/.snowflake/config.toml` に保存される (秘密鍵の本文ではなくパスが記録される)。このファイルを Git へ入れない。

## 5. 検証用オブジェクトの例

自分の検証用 Snowflake アカウントで、管理者権限を持つ場合の例。組織のアカウントでは管理者の指示に従う。

```sql
USE ROLE SYSADMIN;
CREATE WAREHOUSE IF NOT EXISTS <SNOWFLAKE_WAREHOUSE>
  WAREHOUSE_SIZE = XSMALL AUTO_SUSPEND = 60 AUTO_RESUME = TRUE INITIALLY_SUSPENDED = TRUE;
CREATE DATABASE IF NOT EXISTS <SNOWFLAKE_DATABASE>;
CREATE SCHEMA IF NOT EXISTS <SNOWFLAKE_DATABASE>.<SNOWFLAKE_SCHEMA>;

USE ROLE SECURITYADMIN;
CREATE ROLE IF NOT EXISTS <SNOWFLAKE_ROLE>;
GRANT USAGE ON WAREHOUSE <SNOWFLAKE_WAREHOUSE> TO ROLE <SNOWFLAKE_ROLE>;
GRANT USAGE ON DATABASE <SNOWFLAKE_DATABASE> TO ROLE <SNOWFLAKE_ROLE>;
GRANT USAGE, CREATE TABLE ON SCHEMA <SNOWFLAKE_DATABASE>.<SNOWFLAKE_SCHEMA> TO ROLE <SNOWFLAKE_ROLE>;
GRANT SELECT, INSERT, UPDATE ON FUTURE TABLES IN SCHEMA <SNOWFLAKE_DATABASE>.<SNOWFLAKE_SCHEMA> TO ROLE <SNOWFLAKE_ROLE>;

CREATE USER IF NOT EXISTS <SNOWFLAKE_USER>
  TYPE = SERVICE DEFAULT_ROLE = <SNOWFLAKE_ROLE> DEFAULT_WAREHOUSE = <SNOWFLAKE_WAREHOUSE>;
GRANT ROLE <SNOWFLAKE_ROLE> TO USER <SNOWFLAKE_USER>;
```

- Pattern 03 (参照のみ) だけなら `CREATE TABLE`、`INSERT`、`UPDATE` は不要。
- ダミーデータのみを扱う。本番データ・個人情報を入れない。

## 6. 接続できないとき

[トラブルシューティング](../06_troubleshooting/README.md#snowflake-へ接続できない) と、Pattern 03 の [エラーコード表](../04_patterns/03_docker-react-fastapi-snowflake/README.md#エラーコード) を参照。
