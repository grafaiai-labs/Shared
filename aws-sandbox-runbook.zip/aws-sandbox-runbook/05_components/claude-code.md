# Claude Code

## 1. 前提

- 個人契約の Claude Code を使う。業務ソースコード、社内情報、顧客情報を扱わない。
- 固定版 2.1.284 を導入し、自動更新を止めている (`DISABLE_AUTOUPDATER=1`)。更新手順は [バージョン固定](../02_common-design/version-pinning.md)。

| 端末 | 導入場所 | 実行ユーザー |
| --- | --- | --- |
| Windows 開発用 EC2 | `C:\DevTools\npm-global\claude.cmd` | Administrator |
| Linux 開発用 EC2 | `/home/dev/.npm-global/bin/claude` | `dev` (sudo なし) |

## 2. 導入確認

```bash
claude --version     # 2.1.284 (Claude Code)
```

## 3. 認証

- 認証情報は各 EC2 のユーザーホームに保存され、週末に EC2 ごと消える。毎週ログインし直す。
- 社内 PC のブラウザーで個人アカウントへログインしてよいかは未確定 (Q-07)。確定までは **Windows 開発用 EC2 のブラウザー** で行う。
- Linux (SSM セッション) ではブラウザーを開けないため、`claude` の初回起動時に表示される URL を Windows 開発用 EC2 のブラウザーで開き、表示されたコードを SSM セッションへ貼り付ける。

## 4. 秘密情報を読ませない設定

プロジェクトのルートに `.claude/settings.json` を置き、秘密情報のファイルを読み取り禁止にする。このファイルは秘密情報を含まないため Git 管理してよい。このランブック自体にも [同じ設定](../.claude/settings.json) を置いている。

```json
{
  "permissions": {
    "deny": [
      "Read(**/.env)",
      "Read(**/secrets/**)",
      "Read(**/*.tfvars)",
      "Read(**/*.tfstate*)",
      "Read(**/*.tfplan)",
      "Read(**/backend.hcl)",
      "Read(**/*.pem)",
      "Read(**/*.p8)",
      "Read(**/*.key)",
      "Read(**/*.local.json)"
    ]
  }
}
```

- `.env.example` と `*.tfvars.example` は読み取り可能なままにする (ダミー値のみ)。
- 個人用の上書き設定 `.claude/settings.local.json` は `.gitignore` 対象。

## 5. 使い方の注意

- Claude Code の提案する `terraform apply`、`docker system prune`、`rm -rf` 等の破壊的操作は、自分で内容を確認してから実行する。
- Runner では Claude Code を使わない (Runner には導入していない)。IaC の編集は社内 PC で行う。
- 出力やログを Claude Code へ貼り付けるときは、アカウント ID、IP、バケット名を `<...>` へ置き換える。
