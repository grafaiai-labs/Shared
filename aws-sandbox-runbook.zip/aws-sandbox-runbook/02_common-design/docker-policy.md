# Docker 方針

## 1. 実行場所

| 場所 | Docker | 理由 |
| --- | --- | --- |
| Linux Docker 開発用 EC2 (Pattern 02) | **採用** (Docker Engine + Compose Plugin) | Web アプリ検証の標準実行環境 |
| Windows 開発用 EC2 (Pattern 01) | 不採用 | Windows Server 上の Docker Desktop はライセンス・サポート・入れ子仮想化の制約があり、Linux EC2 で代替できる |
| 社内 PC | 不採用 | 業務端末へ検証用ランタイムを入れない |

## 2. 規則

| 規則 | 実装 |
| --- | --- |
| Snowflake 自体はコンテナ化しない | Snowflake へは FastAPI / バッチからサーバーサイドで接続する |
| Dockerfile / Compose に秘密情報を書かない | 資格情報は `./secrets/` (Git 管理外) を読み取り専用でマウント。`.env` にはファイルパスだけを書く |
| イメージへ秘密情報を焼き込まない | `.dockerignore` で `.env`、`secrets/`、`*.p8`、`*.pem` を除外 |
| Docker ソケットを外部公開しない | `daemon.json` に `hosts` を書かない。TCP 2375/2376 の待ち受けを起動時に検査。Compose で `/var/run/docker.sock` をマウントしない |
| 非 root で実行する | API: UID 10001、フロントエンド: nginx-unprivileged (UID 101)、ETL: UID 10001 |
| ベースイメージを固定する | タグとダイジェストの両方 (`image:tag@sha256:...`) |
| 最小限のレイヤー | マルチステージビルド。実行イメージにはビルドツール・テストを含めない |
| Healthcheck | Dockerfile の `HEALTHCHECK`。Compose の `depends_on: condition: service_healthy` |
| 実行時の制限 | `read_only: true`、`cap_drop: [ALL]`、`no-new-privileges`、`tmpfs: /tmp`、メモリ・PID 上限 |
| 公開ポート | 既定で `127.0.0.1` のみにバインド |
| ログ | JSON 構造化ログを標準出力へ。`json-file` ドライバーでローテーション (10 MB × 3) |
| 永続データをコンテナ・EC2 内だけに置かない | 正本は Git (コード) と Snowflake (データ)。EC2 上のボリュームは週末に消える前提 |

## 3. Docker グループと非 root 利用

作業ユーザー (`dev`) を `docker` グループへ追加し、`sudo` なしで Docker を操作する。

- `docker` グループへの所属は実質的に root 相当の権限である。`dev` には `sudo` 権限を与えず、Claude Code などのツールもこのユーザーで実行する。
- Rootless Docker は Amazon Linux 2023 の標準パッケージでは提供されないため、初期は採用しない。
  - 切替条件: Docker 公式の rootless 版を AL2023 で安定して導入できると確認できた場合、またはコンテナ内で信頼できないコードを実行する必要が生じた場合。

## 4. ローカル検証用 DB

必要な場合は Compose にコンテナとして追加してよい (例: PostgreSQL)。ただし:

- ポートは公開しない (Compose 内部ネットワークのみ)。必要なら `127.0.0.1` にバインド。
- データは検証用のダミーに限る。週末に消えてよいものだけを置く。
- 本番相当の DB が試験対象の場合は、コンテナではなく RDS (`db.t3.*`、100 GB 以下) を検討する。
