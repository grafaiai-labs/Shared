# IAM 設計

## 1. 原則

- IAM ユーザー、IAM グループ、アクセスキーは作成しない (作成もできない)。
- すべての AWS 操作は EC2 インスタンスロールの一時認証情報で行う。
- IAM ロールを作成するときは必ず Permissions Boundary `ChildAccountRoleBoundary` を適用する。
- 最小権限を目標とするが、Boundary と C-MAC の制約を優先する (Boundary が拒否するものは許可しても使えない)。

## 2. ロール一覧

| ロール | 作成方法 | 信頼 | 付与する権限 | Boundary |
| --- | --- | --- | --- | --- |
| `<owner>-tfrunner-role-01` | 手動 (コンソール) | `ec2.amazonaws.com` ([trust](../04_patterns/00_terraform-bootstrap/iam/runner-trust-policy.json)) | `AmazonSSMManagedInstanceCore` + [base](../04_patterns/00_terraform-bootstrap/iam/runner-base-policy.json) + [s3](../04_patterns/00_terraform-bootstrap/iam/runner-s3-prefix-policy.json) + [workload](../04_patterns/00_terraform-bootstrap/iam/runner-workload-policy.json) | 必須 (作成画面で設定) |
| `<owner>-windev-role-01` | Terraform ([ssm-instance-role](../08_iac/modules/ssm-instance-role/main.tf)) | `ec2.amazonaws.com` | `AmazonSSMManagedInstanceCore` + 退避用 S3 プレフィックス | 必須 (`permissions_boundary_arn` 変数) |
| `<owner>-dockdev-role-01` | Terraform (同上) | `ec2.amazonaws.com` | 同上 | 必須 |

## 3. Permissions Boundary の適用箇所

| 箇所 | 方法 | 検証 |
| --- | --- | --- |
| Runner ロール (手動) | IAM コンソールのロール作成で「アクセス許可の境界を設定」→ `ChildAccountRoleBoundary` | ロール詳細 → 「アクセス許可」タブ → 「アクセス許可の境界」に表示される |
| ワークロードロール (Terraform) | `aws_iam_role.permissions_boundary = var.permissions_boundary_arn` | Module テスト (`terraform test`) で必須化を検証。`terraform plan` で `permissions_boundary` を確認 |
| Runner が作るロールへの強制 | Runner の workload ポリシーで `iam:CreateRole` に条件 `iam:PermissionsBoundary = <PERMISSIONS_BOUNDARY_ARN>` | Boundary なしの作成は AccessDenied になる |
| Boundary の削除防止 | base ポリシーで `iam:DeleteRolePermissionsBoundary` を Deny | |

## 4. Runner ポリシーの構成

| ポリシー | 目的 | 主な制限 |
| --- | --- | --- |
| `AmazonSSMManagedInstanceCore` (AWS 管理) | Session Manager 接続 | AWS 管理ポリシー |
| base | 読み取り (Describe) と安全柵 | 東京以外の Deny、予約名への IAM 操作 Deny、IAM ユーザー / アクセスキー作成 Deny |
| s3-prefix | Backend と IaC 取得 | `state/` の読み書き、`iac/` の読み取りのみ。バケット設定変更と版削除を Deny |
| workload | Pattern 01 / 02 のリソース作成 | タグ `Owner` 一致、許可インスタンスタイプ、EBS タイプ・サイズ、対象 VPC、Amazon 所有 AMI、ロール名 `<owner>-*`、Boundary 必須、付与できる管理ポリシーは SSM Core のみ |

## 5. ワイルドカードを使っている箇所と理由

| 箇所 | 内容 | 理由 | 想定リスク | 将来の縮小方法 |
| --- | --- | --- | --- | --- |
| base: `ec2:Describe*` on `*` | EC2 の参照系 | Describe 系 API はリソース単位の権限指定に対応しておらず、Terraform は plan/refresh で多数の Describe を呼ぶ | 同一アカウント内の EC2 構成情報の読み取り | CloudTrail で実際に呼ばれた API を確認し、`ec2:DescribeInstances` など個別アクションへ列挙する。リージョン条件は付与済み |
| base: `sts:DecodeAuthorizationMessage` on `*` | AccessDenied の詳細確認 | リソース指定に対応しない | 権限エラー時のポリシー評価情報の閲覧 | IAM 設計が安定したら削除する |
| workload: `arn:aws:ec2:ap-northeast-1:<AWS_ACCOUNT_ID>:*/*` | 既存 EC2 リソースの変更・削除 | Terraform が扱うリソース種別 (instance / security-group / security-group-rule / key-pair / volume) が複数ある | 同じ `Owner` タグを持つ他リソースの変更 | リソース種別ごとに ARN を列挙する。`Owner` タグ条件で他者のリソースは対象外 |
| workload: `ec2:CreateTags` on `*/*` | 作成時のタグ付け | タグ付けは作成アクションと同時に全リソース種別へ発生する | なし (条件 `ec2:CreateAction` で作成時に限定) | 現状で十分 |
| workload: `role/<owner>-*` | ワークロードロールの管理 | パターン追加ごとにロール名が増える | 同じ接頭辞の他ロールの変更 | パターンごとに完全なロール名を列挙する |
| workload: `iam:PassRole` の `StringEqualsIfExists` | インスタンスプロファイルへのロール追加 | `AddRoleToInstanceProfile` の評価では `iam:PassedToService` が存在しないため | EC2 以外へのロール受け渡し | 初回適用後に CloudTrail で確認し、`StringEquals` へ変更できるか検証する |
| s3-prefix: `state/*` | 全パターンの State | パターンごとに State キーが異なる | 他パターンの State の上書き | パターンごとに `state/<pattern>/*` を列挙する |

## 6. ワークロードロールの権限

- `AmazonSSMManagedInstanceCore`: Session Manager と Run Command。
- 退避用 S3: `s3://<BOOTSTRAP_BUCKET_NAME>/transfer/<owner>-<purpose>/` だけを読み書き (`ListBucket` はプレフィックス条件付き)。
- それ以外の AWS 権限は付与しない。Snowflake や GitHub の認証は AWS の IAM とは独立している。

## 7. 権限不足 (AccessDenied) の調べ方

1. エラーメッセージの `Action` と `Resource` を確認する。
2. `Encoded authorization failure message` がある場合は Runner で次を実行し、どのステートメントで拒否されたかを確認する。

   ```bash
   aws sts decode-authorization-message --encoded-message '<ENCODED_MESSAGE>' --query DecodedMessage --output text | jq .
   ```

3. Boundary 側で拒否されている場合は、ポリシーを広げても解決しない。管理者へ確認する。
4. 出力には ARN やアカウント ID が含まれるため、共有前に `<...>` へ置き換える。
