# ネットワーク設計

VPC / Subnet / NACL は利用者が作成・変更できないため、既存のものを参照するだけとする。

## 1. 全体像

```mermaid
flowchart LR
  subgraph Corp["社内"]
    PC["社内 PC<br/>ブラウザー / VS Code"]
    SGW["SMART Gateway"]
  end
  subgraph AWS["サンドボックス VPC (ap-northeast-1)"]
    subgraph Pub["Public Subnet"]
      WIN["Windows 開発用 EC2<br/>RDP 3389 (SGW のみ)"]
      RUN["Terraform Runner<br/>インバウンドなし"]
      LNX["Linux Docker EC2<br/>インバウンドなし"]
    end
    VPCE["SSM VPC Endpoint<br/>(既存)"]
  end
  NET["インターネット<br/>GitHub / Registry / Snowflake"]
  PC -- "HTTPS (AWS コンソール)" --> AWSCON["AWS コンソール<br/>Session Manager"]
  PC --> SGW -- "RDP" --> WIN
  AWSCON -. "SSM" .-> VPCE
  VPCE -. "SSM" .-> RUN
  VPCE -. "SSM" .-> LNX
  RUN -- "HTTPS 443" --> NET
  LNX -- "HTTPS 443" --> NET
  WIN -- "HTTPS 443 / HTTP 80" --> NET
  WIN -. "任意: アプリ確認 8080 (SG 参照)" .-> LNX
```

## 2. 外向き通信の案と切替条件

Private Subnet から外部へ接続できることは確認されていない (未確定事項 Q-04)。外向き通信が必要な EC2 は次の 2 案を区別する。

| 項目 | 案 A: Public Subnet + Public IPv4 (**初期採用**) | 案 B: Private Subnet + NAT または承認済み Proxy |
| --- | --- | --- |
| 前提 | Public Subnet のルートに `0.0.0.0/0 → igw-` がある | Private Subnet のルートに NAT、または承認済み Proxy がある |
| インバウンド | SG で原則なし (Windows は RDP のみ) | なし |
| 外向き | インターネットゲートウェイ経由で直接 | NAT / Proxy 経由 |
| Terraform 設定 (Pattern 02) | `subnet_mode = "public"` | `subnet_mode = "private"`、`proxy_url` (Proxy の場合) |
| 利点 | 追加コンポーネント不要。すぐ使える | Public IPv4 が不要。攻撃面が小さい |
| 欠点 | Public IPv4 の料金。SG 設定ミス時の露出 | NAT は利用者が作成できない可能性。Proxy は各ツールへ設定が必要 |

**切替条件** (案 A → 案 B): 次のすべてを満たしたとき。

1. smoke-test の `subnet_routes` で Private Subnet の `default_route_via` が `nat`、または承認済み Proxy の URL が提示された。
2. その経路で `releases.hashicorp.com`、`registry.terraform.io`、`github.com`、コンテナレジストリ、Snowflake へ到達できることを確認した。
3. SSM Session Manager が Private Subnet から接続できることを確認した (既存の SSM VPC Endpoint 経由)。

**案 A の残存リスクと対策**

| リスク | 対策 |
| --- | --- |
| SG の誤設定でポートが公開される | Terraform の変数検証で `0.0.0.0/0` の RDP、Docker API ポートを拒否。Linux はインバウンドなしが既定 |
| Public IP が変わる (停止・起動) | RDP 接続前に毎回コンソールで Public IP を確認する |
| コンテナから IMDS 経由でロール資格情報を取得される | IMDSv2 必須 + hop limit 1 |
| Docker API の公開 | TCP で待ち受けない設定とし、起動時スクリプトで検査 |

## 3. Security Group 基準

| 対象 | インバウンド | アウトバウンド | 作成方法 |
| --- | --- | --- | --- |
| Terraform Runner | なし | TCP 443 → 0.0.0.0/0 | 手動 |
| Windows 開発用 EC2 | TCP 3389 ← `<RDP_ALLOWED_CIDR>` | TCP 443、TCP 80 → 0.0.0.0/0 | Terraform |
| Linux Docker EC2 | なし (任意で Windows SG からアプリ確認ポートのみ) | TCP 443 → 0.0.0.0/0 | Terraform |

- アウトバウンドは既定の「全許可」を削除し、必要なポートだけにする。
- Windows の TCP 80 は証明書失効確認 (CRL / OCSP) のため。不要と確認できたら `allow_http_egress = false` にする。
- DNS (VPC リゾルバー)、時刻同期 (169.254.169.123)、IMDS (169.254.169.254) は SG の影響を受けない。
- SSM Session Manager はインバウンドを必要としない (エージェントから Endpoint への外向き 443)。
- RDP、SSH、DB ポートをインターネット全体 (`0.0.0.0/0`) へ公開しない。

## 4. Public Subnet から外部へ接続できない場合

未確定事項 Q-02 が「不可」と判明した場合の代替策。

| 必要な通信 | 代替策 |
| --- | --- |
| Terraform CLI の取得 | 社内 PC で公式 ZIP と `SHA256SUMS` を取得して検証 → 非公開 S3 経由で Runner へ搬送 |
| Terraform Provider の取得 | 社内 PC 以外に Terraform を実行できる場所がないため、`terraform providers mirror` が使えない。管理者へ Registry への到達可否を確認し、解決するまで IaC の実行は保留 |
| OS パッケージ | AL2023 のリポジトリは S3 上にあるため、S3 Gateway Endpoint があれば取得できる場合がある。管理者へ確認 |
| GitHub | コードは非公開 S3 経由で搬送する |
