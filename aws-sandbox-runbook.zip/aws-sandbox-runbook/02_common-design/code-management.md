# コード管理

## 1. 流れ

```mermaid
flowchart LR
  VS["VS Code<br/>(社内 PC)"] --> GIT["ローカル Git<br/>正本 / リモートなし"]
  GIT -- "git bundle / ZIP" --> BOX["Box Drive<br/>バックアップ"]
  GIT -- "package-iac (tfvars 含む)" --> ZIP["非公開 IaC ZIP"]
  ZIP -- "コンソールでアップロード" --> S3["非公開 S3<br/>iac/"]
  S3 -- "iac-fetch" --> RUN["Terraform Runner"]
  GIT -- "export-public (許可リストのみ)" --> PUB["個人 Public GitHub"]
  PUB -- "git clone" --> LNX["Linux / Windows 開発用 EC2"]
```

## 2. ローカル Git

- 文字コード UTF-8、改行 LF (`.gitattributes` で `*.ps1` のみ CRLF)。
- リモートは設定しない (`git remote -v` が空であること)。
- コミット前に [check-repo.sh](../09_scripts/check-repo.sh) を実行する (リンク、書式、秘密情報らしい値の検査)。
- `.gitignore` 対象 (State、tfvars、`backend.hcl`、`.env`、鍵、ZIP) が追跡されていないことを確認する。

```bash
git status --short
git check-ignore -v 04_patterns/01_windows-dev-ec2/terraform/terraform.tfvars 08_iac/bootstrap/backend.hcl
```

## 3. Box Drive へのバックアップ

Git Bundle は履歴ごと 1 ファイルにまとめたもの。Git 管理外の tfvars / `backend.hcl` は含まれない。

```bash
# リポジトリのルートで実行。出力先はリポジトリの外 (<BOX_BACKUP_DIR>) にする
git bundle create "<BOX_BACKUP_DIR>/aws-sandbox-runbook-$(date +%Y%m%d).bundle" --all
git bundle verify "<BOX_BACKUP_DIR>/aws-sandbox-runbook-$(date +%Y%m%d).bundle"
```

```powershell
# Windows (PowerShell)
$d = Get-Date -Format yyyyMMdd
git bundle create "<BOX_BACKUP_DIR>\aws-sandbox-runbook-$d.bundle" --all
git bundle verify "<BOX_BACKUP_DIR>\aws-sandbox-runbook-$d.bundle"
```

復元:

```bash
git clone "<BOX_BACKUP_DIR>/aws-sandbox-runbook-YYYYMMDD.bundle" aws-sandbox-runbook
```

tfvars / `backend.hcl` を含めて退避したい場合は、次節の IaC ZIP を Box Drive にも保存する (State は含まれない)。

## 4. 非公開 IaC ZIP

Runner へ渡す IaC 一式。Git 管理対象 + Git 管理外の設定ファイル (`backend.hcl`、`terraform.tfvars`) を含み、State / Plan / `.terraform/` は含まない。

```bash
# Git Bash / Linux / macOS
09_scripts/package-iac.sh
```

```powershell
# Windows PowerShell
powershell -NoProfile -ExecutionPolicy Bypass -File .\09_scripts\New-IacPackage.ps1
```

出力: `dist/iac/iac-<日時>.zip` と SHA256。ZIP は `.gitignore` 対象。
アップロードと取得の手順は [S3 による搬送](../05_components/s3-transfer.md) を参照。

## 5. Public GitHub への抽出

Public 可のディレクトリだけを別フォルダーへコピーし、C-MAC 固有語・ID 形式の値・秘密情報らしい値がないことを検査する。

```bash
09_scripts/export-public.sh <EXPORT_DIR>
cd <EXPORT_DIR>
git init && git add . && git commit -m "Initial public import"
git remote add origin https://github.com/<GITHUB_USER>/<GITHUB_REPO>.git
git push -u origin main
```

- 抽出対象は [export-public.sh](../09_scripts/export-public.sh) の許可リストで管理する。対象を増やすときは [公開可否表](../01_constraints/security-boundary.md#2-ディレクトリごとの公開可否) も更新する。
- 抽出先の README は Public 向けに別途書く (ランブックの README は C-MAC 情報を含むため抽出しない)。
- push 前に `git log -p` で差分を目視確認する。
