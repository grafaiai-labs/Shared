# バージョン固定

2026-09-29 時点で公式配布元を確認し、安定版を固定した。バージョンを変えるときは、この表と該当ファイルを同時に更新し、[CHANGELOG](../CHANGELOG.md) に記録する。

## 1. 固定一覧

### インフラ・ツール

| 対象 | バージョン | 検証方法 | 定義箇所 |
| --- | --- | --- | --- |
| Terraform CLI | 1.16.4 | HashiCorp PGP 署名 (`C874 011F 0AB4 0511 0D02 1055 3436 5D94 72D7 468F`) + 固定 SHA256 | [runner-setup.sh](../04_patterns/00_terraform-bootstrap/scripts/runner-setup.sh)、各 `versions.tf` |
| AWS Provider | 6.66.0 | `.terraform.lock.hcl` のハッシュ | 各 Root Module の `versions.tf` / `.terraform.lock.hcl` |
| Docker Engine | AL2023 リポジトリの `docker` (確認時 25.0.x) | dnf の署名検証 | [bootstrap-linux-docker.sh](../04_patterns/02_linux-docker-dev/scripts/bootstrap-linux-docker.sh) |
| Docker Compose Plugin | v5.5.1 | 固定 SHA256 | 同上 |
| Docker Buildx Plugin | v0.37.1 | 固定 SHA256 | 同上 |
| Node.js (Linux / Windows) | 24.21.0 (LTS) | 固定 SHA256 (Windows は + Authenticode) | 同上、[Initialize-WindowsDev.ps1](../04_patterns/01_windows-dev-ec2/scripts/Initialize-WindowsDev.ps1) |
| Python (Linux) | AL2023 の `python3.13` | dnf の署名検証 | bootstrap-linux-docker.sh |
| Python (Windows) | 3.13.15 | 固定 SHA256 + Authenticode | Initialize-WindowsDev.ps1 |
| Git for Windows | 2.56.0 | 固定 SHA256 + Authenticode | 同上 |
| VS Code (Windows, System) | 1.139.1 | 固定 SHA256 + Authenticode | 同上 |
| AWS CLI v2 (Windows) | 2.37.5 | 固定 SHA256 + Authenticode | 同上 |
| Claude Code | 2.1.284 (npm `@anthropic-ai/claude-code`) | npm レジストリの integrity | 同上、bootstrap-linux-docker.sh |
| Snowflake Connector for Python | 4.7.5 | pip | 同上 |
| Snowflake CLI | 3.28.0 | pip | 同上 |

### コンテナ・アプリ

| 対象 | バージョン | 定義箇所 |
| --- | --- | --- |
| Python ベースイメージ | `python:3.13.15-slim-trixie@sha256:7c61056e…` | API / ETL の `Dockerfile` |
| Node ベースイメージ (ビルド) | `node:24.21.0-alpine3.24@sha256:ebfe2f90…` | フロントエンドの `Dockerfile` |
| nginx ベースイメージ (配信) | `nginxinc/nginx-unprivileged:1.30.5-alpine3.24@sha256:ed04ec1f…` | 同上 |
| FastAPI / Uvicorn / Pydantic / pydantic-settings | 0.141.1 / 0.54.0 / 2.13.5 / 2.15.0 | `api/requirements.in` → ハッシュ付き `requirements.txt` |
| React / React DOM | 19.3.0 | `frontend/package.json` + `package-lock.json` |
| Vite / @vitejs/plugin-react / TypeScript / Vitest | 8.3.1 / 6.1.1 / 6.0.3 / 5.0.2 | 同上 |

## 2. 更新手順

### Terraform CLI

1. <https://releases.hashicorp.com/terraform/> で新しい安定版を確認する (alpha / beta / rc を除く)。
2. `terraform_<ver>_SHA256SUMS` から `linux_amd64.zip` の値を取得する。
3. `runner-setup.sh` の `TERRAFORM_VERSION` と `TERRAFORM_ZIP_SHA256`、各 Root Module の `required_version` を更新する。

### AWS Provider

```bash
cd 04_patterns/02_linux-docker-dev/terraform    # Root Module ごとに実施
# versions.tf の version を更新してから
terraform init -backend=false -upgrade
terraform providers lock -platform=linux_amd64 -platform=darwin_arm64 -platform=darwin_amd64 -platform=windows_amd64
terraform validate && terraform test
```

### ダウンロード物の SHA256

公式が公開する値を使う。

| 対象 | 取得元 |
| --- | --- |
| Docker Compose / Buildx | GitHub Release の `checksums.txt` |
| Node.js | `https://nodejs.org/dist/v<ver>/SHASUMS256.txt` |
| Git for Windows | GitHub Release のアセットの `digest` |
| VS Code | `https://update.code.visualstudio.com/api/update/win32-x64/stable/latest` の `sha256hash` |
| Python (Windows) | python.org のリリースファイル一覧 (`sha256_sum`) |
| AWS CLI MSI | 公式の SHA256 公開がないため、取得したファイルの Authenticode 署名 (Amazon) を確認したうえで算出値を固定する |

### Python 依存

```bash
cd 04_patterns/03_docker-react-fastapi-snowflake/api
# requirements.in を編集してから
uv pip compile requirements.in --universal --python-version 3.13 --generate-hashes -o requirements.txt
uv pip compile requirements-dev.in --universal --python-version 3.13 --generate-hashes -o requirements-dev.txt
docker build --target test .
```

### npm 依存

```bash
cd 04_patterns/03_docker-react-fastapi-snowflake/frontend
# package.json を編集してから、固定した Node イメージの中でロックを再生成する
docker run --rm -v "$PWD":/app -v /app/node_modules -w /app node:24.21.0-alpine3.24 npm install
docker build .
```

### ベースイメージのダイジェスト

```bash
docker buildx imagetools inspect python:3.13.15-slim-trixie --format '{{json .Manifest}}' | jq -r .digest
```

## 3. 自動更新を止めているもの

- Claude Code: 環境変数 `DISABLE_AUTOUPDATER=1` (Linux: `/etc/profile.d/dev-tools.sh`、Windows: システム環境変数)。
- VS Code の自動更新は止めていない。週末に EC2 ごと削除されるため、翌週は固定版から再導入される。
