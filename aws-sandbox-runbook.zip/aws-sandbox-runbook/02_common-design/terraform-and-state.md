# Terraform と State

## 1. 構成

```text
04_patterns/01_windows-dev-ec2/terraform/   Root Module (State: state/01_windows-dev-ec2/terraform.tfstate)
04_patterns/02_linux-docker-dev/terraform/  Root Module (State: state/02_linux-docker-dev/terraform.tfstate)
08_iac/bootstrap/smoke-test/                Root Module (疎通確認用。AWS リソースを作らない)
08_iac/bootstrap/backend.hcl.example        Backend 共通設定の雛形 (bucket のみ)
08_iac/modules/                             再利用 Module (環境非依存、Public 可)
```

- Root Module はパターンごとに独立した State を持つ。1 つを destroy しても他へ影響しない。
- Module は `required_version` / `required_providers` を互換範囲で宣言し、**正確な固定は Root Module で行う**。
- `.terraform.lock.hcl` は Root Module ごとに Git 管理する。Runner (`linux_amd64`) と検証用端末のハッシュを含めて生成している。
- パターンの一覧、State キー、依存関係、適用・破棄の順序は [08_iac/patterns](../08_iac/patterns/README.md) を参照。

## 2. Backend

各 Root Module の `backend.tf`:

```hcl
terraform {
  backend "s3" {
    key          = "state/<pattern>/terraform.tfstate"
    region       = "ap-northeast-1"
    encrypt      = true
    use_lockfile = true
  }
}
```

バケット名だけを Git 管理外の `08_iac/bootstrap/backend.hcl` に書き、`terraform init` で渡す。

```bash
terraform init -backend-config=../../../08_iac/bootstrap/backend.hcl
```

| 要件 | 実現方法 |
| --- | --- |
| 暗号化 | バケットの既定暗号化 SSE-S3 + Backend の `encrypt = true` |
| バージョニング | バケットで有効化 (手動作成時) |
| ロック | `use_lockfile = true` (S3 上の `<key>.tflock`)。DynamoDB は使わない |
| Public Access Block | バケットで 4 項目すべて有効 |
| TLS 強制 | バケットポリシー [bootstrap-bucket-policy.json](../04_patterns/00_terraform-bootstrap/iam/bootstrap-bucket-policy.json) |

SSE-KMS (カスタマー管理キー) を使わない理由: KMS キーも週末に削除され、毎週の手動作成対象が増える。SSE-S3 で要件 (保存時暗号化) を満たす。

## 3. State の寿命

```mermaid
stateDiagram-v2
  [*] --> 空: 月曜 Bootstrap (S3 作成)
  空 --> 使用中: terraform apply
  使用中 --> 使用中: plan / apply
  使用中 --> 空: 週末前 terraform destroy
  空 --> [*]: S3 手動削除 / 定期削除
```

- S3 上の State は **実行中の作業用** であり、正本ではない。正本はローカル Git の IaC と tfvars である。
- 週末前に全ワークロードを destroy し、`terraform state list` が空であることを確認してからバケットを削除する。
- 週明けは空の State から再構築する (前週の State を復元しない)。

## 4. 実行規律

| 規則 | 手順 |
| --- | --- |
| Plan を確認せずに Apply しない | `terraform plan -out=run.tfplan` → 差分を読む → `terraform apply run.tfplan` |
| Plan ファイルを残さない | 適用後に `rm -f run.tfplan`。`*.tfplan` は `.gitignore` 対象 |
| 誤アカウントに適用しない | Provider の `allowed_account_ids = [var.aws_account_id]` |
| 誤リージョンに適用しない | `aws_region` 変数は `ap-northeast-1` 以外を拒否 |
| 入力検証 | 変数の `validation` と `terraform test` (モック Provider) |
| 書式 | `terraform fmt -check -recursive` |

Plan で確認する観点:

- `destroy` / `replace` (`-/+`) が意図したものか。特に EC2 の再作成は作業中データを失う。
- Security Group の `cidr_ipv4` に広すぎる範囲がないか。
- IAM ロールに `permissions_boundary` が設定されているか。
- EBS の `volume_type` が `gp2`、`volume_size` が 100 以下か。

## 5. State の Box Drive 保存

未確定事項 Q-01 が確定するまで、**State を Box Drive へ保存しない**。ダウンロードもしない。
State を失っても、週末に AWS 側のリソースも削除されるため、空の State から再構築すれば整合する。

週の途中で State を失った場合 (誤削除など) は [トラブルシューティング](../06_troubleshooting/README.md#state-を失ったs3-バケットが消えた) を参照する。

## 6. Terraform を実行する場所

社内 PC と CloudShell では実行できないため、Terraform Runner EC2 だけで実行する ([Pattern 00](../04_patterns/00_terraform-bootstrap/README.md))。
ローカル (社内 PC 以外の個人端末など) で行ってよいのは、AWS に接続しない `fmt` / `validate` / `test` のみ。
