# 命名とタグ

## 1. 命名規則

```text
<owner>-<purpose>-<resource>-<sequence>
```

| 要素 | 規則 | 例 |
| --- | --- | --- |
| `owner` | 英小文字で始まる英小文字・数字 3〜16 文字。ハイフン不可 | `<OWNER>` |
| `purpose` | 英小文字で始まる英小文字・数字 2〜16 文字。ハイフン不可 | `tfrunner` / `windev` / `dockdev` |
| `resource` | リソース種別の短縮名 | `ec2` / `sg` / `role` / `key` / `s3` |
| `sequence` | 2 桁の連番 | `01` |

### 予約名の回避

管理用に予約された `CP-SandD*-D-*` に該当する名前を作成しない。

- IAM ロール名は大文字・小文字を区別せずに一意となるため、`cp-sandd01-d-...` のような小文字表記も衝突しうる。
- 本規則では先頭要素 `owner` を **3 文字以上・ハイフンなし** に制限しているため、先頭が `CP-` (2 文字 + ハイフン) となる予約名とは構造的に一致しない。
- Terraform の Root Module は `owner` をこの規則で検証する。コンソールで手動作成する Bootstrap リソースも同じ規則で命名する。
- Runner の IAM ポリシーは、`CP-SandD*` への IAM 操作を明示的に Deny する ([runner-base-policy.json](../04_patterns/00_terraform-bootstrap/iam/runner-base-policy.json))。

### リソース名の一覧

| リソース | 名前 | 作成方法 |
| --- | --- | --- |
| Bootstrap S3 バケット | `<owner>-tfstate-s3-<sequence>-<random6>` (例の形式のみ。英小文字・数字・ハイフン) | 手動 |
| Runner 用 IAM ロール | `<owner>-tfrunner-role-01` | 手動 |
| Runner 用カスタマー管理ポリシー | `<owner>-tfrunner-base-policy-01` / `-s3-policy-01` / `-workload-policy-01` | 手動 |
| Runner 用 SG | `<owner>-tfrunner-sg-01` | 手動 |
| Runner EC2 | `<owner>-tfrunner-ec2-01` | 手動 |
| Windows 開発用 EC2 一式 | `<owner>-windev-{ec2,sg,role,key}-01` | Terraform |
| Linux Docker 開発用 EC2 一式 | `<owner>-dockdev-{ec2,sg,role}-01` | Terraform |

## 2. 必須タグ

| キー | 値 | 備考 |
| --- | --- | --- |
| `Name` | 上記の名前 | |
| `Owner` | `<owner>` | Runner の IAM 条件 (`aws:RequestTag/Owner`、`ec2:ResourceTag/Owner`) に使う |
| `Purpose` | `<purpose>` | |
| `Environment` | `sandbox` | 固定 |
| `ManagedBy` | `terraform` または `manual-bootstrap` | Terraform 管理か手動かを区別し、週末前の削除漏れ確認に使う |
| `ExpiresAt` | `YYYY-MM-DD` (直近の日曜日) | 削除期限 |

- Terraform 管理のリソースは、Provider の `default_tags` で `Owner` / `Purpose` / `Environment` / `ManagedBy` / `ExpiresAt` を自動付与し、`Name` は Module 内で付与する。
- 手動作成の Bootstrap リソースはコンソールの「タグ」欄で 6 つすべてを入力する (`ManagedBy = manual-bootstrap`)。
- S3 バケットはバケットのタグ (プロパティ → タグ) に設定する。
