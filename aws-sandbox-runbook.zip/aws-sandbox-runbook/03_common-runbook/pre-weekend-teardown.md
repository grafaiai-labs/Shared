# 週末前の破棄手順

実施時期: **金曜の作業終了時**。遅くとも **日曜 21:00** までに完了させる (22:00 からサインイン不可)。

> [!CAUTION]
> この手順は EC2、EBS、IAM ロール、S3 バケットを **完全に削除** する。削除したものは復元できない。
> 手順 1 (退避) を終える前に手順 3 以降へ進まない。

## 全体の順序

```mermaid
flowchart TD
  A["1. 退避<br/>GitHub / 社内 PC"] --> B["2. アプリ停止"]
  B --> C["3. Runner で terraform destroy<br/>02 → 01 の順"]
  C --> D["4. State が空であることを確認"]
  D --> E["5. Runner 終了 → SG → S3 → IAM<br/>(手動 Bootstrap の削除)"]
  E --> F["6. 残存リソースの最終確認"]
```

依存関係: Pattern 02 の SG が Pattern 01 の SG を参照している場合があるため、**02 → 01** の順に破棄する。
Runner は destroy を実行するため **最後** に削除する。

## 1. 退避

各パターンの §29 に従う。

| 対象 | 手順 |
| --- | --- |
| Windows 開発用 EC2 | [Pattern 01 §29](../04_patterns/01_windows-dev-ec2/README.md#29-週末前の退避) |
| Linux Docker 開発用 EC2 | [Pattern 02 §29](../04_patterns/02_linux-docker-dev/README.md#29-週末前の退避) |
| Runner | 退避対象なし (IaC の正本は社内 PC のローカル Git) |

確認:

- [ ] Public 可のコードを GitHub へ push した
- [ ] 非公開の成果物を社内 PC のローカル Git へ取り込み、コミットした
- [ ] Box Drive へ Git Bundle を作成した ([コード管理 §3](../02_common-design/code-management.md#3-box-drive-へのバックアップ))

## 2. アプリケーションの停止

```bash
# Linux (dev ユーザー)
cd ~/work/<GITHUB_REPO>/04_patterns/03_docker-react-fastapi-snowflake
docker compose down --volumes --rmi local
sudo systemctl disable --now sample-etl.timer 2>/dev/null || true
```

EC2 ごと削除するため必須ではないが、コンテナ内の一時データを確実に消す。

## 3. terraform destroy

Runner が停止している場合は起動し、Session Manager で接続する。

```bash
cd ~/iac/current/04_patterns/02_linux-docker-dev/terraform
terraform init -input=false -backend-config=../../../08_iac/bootstrap/backend.hcl
terraform plan -destroy -out=destroy.tfplan
```

Plan を確認する。

- `Plan: 0 to add, 0 to change, N to destroy.` の N が想定どおりか (Pattern 02 は 7 前後)。
- 対象の `Name` がすべて `<owner>-dockdev-*` であること。

```bash
terraform apply destroy.tfplan
rm -f destroy.tfplan
terraform state list          # 何も表示されなければ空
```

続けて Pattern 01 を同様に破棄する。

```bash
cd ~/iac/current/04_patterns/01_windows-dev-ec2/terraform
terraform init -input=false -backend-config=../../../08_iac/bootstrap/backend.hcl
terraform plan -destroy -out=destroy.tfplan
terraform apply destroy.tfplan
rm -f destroy.tfplan
terraform state list
```

smoke-test の State が残っている場合も破棄する (AWS 上のリソースはないが State を空にする)。

```bash
cd ~/iac/current/08_iac/bootstrap/smoke-test
terraform init -input=false -backend-config=../backend.hcl
terraform plan -destroy -out=destroy.tfplan   # 対象は terraform_data.smoke の 1 件のみであること
terraform apply destroy.tfplan
rm -f destroy.tfplan
```

## 4. State が空であることの確認

- [ ] 各 Root Module で `terraform state list` が何も出力しない
- [ ] EC2 → インスタンス (`tag:ManagedBy = terraform`、`tag:Owner = <OWNER>`) が 0 件、または「終了済み」のみ

## 5. 手動 Bootstrap リソースの削除

> [!WARNING]
> Runner を終了すると Session Manager の接続も切れる。手順 3・4 の完了を確認してから進む。

| 順 | 対象 | コンソール操作 | 確認する値 |
| --- | --- | --- | --- |
| 1 | Runner EC2 | EC2 → インスタンス → `<owner>-tfrunner-ec2-01` → 「インスタンスの状態」→「インスタンスを終了 (削除)」 | 状態が「終了済み」。ルート EBS は「終了時に削除」が有効だったため自動削除される |
| 2 | Runner SG | EC2 → セキュリティグループ → `<owner>-tfrunner-sg-01` → 「アクション」→「セキュリティグループを削除」 | Runner が「終了済み」になってから実行 (ENI が残っていると削除できない) |
| 3 | Bootstrap S3 | S3 → `<BOOTSTRAP_BUCKET_NAME>` →「空にする」→ 確認文字列を入力 → 「削除」→ バケット名を入力 | バージョニング有効のため「空にする」で全バージョンが削除される。削除前に `state/` 以外に必要なものがないか確認 |
| 4 | Runner IAM ロール | IAM → ロール → `<owner>-tfrunner-role-01` → 「削除」 | 同名のインスタンスプロファイルもコンソールが併せて削除する |
| 5 | Runner 用カスタマー管理ポリシー | IAM → ポリシー → フィルター `<owner>-tfrunner` → 3 件を削除 | ロール削除後はアタッチ先が 0 件 |

## 6. 残存リソースの最終確認

Resource Groups & Tag Editor が利用できる場合 (未確定事項 Q-08):

1. 「Resource Groups & Tag Editor」→「タグエディタ」。
2. リージョン `ap-northeast-1`、リソースタイプ「すべてのサポートされているリソースタイプ」、タグ `Owner = <OWNER>` で検索。
3. 0 件であること (IAM などグローバルリソースは別途確認)。

利用できない場合はサービスごとに確認する。

- [ ] EC2 インスタンス: 実行中・停止済みが 0 件
- [ ] EBS ボリューム: `<owner>-` で始まる Name タグが 0 件
- [ ] セキュリティグループ: `<owner>-` で始まるものが 0 件
- [ ] キーペア: `<owner>-windev-key-01` がない
- [ ] IAM ロール: `<owner>-` で始まるものが 0 件
- [ ] IAM ポリシー: `<owner>-` で始まるカスタマー管理ポリシーが 0 件
- [ ] S3: `<BOOTSTRAP_BUCKET_NAME>` がない
- [ ] Elastic IP: 割り当てがない (本ランブックでは作成しない)

## 7. 社内 PC 側の後片付け

- `dist/iac/` の ZIP は削除してよい (Box Drive に保存済みの場合)。
- Windows パスワードをメモした場合は破棄する (翌週は新しいパスワードになる)。
