# 週末後の再構築手順

実施時期: 月曜 09:00 以降、その週の最初の作業時。前週のリソースはすべて削除されている前提で、空の環境から作り直す。

## 全体の順序

```mermaid
flowchart TD
  A["1. 環境が空であることを確認"] --> B["2. 社内 PC: tfvars 更新・IaC ZIP 作成"]
  B --> C["3. Bootstrap (手動)<br/>S3 → IAM → SG → Runner"]
  C --> D["4. Runner: IaC 取得・疎通確認"]
  D --> E["5. Pattern 01 apply<br/>Windows"]
  E --> F["6. Pattern 02 apply<br/>Linux Docker"]
  F --> G["7. Pattern 03 起動<br/>アプリ"]
```

必要なパターンだけを構築してよい (例: Windows を使わない週は手順 5 を省略)。ただし Pattern 02 で Windows からのアプリ確認を許可する場合は Pattern 01 が先に必要。

## 1. 環境が空であることを確認

1. [スイッチロール](README.md#共通の前提操作-スイッチロール) する。
2. [週末前の破棄 §6](pre-weekend-teardown.md#6-残存リソースの最終確認) のチェックリストで、前週のリソースが残っていないことを確認する。
3. 残っている場合: Terraform 管理のもの (`ManagedBy = terraform`) は State がないため、コンソールで手動削除する。削除前に `Owner` タグが自分であることを確認する。

## 2. 社内 PC: 設定更新と IaC ZIP

1. 今週の `ExpiresAt` (次の日曜日) を各 `terraform.tfvars` の `expires_at` に設定する。
2. Bootstrap S3 バケット名は前週と同じ名前を再利用する。作成時に「既に存在する」エラーになる場合は末尾のランダム英数字を変え、次の 3 か所を更新する。
   - `08_iac/bootstrap/backend.hcl` の `bucket`
   - 各 `terraform.tfvars` の `transfer_bucket_name`
   - IAM ポリシー JSON を貼り付けるときの `<BOOTSTRAP_BUCKET_NAME>`
3. IaC ZIP を作成する ([コード管理 §4](../02_common-design/code-management.md#4-非公開-iac-zip))。

```bash
09_scripts/package-iac.sh
```

出力された ZIP 名と SHA256 を控える (SHA256 は秘密情報ではない)。

## 3. Bootstrap (手動)

[Pattern 00 §19 手動例外手順](../04_patterns/00_terraform-bootstrap/README.md#19-手動例外手順) の手順 A〜F を実施する。

| 手順 | 内容 | 目安 |
| --- | --- | --- |
| A | Bootstrap S3 作成 | 5 分 |
| B | IAM ポリシー 3 件作成 | 10 分 |
| C | Runner 用 IAM ロール作成 (Boundary 適用) | 5 分 |
| D | Runner 用 SG 作成 | 3 分 |
| E | Runner EC2 作成 (user data に runner-setup.sh) | 5 分 + 起動待ち 5 分 |
| F | IaC ZIP を S3 `iac/` へアップロード | 2 分 |

## 4. Runner: IaC 取得と疎通確認

[Pattern 00 §23 正常系確認](../04_patterns/00_terraform-bootstrap/README.md#23-正常系確認) を実施する。
smoke-test で Backend への書き込みとロック、Subnet の経路判定まで確認できたら次へ進む。

## 5. Pattern 01: Windows 開発用 EC2

[Pattern 01 §30 週末後の再構築](../04_patterns/01_windows-dev-ec2/README.md#30-週末後の再構築) を実施する。

## 6. Pattern 02: Linux Docker 開発用 EC2

[Pattern 02 §30 週末後の再構築](../04_patterns/02_linux-docker-dev/README.md#30-週末後の再構築) を実施する。

## 7. Pattern 03: アプリケーション

[Pattern 03 §30 週末後の再構築](../04_patterns/03_docker-react-fastapi-snowflake/README.md#30-週末後の再構築) を実施する。

## 8. 完了確認

- [ ] Runner: `terraform version` が 1.16.4、`/var/lib/runner-setup/status` が `success`
- [ ] Windows: `Test-WindowsDev.ps1` がすべて PASS
- [ ] Linux: `check-devhost.sh` がすべて PASS
- [ ] アプリ: `/api/healthz` が 200、`/api/readyz` が Snowflake 設定済みなら 200
- [ ] 作業しない EC2 は停止した
