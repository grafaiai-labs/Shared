# 作業開始手順 (日次)

前提: 今週の [再構築](post-weekend-rebuild.md) が完了していること。月曜の最初の作業では再構築手順を先に行う。

## 1. 環境の確認

1. [スイッチロール](README.md#共通の前提操作-スイッチロール) し、リージョンが `ap-northeast-1` であることを確認する。
2. EC2 → インスタンス で、フィルター `tag:Owner = <OWNER>` を指定して一覧を表示する。

   | 確認項目 | 期待値 |
   | --- | --- |
   | インスタンス数 | 今週作成したものだけ (Runner、Windows、Linux) |
   | インスタンスの状態 | 前日に停止したものは「停止済み」 |
   | 想定外のインスタンス | ないこと |

## 2. 必要な EC2 を起動する

必要なものだけを起動する (課金は起動中のみ)。

1. 対象インスタンスを選択 → 「インスタンスの状態」→「インスタンスを開始」。
2. 「ステータスチェック」が `2/2 のチェックに合格しました` (または `3/3`) になるまで待つ。

| 対象 | 起動する場面 |
| --- | --- |
| Terraform Runner | Terraform を実行する日だけ |
| Windows 開発用 EC2 | GUI (VS Code、ブラウザー) を使う日 |
| Linux Docker 開発用 EC2 | コンテナを動かす日 |

## 3. 接続

| 対象 | 手順 |
| --- | --- |
| Windows | **Public IPv4 が起動ごとに変わる** ため、インスタンス詳細で新しい Public IPv4 を確認してから SMART Gateway 経由で RDP 接続する ([Pattern 01 §23](../04_patterns/01_windows-dev-ec2/README.md#23-正常系確認)) |
| Runner / Linux | EC2 → 対象インスタンス → 「接続」→「Session Manager」タブ →「接続」([SSM 接続](../05_components/ssm-session-manager.md)) |

Linux では接続後に作業ユーザーへ切り替える。

```bash
sudo -iu dev
```

## 4. 作業再開時の確認

```bash
# Linux (dev ユーザー)
cd ~/work/<GITHUB_REPO>
git status --short
git pull --ff-only
docker compose ps
```

```powershell
# Windows
cd $HOME\work\<GITHUB_REPO>
git status --short
git pull --ff-only
```
