# 作業終了手順 (日次)

金曜 (週の最終作業日) はこの手順ではなく [週末前の破棄](pre-weekend-teardown.md) を行う。

## 1. 作業内容の保存

EC2 のディスクは週末に消える。日次でも、失いたくない変更はその日のうちに外へ出す。

| 内容 | 保存先 | 手順 |
| --- | --- | --- |
| Public 可のコード | 個人 Public GitHub | `git add` → `git commit` → `git push` |
| 非公開の成果物 (メモ、設定) | 社内 PC のローカル Git | [S3 による搬送](../05_components/s3-transfer.md) の「EC2 → 社内 PC」 |
| Snowflake のデータ | Snowflake | 対象外 (Snowflake 側が正本) |

> [!WARNING]
> `.env`、`secrets/`、Windows のパスワード、Snowflake の鍵を GitHub や S3 へ保存しない。

## 2. アプリケーションの停止

```bash
# Linux (dev ユーザー)。コンテナを停止する (イメージとボリュームは残る)
cd ~/work/<GITHUB_REPO>/04_patterns/03_docker-react-fastapi-snowflake
docker compose stop
docker compose ps
```

systemd timer でバッチを動かしている場合、EC2 を停止すればタイマーも止まる。

## 3. EC2 の停止

1. EC2 → インスタンス → フィルター `tag:Owner = <OWNER>`。
2. 起動中のインスタンスをすべて選択 → 「インスタンスの状態」→「インスタンスを停止」。
3. 状態が「停止済み」になったことを確認する。

| 対象 | 停止してよいか |
| --- | --- |
| Terraform Runner | はい (State は S3 にある) |
| Windows 開発用 EC2 | はい (EBS は残る。Public IPv4 は変わる) |
| Linux Docker 開発用 EC2 | はい (Docker イメージは残る) |

停止中も EBS の料金は発生する。Public IPv4 は停止中は課金されない (インスタンスに関連付いている間のみ)。

## 4. 確認

- [ ] 起動中のインスタンスが 0 件 (`tag:Owner = <OWNER>`、状態 = running)
- [ ] ローカル Git に未コミットの変更がない (`git status --short` が空)
